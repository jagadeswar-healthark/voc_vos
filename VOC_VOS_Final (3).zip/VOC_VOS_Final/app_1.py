import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
import os
import json
import zipfile
import tempfile
import shutil
from datetime import datetime
from pathlib import Path
import time
import uuid
from io import BytesIO
import re
from typing import List, Dict, Any


# Pipeline imports
from src.ingestion import load_files
from src.preprocessing import preprocess
from src.classification import classify
# UPDATED IMPORTS FOR KANO
from src.requirement_generator import (
    generate_requirement, 
    generate_qfd_roof, 
    write_excel_house, 
    create_kano_chart,
    analyze_stakeholder_persona,customer_need
)
from src.competitive_analysis import (
    get_gemini_client, 
    discover_companies, 
    retrieve_company_data,
    generate_competitor_assessment
)
from src.strategic_fit import generate_strategic_fit
from src.market import market_insights   
from src.new_analysis.new_analysis import ( 
    product_anchor,
    like_for_like,
    compititive_table,
    generate_swot_analysis,
    generate_ip_technology_positioning,
    fix_nested_list_formatting,
    generate_deep_dive_strategy,
    generate_cost_structure
)
from src.slide_export import (
    initialize_presentation,
    add_slide_to_presentation,
    export_presentation_to_bytes
)
from src.image_extractor import fetch_product_image



# ============================================================
# PAGE CONFIG - MUST BE FIRST
# ============================================================
st.set_page_config(page_title="VOC/VOS Analytics", page_icon="📊", layout="wide")

# ============================================================
# SESSION STATE INITIALIZATION
# ============================================================
def init_session_state():
    """Initialize all session state variables"""
    defaults = {
        # QFD State
        "all_text": "",
        "uploaded_zip": None,
        "run_completed": False,
        "classified_df": None,
        "req_df": None,
        "results_df": None,
        "product_image": None,
        "specs_list": [],  # <--- ADD THIS
        "voc_slide": False, # <--- ADD THIS
        "stakeholder_rows": [],
        "customer_needs": None, # <--- ADD THIS
        "stakeholder_analysis": False, # <--- ADD THIS
        "competitive_df": None,
        "fit_data": None,
        "product_category":"",
        "strategic_fit_data": None,
        "expand_qfd": False,
        "competitive_analysis": False,
        "market_analysis": False,
        "new_competitive_analysis": False,
        "strategic_fit": False,
        "idx_a": 0,
        "idx_b": 1,
        "run_button": False,
        
        # Kano State
        "kano_image_path": None,
        "kano_fig": None,

        #new competitive analysis state variables
        "product_category": "",
        "benchmark_product":"",
        "benchmark_manufacturer":"",
        "anchor_info": None,
        "like_info": None,
        "benchmarking_info":None,
        "swat_analysis_info":None,
        "ip_technology_info" : None,
        "strategy_info":None,
        "cost_info": None,

        # Presentation Export State
        "export_presentation": None,
        "slides_added": set(),




        # Competitive Analysis State
        "companies": [],
        "citations": [],
        "analysis_citation": [],
        "product": "",
        "region": "North America",
        "raw_results": [],
        "product_options": [],
        "assessment": None,
        "ca_step": "1. Discover", 
        
        # Performance Scores
        "performance_scores": {
            "Quality": 5,
            "Performance": 5,
            "Safety & Regulatory": 5,
            "Ease of Use": 4,
            "Reliability": 5,
            "Cost": 4,
            "Storage Capacity": 3,
            "Appearance": 2,
            "Market": 2,
            "Logistics": 1,
            "Sustainability": 3
        }
    }
    
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value

init_session_state()

# ============================================================
# CONFIGURATION
# ============================================================
RUNS_BASE_DIR = "data/outputs"
os.makedirs(RUNS_BASE_DIR, exist_ok=True)

# Custom CSS
CUSTOM_CSS = """
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: 700;
        color: #1e40af;
        margin-bottom: 0.5rem;
    }
    .sub-header {
        font-size: 1.5rem;
        font-weight: 600;
        color: #1e40af;
        margin-bottom: 1rem;
        padding-bottom: 0.5rem;
    }
    .red-header {
        font-size: 1.3rem;
        font-weight: 600;
        color: #dc2626;
        margin-bottom: 0.8rem;
    }
    .card {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 0.5rem;
        padding: 1.5rem;
        line-height: 1.6;
    }
    .grey-box {
        background: #f3f4f6;
        border-left: 4px solid #6b7280;
        padding: 1rem;
        border-radius: 0.25rem;
        margin-top: 1rem;
    }
</style>
"""

# ============================================================
# UTILITY FUNCTIONS
# ============================================================
def unzip_to_temp(zip_file):
    temp_dir = tempfile.mkdtemp()
    with zipfile.ZipFile(zip_file, "r") as zip_ref:
        zip_ref.extractall(temp_dir)
    return temp_dir

def get_file_count_in_zip(zip_file):
    with zipfile.ZipFile(zip_file, "r") as zip_ref:
        return len([f for f in zip_ref.namelist() if f.endswith('.txt')])

def save_text_to_temp(text: str, temp_dir: str) -> str:
    file_name = f"Manager_input_{uuid.uuid4()}.txt"
    file_path = os.path.join(temp_dir, file_name)
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(text)
    return file_path

def save_uploaded_file_to_temp(uploaded_file, temp_dir: str) -> str:
    file_path = os.path.join(temp_dir, uploaded_file.name)
    with open(file_path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    return file_path

def create_bar_chart(results_df):
    try:
        if results_df is None or results_df.empty:
            return None
        
        results_df = results_df.apply(pd.to_numeric, errors='coerce')
        selected_columns = results_df.columns[2:]
        total_values = results_df.loc['Total', selected_columns]
        total_values_sorted = total_values.sort_values(ascending=True)
        
        fig = go.Figure()
        fig.add_trace(go.Bar(
            x=total_values_sorted,
            y=total_values_sorted.index,
            orientation='h',
            marker=dict(
                color=total_values_sorted,
                colorscale='Viridis',
                showscale=True,
                line=dict(color='#1e40af', width=1)
            ),
            text=total_values_sorted.astype(int),
            textposition='outside'
        ))
        
        fig.update_layout(
            title={'text': '<b>Requirement Scores</b>', 'x': 0.5},
            xaxis_title='Total Score',
            height=600,
            template='plotly_white'
        )
        return fig
    except Exception as e:
        return None

def create_pie_chart(results_df):
    try:
        if results_df is None or results_df.empty or 'Total' not in results_df.columns:
            return None
        
        results_df = results_df.iloc[:-1]
        total_values = results_df['Total']
        
        fig = go.Figure(data=[go.Pie(
            labels=results_df.index,
            values=total_values,
            hole=0.3,
            textinfo='percent+label'
        )])
        
        fig.update_layout(
            title={'text': '<b>Importance Distribution</b>', 'x': 0.5},
            template='plotly_white'
        )
        return fig
    except Exception:
        return None

def add_performance_score(key, value):
    if key and key not in st.session_state.performance_scores:
        try:
            st.session_state.performance_scores[key] = int(value)
            st.rerun()
        except ValueError:
            st.error("Score must be a number")

def delete_performance_score(key):
    if key in st.session_state.performance_scores:
        del st.session_state.performance_scores[key]
        st.rerun()

def export_to_excel(dataframes_dict, filename="output.xlsx"):
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        for sheet_name, df in dataframes_dict.items():
            clean_name = sheet_name[:31].replace('/', '-')
            df.to_excel(writer, sheet_name=clean_name, index=False)
    output.seek(0)
    return output

def export_to_word_with_chart(title, sections, chart_figure=None, product_name=""):
    # (Existing Word Export Logic - Kept simplified for brevity, assume previous logic)
    from docx import Document
    from docx.shared import Inches, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    
    doc = Document()
    doc.add_heading(title, 0)
    if product_name: doc.add_paragraph(f"Product: {product_name}")
    
    for section in sections:
        doc.add_heading(section.get("heading", ""), 1)
        content = section.get("content", "")
        if isinstance(content, list):
            for item in content: doc.add_paragraph(item, style='List Bullet')
        else:
            doc.add_paragraph(str(content))
            
    if chart_figure:
        img_buffer = BytesIO()
        chart_figure.savefig(img_buffer, format='png')
        img_buffer.seek(0)
        doc.add_picture(img_buffer, width=Inches(6))
        
    output = BytesIO()
    doc.save(output)
    output.seek(0)
    return output

def reset_competitive_analysis_state():
    st.session_state.anchor_info= None
    st.session_state.like_info= None
    st.session_state.benchmarking_info=None
    st.session_state.swat_analysis_info=None
    st.session_state.ip_technology_info = None
    st.session_state.companies = []
    st.session_state.strategy_info = None
    st.session_state.cost_info = None
    st.session_state.ca_step = None


# ============================================================
# SIDEBAR
# ============================================================
def render_sidebar():
    with st.sidebar:
        st.markdown("### 🔧 Navigation")
        
        if st.button("📋 QFD", use_container_width=True, key="btn_qfd"):
            st.session_state.expand_qfd = True # Changed logic slightly to ensure True state
            st.session_state.voc_slide = False
            st.session_state.stakeholder_analysis = False
            st.session_state.competitive_analysis = False
            st.session_state.strategic_fit = False
            st.session_state.market_analysis = False
            st.session_state.new_competitive_analysis = False
        
        if st.button("👥 Stakeholder Analysis", use_container_width=True, key="btn_stakeholder"):
            st.session_state.stakeholder_analysis = True
            st.session_state.expand_qfd = False
            st.session_state.voc_slide = False
            st.session_state.market_analysis = False
            st.session_state.competitive_analysis = False
            st.session_state.strategic_fit = False
            st.session_state.new_competitive_analysis = False

        if st.button("📢 VOC Summary Slide", use_container_width=True, key="btn_voc_slide"):
            st.session_state.voc_slide = True # Changed logic slightly to ensure True state
            st.session_state.expand_qfd = False
            st.session_state.stakeholder_analysis = False
            st.session_state.market_analysis = False
            st.session_state.competitive_analysis = False
            st.session_state.strategic_fit = False
            st.session_state.new_competitive_analysis = False
        
        if st.button("📊 Market Analysis", use_container_width=True, key="btn_ma"):
            st.session_state.market_analysis = True # Changed logic slightly to ensure True state
            st.session_state.expand_qfd = False
            st.session_state.voc_slide = False
            st.session_state.stakeholder_analysis = False
            st.session_state.competitive_analysis = False 
            st.session_state.strategic_fit = False
            st.session_state.new_competitive_analysis = False

        # if st.button("📈 Competitive Analysis", use_container_width=True, key="btn_ca"):
        #     st.session_state.competitive_analysis = True # Changed logic slightly to ensure True state
        #     st.session_state.expand_qfd = False
        #     st.session_state.voc_slide = False
        #     st.session_state.market_analysis = False
        #     st.session_state.stakeholder_analysis = False
        #     st.session_state.strategic_fit = False
        #     st.session_state.new_competitive_analysis = False
        st.write("")

        if st.button("📈 Competitive Analysis ", use_container_width=True, key="btn_new_ca"):
            st.session_state.new_competitive_analysis = True
            st.session_state.expand_qfd = False
            st.session_state.voc_slide = False
            st.session_state.stakeholder_analysis = False
            st.session_state.market_analysis = False
            st.session_state.competitive_analysis = False
            st.session_state.strategic_fit = False

        # if st.button("🎯 Strategic Fit", use_container_width=True, key="btn_sf"):
        #     st.session_state.strategic_fit = True # Changed logic slightly to ensure True state
        #     st.session_state.expand_qfd = False
        #     st.session_state.voc_slide = False
        #     st.session_state.market_analysis = False
        #     st.session_state.stakeholder_analysis = False
        #     st.session_state.competitive_analysis = False
        #     st.session_state.new_competitive_analysis = False
        
        if st.button("🎯 Reset", use_container_width=True, key="btn_rs"):
            st.session_state.anchor_info= None
            st.session_state.like_info= None
            st.session_state.benchmarking_info=None
            st.session_state.swat_analysis_info=None
            st.session_state.ip_technology_info = None
            st.session_state.companies = []
            st.session_state.strategy_info= None
            st.session_state.cost_info = None
          
        st.markdown("---")
        
        if st.session_state.expand_qfd:
            st.subheader("📋 QFD Configuration")

            st.session_state.uploaded_zip = st.file_uploader(
                "📦 Upload ZIP \n (Accepted file types inside ZIP: .pdf,.docx,.xlsx,.csv,.txt)",
                type=["zip"] )
            product_name = st.text_input("**Product Name**", "Generic Product")
            st.subheader("Input Data")
            manual_input = st.text_area("Manual Input", height=100)
            uploaded_file = st.file_uploader("Or single file", type=["txt", "docx"])
            

            st.markdown("---")
            st.subheader("📊 Feedback Categories")
            
            # Category Editors
            for key, value in st.session_state.performance_scores.items():
                col1, col2, col3 = st.columns([2, 1, 0.8])
                with col1: st.write(f"**{key}**")
                with col2: 
                    new = st.number_input("S", 0, 10, int(value), key=f"e_{key}", label_visibility="collapsed")
                    if new != value: st.session_state.performance_scores[key] = new
                with col3:
                    if st.button("x", key=f"d_{key}"): delete_performance_score(key)
            
            st.markdown("**Add New**")
            c1, c2, c3 = st.columns([2,1,1])
            nk = c1.text_input("N", label_visibility="collapsed")
            nv = c2.number_input("V", 0, 10, 5, label_visibility="collapsed")
            if c3.button("Add"): add_performance_score(nk, nv)
            
            return st.session_state.uploaded_zip, manual_input, uploaded_file

        if st.session_state.new_competitive_analysis:
                st.subheader("📈 Competitive Analysis Configuration")
                st.write("")
                
                st.session_state.product_category = st.text_input("**Product Category**", st.session_state.product_category)
                st.session_state.benchmark_product = st.text_input("**Benchmark Product**", st.session_state.benchmark_product)
                st.session_state.benchmark_manufacturer = st.text_input("**Benchmark Manufacturer**", st.session_state.benchmark_manufacturer)
                               
           
        
        return None, None, None



# ============================================================
# QFD SECTION (UPDATED FOR KANO)
# ============================================================
def render_qfd_section(uploaded_zip, manual_input, uploaded_file):
    col1, col2 = st.columns([4,6])
    with col1:
        st.markdown('<div class="sub-header">📋 Quality Function Deployment</div>', unsafe_allow_html=True)
    
    # 1. Handle No Data Case (Reset State)
    # if not st.session_state.run_button:
    if st.session_state.uploaded_zip is None:
        if st.session_state.run_completed:
            st.success("✅ Analysis Loaded")
            render_qfd_results()
            return 
        else: 
            st.info("👈 Upload data to start")
            # Reset run state so old results don't linger when files are removed
            st.session_state.run_completed = False  
            st.session_state.run_button = False
            st.session_state.stakeholder_rows = []

        return

    # 2. Render Run Button (ALWAYS show this if data is present)
    with col2:
        st.session_state.run_button = False
        # st.session_state.run_completed = False
        # Change label if re-running
        btn_label = "🔄 Rerun Pipeline" if st.session_state.run_completed else "▶️ Run Pipeline"
        if st.button(btn_label, type="primary", use_container_width=True):
            st.session_state.run_button = True
            st.session_state.stakeholder_rows = []
           


    if st.session_state.run_button:
        execute_qfd_pipeline(uploaded_zip, manual_input, uploaded_file)
        # st.rerun() # Force refresh to show new results immediately

    # 3. Show Completion Status & Results
    if st.session_state.run_completed:
        
        st.success("✅ Analysis Loaded")
        render_qfd_results()

def execute_qfd_pipeline(uploaded_zip, manual_input, uploaded_file):
    start_time = time.time()
    specs_list = []
    
    # KANO TRACKING LISTS
    graph_reqs = []
    graph_cats = []
    kano_map = {}

    run_id = datetime.now().strftime("%d-%m-%Y_%H-%M-%S")
    run_dir = os.path.join(RUNS_BASE_DIR, f"run_{run_id}")
    os.makedirs(run_dir, exist_ok=True)
    
    requirements_path = os.path.join(run_dir, "requirements.xlsx")
    kano_image_path = os.path.join(run_dir, "Kano_Graph.png")
    
    with st.spinner("📦 Extracting files..."):
        if uploaded_zip: input_dir = unzip_to_temp(uploaded_zip)
        else: input_dir = tempfile.mkdtemp()
        
    if manual_input: save_text_to_temp(manual_input, input_dir)
    if uploaded_file: save_uploaded_file_to_temp(uploaded_file, input_dir)
    
    docs = load_files(input_dir)
    classified_records = []
    req_rows = []
    
    progress_bar = st.progress(0)
    status = st.empty()

    for idx, d in enumerate(docs, start=1):
        progress_bar.progress(idx / len(docs))
        status.text(f"Processing {d['filename']}...")
        
        p = preprocess(d)
        st.session_state.all_text += p["cleaned_text"]
        c, _ = classify(p["cleaned_text"], "Product")
        classified_records.append({
            "filename": p["filename"], 
            "text": p["cleaned_text"], 
            "category": c.product_line
        })
        
        # CALL GENERATOR (Returns Kano & Specs now)
        req_json, _ = generate_requirement(p["cleaned_text"], "Product")
        
        for entry in req_json.get("QFD_Entries", []):
            req_name = entry['Product_Requirement']
            # Parse new fields
            kano_cat = entry.get('Kano_Category', 'Performance')
            tech_spec = entry.get('Technical_Specification', '')
            spec_det = entry.get('Specification_details', '')
            
            # Prepare matrix row
            row = {"Product_Requirement": req_name}
            row.update(entry["Relationship_Matrix"])
            req_rows.append(row)

            # Store Specs for Sheet 3
            specs_list.append({
                "Product_Requirement": req_name,
                "Specification_details": spec_det,
                "Technical_Specification": tech_spec,
                "Kano_Category": kano_cat,
                "Source_File": d['filename']
            })
            
            # Store Map & Graph Data
            kano_map[req_name] = kano_cat
            graph_reqs.append(req_name)
            graph_cats.append(kano_cat)
            
        # --- NEW: STAKEHOLDER ANALYSIS ---
        # We only run this once per file to identify the "Voice" of that file
        persona_data = analyze_stakeholder_persona(p["cleaned_text"], d['filename'])
        if persona_data:
            # Append source file for traceability
            persona_data["Source"] = d['filename'] 
            # Use session state to accumulate results across the loop
            if "stakeholder_rows" not in st.session_state:
                st.session_state.stakeholder_rows = []
            st.session_state.stakeholder_rows.append(persona_data)
        st.session_state.customer_needs = customer_need(st.session_state.all_text)

    progress_bar.empty()
    status.empty()

    st.write("")
    st.write("")
    with st.spinner("📊 Generating QFD outputs..."):
        # 1. GENERATE KANO CHART
        if graph_reqs:
            path, fig = create_kano_chart(graph_reqs, graph_cats, output_filename=kano_image_path)
            
            st.session_state["kano_image_path"] = path  # Keeps file path for Excel
            st.session_state["kano_fig"] = fig
        # 2. BUILD DATAFRAMES
        classified_df = pd.DataFrame(classified_records)
        st.session_state.classified_df = classified_df.copy()

        req_df = pd.DataFrame(req_rows).drop_duplicates(subset=["Product_Requirement"]).set_index("Product_Requirement")
        req_df = req_df.transpose()
        expectations = ["Quality", "Performance", "Safety & Regulatory", "Ease of Use", "Reliability", "Cost", "Storage Capacity", "Appearance", "Market", "Logistics", "Sustainability"]
        req_df = req_df.reindex(expectations)

        req_df.replace("", float("NaN"), inplace=True)
        req_df.fillna("", inplace=True)
        st.session_state.req_df = req_df.copy()

        # 3. CALCULATE UI RESULTS (For Bar/Pie Charts)
        ui_req_df = req_df.copy()
        Importance = st.session_state.performance_scores.values()
        ui_req_df.insert(0, "Importance", Importance)
        
        priority_map = {"H": 9, "M": 3, "L": 1}
        results_df = ui_req_df.copy()
        value_cols = ui_req_df.columns[1:]
        
        for col in value_cols:
            results_df[col] = (ui_req_df[col].map(priority_map).fillna(0).astype(int) * ui_req_df["Importance"])
        
        results_df.insert(1, "Total", results_df[value_cols].sum(axis=1))
        
        # Add Total Row
        total_row = pd.DataFrame([results_df[value_cols].sum()], index=["Total"])
        total_row["Total"] = results_df["Total"].sum()
        results_df = pd.concat([results_df, total_row])
        st.session_state.results_df = results_df.copy()

        # 4. GENERATE ROOF
        roof_cols = req_df.columns.tolist()
        qfd_roof_df = generate_qfd_roof(roof_cols)

        # 5. WRITE EXCEL HOUSE (New Signature)
        # Note: write_excel_house handles its own score calculation logic for the Excel file
        # We pass specs_list and kano_map for the new features.
        write_excel_house(
            df_body=req_df, 
            roof_data=qfd_roof_df, 
            roof_cols=roof_cols, 
            score_df=results_df,
            specs_list=specs_list,
            kano_map=kano_map,
            OUTPUT_EXCEL_NAME=requirements_path,
            kano_image_path=kano_image_path
        )

        with open(requirements_path, "rb") as f:
            st.session_state["requirements_bytes"] = f.read()
        st.session_state.specs_list = specs_list
        st.session_state.run_completed = True
        shutil.rmtree(input_dir)

def render_qfd_results():
    st.markdown("---")

    col1, col2 = st.columns([4, 6])
    with col1:

        st.markdown(f'<div class="sub-header">📊 Results & Export</div>', unsafe_allow_html=True)
    
    
    with col2:
        if "requirements_bytes" in st.session_state:
            st.download_button(
                "⬇️ Download Excel",
                st.session_state["requirements_bytes"],
                f"QFD_Kano_{datetime.now().strftime('%H%M')}.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True
            )

    # Tabs for Display
    tab1, tab2, tab3 = st.tabs(["📄 Requirements Matrix", "📊 Kano Model", "📈 Score Analysis"])
    
    # with tab1:
    #     st.dataframe(st.session_state.classified_df, use_container_width=True)
    with tab1:
        st.dataframe(st.session_state.req_df, use_container_width=True)
    with tab2:
        st.subheader("Kano Analysis Visualization")
        
        # Check for interactive figure first
        if st.session_state.get("kano_fig"):
            st.plotly_chart(st.session_state["kano_fig"], use_container_width=True)
            
        # Fallback to image if figure is missing (legacy safety)
        elif st.session_state.get("kano_image_path") and os.path.exists(st.session_state["kano_image_path"]):
            st.image(st.session_state["kano_image_path"], caption="Requirements mapped to Satisfaction Curves", use_container_width=True)
        else:
            st.info("Kano graph not generated.")
    with tab3:
        c1, c2 = st.columns([5, 6])
        with c1: 
            fig = create_bar_chart(st.session_state.results_df)
            if fig: st.plotly_chart(fig, use_container_width=True)
        with c2: 
            fig = create_pie_chart(st.session_state.results_df)
            if fig: st.plotly_chart(fig, use_container_width=True)


# ============================================================
# COMPETITIVE ANALYSIS SECTION
# ============================================================
def render_competitive_analysis():
    """Render competitive analysis"""
    st.markdown('<div class="sub-header">📈 Competitive Intelligence</div>', unsafe_allow_html=True)
    
    # Step selector
    col1, col2, col3 = st.columns(3)
    with col1:
        if st.button("1️⃣ Discover", use_container_width=True, key="ca_step1"):
            st.session_state.ca_step = "1. Discover"
    with col2:
        if st.button("2️⃣ Analysis", use_container_width=True, key="ca_step2"):
            st.session_state.ca_step = "2. Market Analysis"
    with col3:
        if st.button("3️⃣ Competitor Assessment", use_container_width=True, key="ca_step3"):
            st.session_state.ca_step = "3. Competitor Assessment"
    
    st.markdown("---")
    
    

    
    # --- STEP 1 ---
    if st.session_state.ca_step == "1. Discover":
        st.markdown('<div class="sub-header">Step 1: Market Landscape Discovery</div>', unsafe_allow_html=True)
        col1, col2 = st.columns(2)

        prod = col1.text_input("Product Category", st.session_state.product_category)
        st.session_state.product_category = prod

        region = col2.selectbox(
            "Region",
            ["North America", "Europe", "Global"],
            index=["North America", "Europe", "Global"].index(st.session_state.region) if st.session_state.region in ["North America", "Europe", "Global"] else 0,
            key="region_widget"
        )
        st.session_state.region = region
        st.write("")
        st.write("")
        if st.button("🚀 Find Top Competitors"):
            st.session_state.competitive_df = None
            st.session_state.analysis_citation = []
            st.session_state.raw_results = []
            with st.spinner("Scanning market..."):
                data,st.session_state.citations = discover_companies(region, prod)
                if data.get("status") == "success":
                    st.session_state.companies = data["companies"]
                    st.session_state.product = prod
                    # st.session_state.region = region
                    st.success(f"✅ Identified {len(data['companies'])} key players:")
                    
                else:
                    st.error(data.get("error"))
        if len(st.session_state.citations) > 0:
            st.write("### 📚 Citations")
            
            # Create a container with custom styling for the box
            st.markdown("""
                <style>
                .citation-box {
                    border: 1px solid #ddd;
                    border-radius: 8px;
                    padding: 15px;
                    background-color: #f8f9fa;
                    max-height: 300px;
                    overflow-y: auto;
                }
                .citation-item {
                    margin-bottom: 10px;
                    padding: 8px;
                    background-color: white;
                    border-radius: 4px;
                    border-left: 3px solid #4CAF50;
                }
                </style>
            """, unsafe_allow_html=True)
            
            # Build the citations HTML
            citations_html = '<div class="citation-box">'
            for i, cite in enumerate(st.session_state.citations, 1):
                citations_html += f'<div class="citation-item">{i}. {cite}</div>'
            citations_html += '</div>'
            
            st.markdown(citations_html, unsafe_allow_html=True)
        st.write("")
        st.write("")
        st.markdown("### 🏢 Discovered Companies")
        
        i=1
        cols = st.columns(3)
        for comp in st.session_state.companies:
            with cols[(i - 1) % 3]:
                
                st.markdown(
                    f"""
                    <div style="
                        padding:8px 12px;
                        background:#1c83e11a;
                        border-radius:20px;
                        margin:6px;
                        display:inline-block;
                        font-size:14px;">
                        <b>{i}</b> · {comp}
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            i+=1
                
       
        
        # --- EXCEL DOWNLOAD FOR STEP 1 ---
        if "companies" in st.session_state and st.session_state.companies:
            st.markdown("---")
            df_companies = pd.DataFrame({
                "Rank": range(1, len(st.session_state.companies) + 1),
                "Company": st.session_state.companies,
                "Product": st.session_state.get("product", ""),
                "Region": st.session_state.get("region", "")
            })
            excel_buffer = export_to_excel({"Discovered Companies": df_companies})
            st.download_button(
                label="📥 Download Companies (Excel)",
                data=excel_buffer,
                file_name=f"Step1_Companies_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )

    # --- STEP 2 (With Product Parsing) ---
    elif st.session_state.ca_step == "2. Market Analysis":
        if "companies" not in st.session_state:
            st.warning("Run Step 1 first.")
        else:
            st.markdown(f'<div class="sub-header">Step 2: Deep Dive Analysis - {st.session_state.product}</div>', unsafe_allow_html=True)
            companies_to_analyze = st.multiselect(
                '**Select companies to analyze**',
                options=st.session_state.companies,  # All available companies
                default=st.session_state.companies  # Set default to all companies selected
            )
            # companies_to_analyze = st.session_state.companies[:3] 
            # st.info(f"💡 Limited to Top 3 companies for this run: {', '.join(companies_to_analyze)}")
            st.write("")
            st.write("")
            if st.button("🔍 Gather & Tabulate Data"):
                st.session_state.raw_results = []

                results = []
                bar = st.progress(0)
                for i, co in enumerate(companies_to_analyze):
                    data, analysis_citation = retrieve_company_data(co, st.session_state.product, st.session_state.region)
                    st.session_state.analysis_citation.extend(analysis_citation)
                    results.append(data)
                    bar.progress((i+1)/len(companies_to_analyze))
                
                st.session_state.raw_results = results
            

                # TABLE & PRODUCT PARSING
                table_rows = []
                # Reset product options to rebuild them freshly
                st.session_state.product_options = []
                

                client = get_gemini_client()
                with st.spinner("Extracting comprehensive data points..."):
                    for r in results:
                        # st.write("--------------------------------------------------------------------------------------------")
                        # st.write(r["content"])
                        if r['status'] == 'success':
                            parse_prompt = f"""
                            Analyze text. Extract fields to JSON:
                            1. "Manufacturer_Status": OEM or Private Label, if not available, put Unknown.
                            2. "Brand_Classification": Premium/Value/..?
                            3. "Product_Lines": Series names (comma separated).
                            4. "Positioning": Target.
                            5. "Pricing": Range. if not available, estimate based on market.
                            6. "Presence": Channels.
                            7. "Differentiators": Tech.
                            8. "Advantages": Competitive edge.
                            9. "Performance_Score": 1-10.
                            """
                            try:
                                parsed = client.chat.completions.create(model="gemini-2.0-flash", messages=[{"role":"user", "content":r['content'] + "\n" + parse_prompt}, {"role":"system", "content": "Output valid JSON."}], temperature=0.3).choices[0].message.content
                                clean = json.loads(parsed.replace("```json","").replace("```",""))
                                # st.write(clean)
                                clean['Company'] = r['company']
                                table_rows.append(clean)
                                
                                # --- CAPTURE PRODUCT LINES FOR STEP 4 ---
                                if 'Product_Lines' in clean and clean['Product_Lines']:
                                    # Split by comma and clean up
                                    products = [p.strip() for p in clean['Product_Lines'].split(',')]
                                    for p in products:
                                        if len(p) > 2: # Ignore noise
                                            st.session_state.product_options.append(f"{r['company']} - {p}")
                                            
                            except: table_rows.append({"Company": r['company'], "Error": "Parse Fail"})
                
                if table_rows:
                   
                    st.session_state.competitive_df = pd.DataFrame(table_rows)


            # SHOW CITATIONS
            if st.session_state.analysis_citation:
                st.markdown("### 📚 Citations: ")

                st.markdown("""
                <style>
                .citation-box {
                    border: 1px solid #ddd;
                    border-radius: 8px;
                    padding: 15px;
                    background-color: #f8f9fa;
                    max-height: 300px;
                    overflow-y: auto;
                }
                .citation-item {
                    margin-bottom: 10px;
                    padding: 8px;
                    background-color: white;
                    border-radius: 4px;
                    border-left: 3px solid #4CAF50;
                }
                </style>
                 """, unsafe_allow_html=True)
            
                # Build the citations HTML
                citations_html = '<div class="citation-box">'
                for i, cite in enumerate(st.session_state.citations, 1):
                    citations_html += f'<div class="citation-item">{i}. {cite}</div>'
                citations_html += '</div>'
                
                st.markdown(citations_html, unsafe_allow_html=True)


            st.write("")
            st.write("")

            # SHOW TABLE
            if st.session_state.competitive_df is not None:
                st.markdown("### 📋 Manufacturer Intelligence Table")
                df=st.session_state.competitive_df
                cols = ["Company", "Manufacturer_Status", "Brand_Classification","Positioning", "Pricing","Presence", "Differentiators","Advantages","Performance_Score", "Product_Lines"]
                cols = [c for c in cols if c in df.columns]
                st.dataframe(df[cols], use_container_width=True)
            


        # --- EXCEL DOWNLOAD FOR STEP 2 --------------------
        if st.session_state.competitive_df is not None:
            st.markdown("---")
            excel_buffer = export_to_excel({"Market Analysis": st.session_state.competitive_df})
            st.download_button(
                label="📥 Download Market Analysis (Excel)",
                data=excel_buffer,
                file_name=f"Step2_MarketAnalysis_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )

    # --- STEP 3 ---
    elif st.session_state.ca_step == "3. Competitor Assessment":
        if "raw_results" not in st.session_state:
            st.warning("Run Step 2 first.")
        else:
            st.markdown('<div class="sub-header">Step 3: Competitor Assessment</div>', unsafe_allow_html=True)
            if st.button("📊 Generate Assessment Slide"):
                with st.spinner("Analyzing market structure..."):
                    assessment = generate_competitor_assessment(st.session_state.raw_results, st.session_state.product)
                    if assessment is None:
                        st.error("❌ Failed to generate assessment. Please check your Azure API key and try again.")
                    else:
                        st.session_state.assessment = assessment
                        st.success("✅ Assessment generated successfully!")
            
            if "assessment" in st.session_state and st.session_state.assessment is not None:
                data = st.session_state.assessment
                col1, col2 = st.columns([0.45, 0.55])
                with col1:
                    st.markdown('<div class="red-header">Market Structure</div>', unsafe_allow_html=True)
                    st.markdown(f"""{data.get('assessment_text', 'No assessment text available')}""", unsafe_allow_html=True)
                with col2:
                    st.markdown('<div class="red-header">Performance vs. Price Matrix</div>', unsafe_allow_html=True)
                    c_data = data.get('chart_data', [])
                    if not c_data:
                        st.warning("No chart data available")
                    else:
                        df_chart = pd.DataFrame(c_data)
                        fig, ax = plt.subplots(figsize=(10, 6))
                        
                        # --- IMPROVED: Brand-grouped color mapping ---
                        color_palette = {
                            'TSG': '#1f77b4', 'FBG': '#1f77b4', 'TSX': '#1f77b4',  # Blue family
                            'VWR': '#2ca02c', 'VWR Standard': '#2ca02c', 'VWR Plus': '#2ca02c', 'VWR Basic': '#2ca02c',  # Green family
                            'ABS': '#17becf', 'ABS Standard': '#17becf', 'ABS Premier': '#17becf', 'ABS Templog': '#17becf',  # Teal family
                            'LabRepCo': '#ff7f0e', 'LabRepCo Ultra': '#ff7f0e', 'LabRepCo Ultra Elite': '#ff7f0e', 'LabRepCo Ultra Touch': '#ff7f0e',  # Orange family
                        }
                        default_colors = ['#d62728', '#9467bd', '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22']
                        colors = []
                        for brand in df_chart['MANUFACTURER']:
                            matched = False
                            for key, color in color_palette.items():
                                if key.lower() in brand.lower():
                                    colors.append(color)
                                    matched = True
                                    break
                            if not matched:
                                colors.append(default_colors[len(colors) % len(default_colors)])
                        
                        scatter = ax.scatter(
                            df_chart['price_usd'], 
                            df_chart['performance'], 
                            s=df_chart['market_share'] * 500, 
                            c=colors, 
                            alpha=0.7, 
                            edgecolors="black", 
                            linewidth=1.5
                        )
                        
                        # --- Labels on bubbles ---
                        for i, txt in enumerate(df_chart['MANUFACTURER']):
                            ax.annotate(txt, (df_chart['price_usd'][i], df_chart['performance'][i]), 
                                        fontsize=9, fontweight='bold', ha='center', va='center')
                        
                        # --- Chart Title ---
                        ax.set_title(f"{st.session_state.product} Competitor Overview - Performance, Price, Relative Market Share", 
                                     fontsize=11, fontweight='bold', pad=10)
                        
                        # --- X-axis with currency formatting ---
                        ax.set_xlabel("Average Price ($ USD)", fontsize=12, fontweight='bold')
                        ax.xaxis.set_major_formatter(FuncFormatter(lambda x, p: f'${x:,.2f}'))
                        
                        ax.set_ylabel("Performance Rating (0-10)", fontsize=12, fontweight='bold')
                        ax.set_ylim(0, 10)
                        ax.grid(True, linestyle='--', alpha=0.5)
                        
                        # --- Legend for bubble size ---
                        ax.text(0.02, 0.98, "Bubble size = Relative Market Share", transform=ax.transAxes, 
                                fontsize=9, verticalalignment='top', style='italic', color='gray')
                        
                        plt.tight_layout()
                        st.pyplot(fig)
                        st.markdown(f"""<div class="grey-box">{data.get('bottom_box_text', 'Analysis complete.')}</div>""", unsafe_allow_html=True)
                        
                        # Save chart data and figure for download
                        st.session_state.assessment_chart_df = df_chart
                        st.session_state.assessment_chart_fig = fig
            
            # --- WORD DOWNLOAD FOR STEP 3 ---
            if "assessment" in st.session_state and st.session_state.assessment is not None:
                st.markdown("---")
                data = st.session_state.assessment
                
                try:
                    # Recreate chart for Word export
                    c_data = data.get('chart_data', [])
                    if c_data:
                        df_chart = pd.DataFrame(c_data)
                        fig_word, ax_word = plt.subplots(figsize=(10, 6))
                        
                        color_palette = {
                            'TSG': '#1f77b4', 'FBG': '#1f77b4', 'TSX': '#1f77b4',
                            'VWR': '#2ca02c', 'VWR Standard': '#2ca02c', 'VWR Plus': '#2ca02c', 'VWR Basic': '#2ca02c',
                            'ABS': '#17becf', 'ABS Standard': '#17becf', 'ABS Premier': '#17becf', 'ABS Templog': '#17becf',
                            'LabRepCo': '#ff7f0e', 'LabRepCo Ultra': '#ff7f0e', 'LabRepCo Ultra Elite': '#ff7f0e',
                        }
                        default_colors = ['#d62728', '#9467bd', '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22']
                        colors = []
                        for brand in df_chart['MANUFACTURER']:
                            matched = False
                            for key, color in color_palette.items():
                                if key.lower() in brand.lower():
                                    colors.append(color)
                                    matched = True
                                    break
                            if not matched:
                                colors.append(default_colors[len(colors) % len(default_colors)])
                        
                        ax_word.scatter(df_chart['price_usd'], df_chart['performance'], 
                                      s=df_chart['market_share'] * 200, c=colors, alpha=0.7, 
                                      edgecolors="black", linewidth=1.5)
                        for i, txt in enumerate(df_chart['MANUFACTURER']):
                            ax_word.annotate(txt, (df_chart['price_usd'][i], df_chart['performance'][i]), 
                                           fontsize=9, fontweight='bold', ha='center', va='center')
                        ax_word.set_title(f"{st.session_state.product} Competitor Overview", fontsize=11, fontweight='bold')
                        ax_word.set_xlabel("Average Price ($ USD)", fontsize=12, fontweight='bold')
                        ax_word.xaxis.set_major_formatter(FuncFormatter(lambda x, p: f'${x:,.2f}'))
                        ax_word.set_ylabel("Performance Rating (0-10)", fontsize=12, fontweight='bold')
                        ax_word.set_ylim(0, 10)
                        ax_word.grid(True, linestyle='--', alpha=0.5)
                        ax_word.text(0.02, 0.98, "Bubble size = Relative Market Share", transform=ax_word.transAxes, 
                                    fontsize=9, verticalalignment='top', style='italic', color='gray')
                        plt.tight_layout()
                        
                        # Create Word document
                        sections = [
                            {"heading": "Market Structure", "style": "heading"},
                            {"content": data.get('assessment_text', ''), "style": "paragraph"},
                            {"heading": "Key Insights", "style": "heading"},
                            {"content": data.get('bottom_box_text', ''), "style": "paragraph"},
                        ]
                        
                        word_buffer = export_to_word_with_chart(
                            title=f"Competitor Assessment - {st.session_state.get('region', 'Market')}",
                            sections=sections,
                            chart_figure=fig_word,
                            product_name=st.session_state.get('product', '')
                        )
                        plt.close(fig_word)
                        
                        st.download_button(
                            label="📄 Download Word Document",
                            data=word_buffer,
                            file_name=f"Step3_CompetitorAssessment_{datetime.now().strftime('%Y%m%d_%H%M')}.docx",
                            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        )
                except ImportError:
                    st.warning("Install python-docx: `pip install python-docx`")
                except Exception as e:
                    st.error(f"Word export error: {e}")


# New Competitive Analysis with Integrated Presentation Export
def _render_slide_button(slide_type, data, key_suffix):
    """Render the Add to Presentation button for a tab."""
    if data is None:
        st.warning("⚠️ Generate the analysis first before adding to presentation.")
        return
    
    if st.session_state.get('export_presentation') is None:
        st.info("💡 Initialize a presentation from the **Presentation Export Controls** above to enable slide export.")
        return
    

    already_added = slide_type in st.session_state.get('slides_added', set())
    
    
    if already_added:
        st.success(f"✅ Slide added to presentation")
        
    else:
        benchmark = st.session_state.get('benchmark_product', 'Product')
        success = add_slide_to_presentation(slide_type, data, benchmark)
        if success:
            st.success("✅ Slide added successfully!")
            st.balloons()
            st.rerun()

def render_new_competitive_analysis():
    st.markdown('<div class="sub-header">📈 Competitive Intelligence</div>', unsafe_allow_html=True)
    if (st.session_state.benchmark_product == "" ) or (st.session_state.benchmark_manufacturer == "") or (st.session_state.product_category == ""):
        st.info("👈 Start by entering the product category, benchmark product, and manufacturer in the sidebar to initialize the analysis.")
        return
    
    # PRESENTATION EXPORT CONTROLS
    def ensure_presentation_initialized():
        """Auto-initialize presentation if not already done"""
        if st.session_state.get('export_presentation') is None:

            product_name = st.session_state.get('benchmark_product', '')
            manufacturer = st.session_state.get('benchmark_manufacturer', '')

            # 🔥 Make sure image exists BEFORE initializing PPT
            if st.session_state.product_image is None:
                with st.spinner("Fetching product image for presentation..."):
                    st.session_state.product_image = fetch_product_image(
                        product_name,
                        manufacturer
                    )

            # 🔥 Pass image into presentation initialization
            st.session_state.export_presentation = initialize_presentation(
                product_name,
                manufacturer,
                st.session_state.product_image
            )

            st.session_state.slides_added = set()
            st.session_state.presentation_auto_initialized = False
            st.rerun()


    def reset_all_state():
        """Fully reset all competitive analysis state"""
        st.session_state.export_presentation = None
        st.session_state.slides_added = set()
        st.session_state.anchor_info = None
        st.session_state.like_info = None
        st.session_state.benchmarking_info = None
        st.session_state.swat_analysis_info = None
        st.session_state.ip_technology_info = None
        st.session_state.companies = []
        st.session_state.strategy_info = None
        st.session_state.cost_info = None
        # ✅ Set to empty/neutral so NO content section renders
        st.session_state.ca_step = ""

    col1, col2, col3 = st.columns(3)
    with col1:
        if st.button("Product Anchor", use_container_width=True, key="ca_step12"):
            st.session_state.ca_step = "Product Anchor"
            ensure_presentation_initialized()

        if st.button("Strategic analysis", use_container_width=True, key="ca_step22"):
            st.session_state.ca_step = "Strategic analysis"
            ensure_presentation_initialized()

        if st.button("IP & technology positioning", use_container_width=True, key="ca_step33"):
            st.session_state.ca_step = "IP & technology positioning"
            ensure_presentation_initialized()

    with col2:
        if st.button("Like for Like", use_container_width=True, key="ca_step13"):
            st.session_state.ca_step = "Like for Like"
            ensure_presentation_initialized()

        if st.button("Cost Structure", use_container_width=True, key="ca_step23"):
            st.session_state.ca_step = "Cost Structure"
            ensure_presentation_initialized()

    with col3:
        if st.button("Competitive Bench marking", use_container_width=True, key="ca_step21"):
            st.session_state.ca_step = "Competitive Bench marking"
            ensure_presentation_initialized()

        if st.button("SWOT Analysis", use_container_width=True, key="ca_step32"):
            st.session_state.ca_step = "SWOT Analysis"
            ensure_presentation_initialized()

    st.write("")
    st.markdown("---")
    st.write("")

    # --- PRESENTATION EXPORT CONTROLS ---
    with st.expander("📑 **Presentation Export Controls** - Click to expand", expanded=False):
        col_status, col_download, col_reset = st.columns([5, 5, 2])

        if st.session_state.get('presentation_auto_initialized', True):
            st.info("💡 Presentation auto-initialized. Start adding analysis sections to build your PPTX!")
        else:
            with col_status:
                if st.session_state.get('export_presentation') is not None:
                    slides_count = len(st.session_state.get('slides_added', set())) + 1
                    st.info(f"📊 {slides_count} slides in presentation")
                else:
                    st.warning("No presentation initialized")

            with col_download:
                if st.session_state.get('export_presentation') is not None:
                    buffer = export_presentation_to_bytes()
                    if buffer:
                        st.download_button(
                            "📥 Download Complete PPTX",
                            data=buffer,
                            file_name=f"Competitive_Analysis_{datetime.now().strftime('%Y%m%d_%H%M')}.pptx",
                            mime="application/vnd.openxmlformats-officedocument.presentationml.presentation",
                            use_container_width=True
                        )

            with col_reset:
                if st.button("🔄 Reset Complete PPTX", key="reset_pres", help="Reset presentation"):
                    reset_all_state()   # ✅ Single call resets everything
                    st.rerun()

        if st.session_state.get('slides_added'):
            st.caption("Added: " + ", ".join(sorted(st.session_state.slides_added)))

    # ============================================================
    # HELPER: Display Citations in UI (not in PPT)
    # ============================================================
    def display_citations(citations):
        """Display citations in an expandable section - UI only"""
        if citations and len(citations) > 0:
            with st.expander("📚 **Sources & Citations** (click to expand)", expanded=False):
                for i, citation in enumerate(citations, 1):
                    st.markdown(f"{i}. {citation}")

    # ✅ Guard: only render content when a step is actively selected
    ca_step = st.session_state.get('ca_step', '')

    if not ca_step:
        # Nothing selected or just reset — show a neutral prompt
        st.info("👆 Select an analysis section above to get started.")
        return  # ✅ Stop here — no content renders after reset

    if ca_step == "Product Anchor":

        # ------------------------------------------
        # 1️⃣ AUTO FETCH PRODUCT IMAGE
        # ------------------------------------------
        if st.session_state.product_image is None:
            with st.spinner("Fetching product image..."):
                st.session_state.product_image = fetch_product_image(
                    st.session_state.benchmark_product,
                    st.session_state.benchmark_manufacturer
                )

        # ------------------------------------------
        # 2️⃣ GENERATE PRODUCT ANCHOR
        # ------------------------------------------
        if st.session_state.anchor_info is None:
            with st.spinner("Generating Product Anchor Analysis..."):
                st.session_state.anchor_info = product_anchor(
                    st.session_state.product_category,
                    st.session_state.benchmark_product,
                    st.session_state.benchmark_manufacturer
                )

        st.write("### Product Anchor Analysis")
        st.write(st.session_state.anchor_info["content"])
        display_citations(st.session_state.anchor_info.get("citations", []))
        st.markdown("---")
        _render_slide_button('product_anchor', st.session_state.anchor_info, "anchor")

    elif ca_step == "Like for Like":
        if st.session_state.like_info is None:
            st.session_state.like_info = like_for_like(
                st.session_state.product_category,
                st.session_state.benchmark_product,
                st.session_state.benchmark_manufacturer
            )
        st.write(f"### Competitive set for {st.session_state.benchmark_product}")
        st.write(st.session_state.like_info["content"])
        display_citations(st.session_state.like_info.get("citations", []))
        st.markdown("---")
        _render_slide_button('like_for_like', st.session_state.like_info, "like")

    elif ca_step == "Competitive Bench marking":
        if st.session_state.benchmarking_info is None:
            st.session_state.benchmarking_info = compititive_table(
                st.session_state.product_category,
                st.session_state.benchmark_product,
                st.session_state.benchmark_manufacturer,
                competitors=st.session_state.get('companies', []),
                like_for_like_info=st.session_state.get('like_info', None)
            )
        st.write("### Competitive Bench marking")
        st.write(st.session_state.benchmarking_info["content"])
        display_citations(st.session_state.benchmarking_info.get("citations", []))
        st.markdown("---")
        _render_slide_button('competitive_benchmarking', st.session_state.benchmarking_info, "bench")

    elif ca_step == "SWOT Analysis":
        if st.session_state.swat_analysis_info is None:
            st.session_state.swat_analysis_info = generate_swot_analysis(
                st.session_state.product_category,
                st.session_state.benchmark_product,
                st.session_state.benchmark_manufacturer,
                st.session_state.companies
            )
        st.write("### SWOT Analysis")
        st.markdown(st.session_state.swat_analysis_info["content"])
        display_citations(st.session_state.swat_analysis_info.get("citations", []))
        st.markdown("---")
        _render_slide_button('swot', st.session_state.swat_analysis_info, "swot")

    elif ca_step == "IP & technology positioning":
        if st.session_state.ip_technology_info is None:
            st.session_state.ip_technology_info = generate_ip_technology_positioning(
                st.session_state.product_category,
                st.session_state.benchmark_product,
                st.session_state.benchmark_manufacturer,
                st.session_state.like_info
            )
        st.write("### IP & technology positioning")
        st.markdown(st.session_state.ip_technology_info["content"])
        display_citations(st.session_state.ip_technology_info.get("citations", []))
        st.markdown("---")
        _render_slide_button('ip_technology', st.session_state.ip_technology_info, "ip")

    elif st.session_state.ca_step == "Strategic analysis":
        if st.session_state.strategy_info is None:
            st.session_state.strategy_info = generate_deep_dive_strategy(st.session_state.benchmark_product, st.session_state.benchmark_manufacturer)
       
        if "error" in st.session_state.strategy_info:
                    st.error(st.session_state.strategy_info["error"])
        else:
            st.markdown("---")
            
            # --- SECTION A ---
            # We print the header manually to ensure style, then the body
            st.markdown('<div class="sub-header">A) Strategic group map (Quality ceiling vs Cost)</div>', unsafe_allow_html=True)
            
            # Fix formatting for the list
            formatted_a = fix_nested_list_formatting(st.session_state.strategy_info["A"])
            # Remove the AI's header since we just printed our own
            body_a = formatted_a.replace("A) Strategic group map (Quality ceiling vs Cost)", "").strip()
            st.markdown(body_a)
            
            # --- SECTION B ---
            # Use the Dynamic Header from the Product Name
            header_b = f"B) Where {st.session_state.benchmark_product} is competitively strong"
            st.markdown(f'<div class="sub-header">{header_b}</div>', unsafe_allow_html=True)
            
            # Clean the body
            body_b = st.session_state.strategy_info["B"]
            # Remove strictly the header line if it exists
            if "B) Where" in body_b:
                body_b = body_b.split("\n", 1)[1] if "\n" in body_b else body_b
            st.markdown(body_b.strip())
            
            # --- SECTION C ---
            header_c = f"C) Where competitors can outflank {st.session_state.benchmark_product}"
            st.markdown(f'<div class="sub-header">{header_c}</div>', unsafe_allow_html=True)
            
            body_c = st.session_state.strategy_info["C"]
            if "C) Where" in body_c:
                body_c = body_c.split("\n", 1)[1] if "\n" in body_c else body_c
            st.markdown(body_c.strip())
            
            # --- CITATIONS ---
            display_citations(st.session_state.strategy_info.get("citations", []))
            
            # --- ADD TO PRESENTATION BUTTON ---
            st.markdown("---")
            _render_slide_button('strategic_analysis', st.session_state.strategy_info, "strategy")
    


    elif st.session_state.ca_step == "Cost Structure":
        if st.session_state.cost_info is None:
            st.session_state.cost_info = generate_cost_structure(st.session_state.benchmark_product, st.session_state.benchmark_manufacturer)
       
        # Handle both dict format (new) and string format (old)
        if isinstance(st.session_state.cost_info, dict):
            st.markdown(st.session_state.cost_info.get("content", ""))
            display_citations(st.session_state.cost_info.get("citations", []))
            cost_content = st.session_state.cost_info.get("content", "")
        else:
            st.markdown(st.session_state.cost_info)
            cost_content = st.session_state.cost_info
        
        # --- ADD TO PRESENTATION BUTTON ---
        st.markdown("---")
        _render_slide_button('cost_structure', st.session_state.cost_info, "cost")

    
             

#===========================================================    
# STRATEGIC FIT SECTION
# ============================================================

def render_strategic_fit():
    if len(st.session_state.companies) == 0:
            st.warning("⚠️ Run Competitive Analysis Section First")
    else:
        st.markdown('<div class="sub-header">🎯 Strategic Fit Analysis</div>', unsafe_allow_html=True)
        
        # --- USE PARSED PRODUCT OPTIONS ---
        # If Step 2 found specific product lines, use them. Otherwise fallback to company names.
        if st.session_state.product_options:
            dropdown_options = sorted(list(set(st.session_state.product_options))) # Dedupe and sort
            st.success(f"Found {len(dropdown_options)} specific product lines for comparison.")
        else:
            dropdown_options = st.session_state.companies
        
        c1, c2 = st.columns(2)
        
        comp_a = c1.selectbox("Benchmark (e.g. TSX Series)", dropdown_options, index=st.session_state.idx_a)
        comp_b = c2.selectbox("Challenger (e.g. Sample Prep)", dropdown_options, index=st.session_state.idx_b)
        
        st.session_state.idx_a = dropdown_options.index(comp_a)
        st.session_state.idx_b = dropdown_options.index(comp_b)

        st.write(comp_a, comp_b)


        if st.button("⚔️ Analyze Fit"):
            st.session_state.fit_data = None
            with st.spinner("Generating Strategic Fit analysis..."):
                st.session_state.fit_data = generate_strategic_fit(comp_a, comp_b, st.session_state.product)


        if st.session_state.fit_data is not None:
                fit_data = st.session_state.fit_data
                
                col_text, col_chart = st.columns([0.45, 0.55])
                with col_text:
                    st.markdown('<div class="red-header">Strategic Fit</div>', unsafe_allow_html=True)
                    st.markdown(f"**Comparison: {comp_a} vs {comp_b}**")
                    bullets = "".join([f"<li style='margin-bottom:10px;'>{b}</li>" for b in fit_data.get('strategy_text', [])])
                    st.markdown(f"""<div class="strategy-box"><ul>{bullets}</ul></div>""", unsafe_allow_html=True)
                with col_chart:
                    fig, ax = plt.subplots(figsize=(8, 5))
                    p_a = fit_data['prices'].get(comp_a, [0,0,0])
                    p_b = fit_data['prices'].get(comp_b, [0,0,0])
                    x_labels = fit_data['sizes']
                    min_len = min(len(x_labels), len(p_a), len(p_b))
                    ax.plot(x_labels[:min_len], p_a[:min_len], marker='o', linewidth=3, label=comp_a, color='#1f77b4')
                    ax.plot(x_labels[:min_len], p_b[:min_len], marker='o', linewidth=3, label=comp_b, color='#ff7f0e')
                    ax.set_title(f"Dealer Pricing Comparison", fontweight='bold')
                    ax.set_ylabel("Price ($)")
                    ax.set_ylim(bottom=0)
                    ax.yaxis.set_major_formatter(FuncFormatter(lambda x, p: f'${x:,.2f}'))
                    ax.grid(True, linestyle='--')
                    ax.legend()
                    st.pyplot(fig)
                    st.markdown(f"""<div class="grey-box" style="margin-top:20px; text-align:left; font-weight:normal;">{fit_data.get('highlight_box', '')}</div>""", unsafe_allow_html=True)
                
                st.session_state.strategic_fit_data = {
                        "comp_a": comp_a,
                        "comp_b": comp_b,
                        "fit_data": fit_data
                    }
                
        # ---DOWNLOAD FOR STEP 4 ---
        if st.session_state.strategic_fit_data is not None:
            st.markdown("---")
            sfd = st.session_state.strategic_fit_data
            fit = sfd["fit_data"]
            
            # Strategy Text DataFrame
            df_strategy = pd.DataFrame({
                "Bullet #": range(1, len(fit.get('strategy_text', [])) + 1),
                "Strategic Insight": fit.get('strategy_text', [])
            })
            
            # Pricing Comparison DataFrame
            sizes = fit.get('sizes', [])
            p_a = fit.get('prices', {}).get(sfd["comp_a"], [0, 0, 0])
            p_b = fit.get('prices', {}).get(sfd["comp_b"], [0, 0, 0])
            
            # --- WORD DOWNLOAD ---
            try:
                # Recreate line chart for Word export
                fig_word, ax_word = plt.subplots(figsize=(8, 5))
                min_len = min(len(sizes), len(p_a), len(p_b))
                ax_word.plot(sizes[:min_len], p_a[:min_len], marker='o', linewidth=3, 
                            label=sfd["comp_a"], color='#1f77b4')
                ax_word.plot(sizes[:min_len], p_b[:min_len], marker='o', linewidth=3, 
                            label=sfd["comp_b"], color='#ff7f0e')
                ax_word.set_title(f"{sfd['comp_a']} vs {sfd['comp_b']} - Dealer Pricing Comparison", 
                                    fontweight='bold')
                ax_word.set_xlabel("Size", fontsize=12, fontweight='bold')
                ax_word.set_ylabel("Price ($)", fontsize=12, fontweight='bold')
                ax_word.set_ylim(bottom=0)
                ax_word.yaxis.set_major_formatter(FuncFormatter(lambda x, p: f'${x:,.2f}'))
                ax_word.grid(True, linestyle='--')
                ax_word.legend()
                plt.tight_layout()
                
                # Create Word document sections
                sections = [
                    {"heading": "Strategic Fit Analysis", "style": "heading"},
                    {"content": f"Benchmark: {sfd['comp_a']}\nChallenger: {sfd['comp_b']}", "style": "paragraph"},
                    {"heading": "Strategic Insights", "style": "heading"},
                    {"content": fit.get('strategy_text', []), "style": "bullet"},
                    {"heading": "Key Takeaway", "style": "heading"},
                    {"content": fit.get('highlight_box', ''), "style": "paragraph"},
                ]
                
                word_buffer = export_to_word_with_chart(
                    title=f"Strategic Fit - {sfd['comp_a']} vs {sfd['comp_b']}",
                    sections=sections,
                    chart_figure=fig_word,
                    product_name=st.session_state.get('product', '')
                )
                plt.close(fig_word)
                
                st.download_button(
                    label="📄 Download Word Document",
                    data=word_buffer,
                    file_name=f"Step4_StrategicFit_{datetime.now().strftime('%Y%m%d_%H%M')}.docx",
                    mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                )
            except ImportError:
                st.warning("Install python-docx: `pip install python-docx`")
            except Exception as e:
                st.error(f"Word export error: {e}")


# ============================================================
# STAKEHOLDER ANALYSIS SECTION (UPDATED WITH LEGEND)
# ============================================================
def render_stakeholder_analysis():
    col1, col2 = st.columns([5,5])
    with col1:
        st.markdown('<div class="sub-header">👥 Stakeholder Analysis</div>', unsafe_allow_html=True)
    st.markdown("---")
    
    # Check if we have data
    if "stakeholder_rows" not in st.session_state or not st.session_state.stakeholder_rows:
        st.info("👋 Run the **QFD Pipeline** first to extract stakeholders from your documents.")
        return

    # Create DataFrame from the AI-generated rows
    df_stakeholders = pd.DataFrame(st.session_state.stakeholder_rows)
    
    
    # Reorder columns to match the slide pattern
    desired_cols = ["Type", "Title", "Responsibility", "Interaction", "Top_3_Requirements", "Source"]
    # Filter for columns that actually exist (safety check)
    cols_to_show = [c for c in desired_cols if c in df_stakeholders.columns]
    df_display = df_stakeholders[cols_to_show]

    # Display the Tabl
   
    st.markdown('<div class="red-header">Customer Needs Summary</div>', unsafe_allow_html=True)
    st.markdown(f"""<div class="card">{st.session_state.customer_needs}</div>""", unsafe_allow_html=True)

    st.markdown('<div class="red-header">Stakeholder Analysis Table</div>', unsafe_allow_html=True)
    st.dataframe(
        df_display,
        use_container_width=True,
        hide_index=True,
        column_config={
            "Type": st.column_config.TextColumn("Type", help="D=Decision Maker, I=Influencer", width="small"),
            "Title": st.column_config.TextColumn("Persona Title", width="medium"),
            "Top_3_Requirements": st.column_config.TextColumn("Key Requirements", width="large"),
            "Source": st.column_config.TextColumn("Source File", width="medium"),
        }
    )
    
    # --- LEGEND (ADDED HERE) ---
    st.markdown("**TYPE:** I = Influencer, D = Decision Maker")

    # --- DOWNLOAD BUTTON ---
    excel_buffer = export_to_excel({"Stakeholder Analysis": df_display})
    with col2:
        st.download_button(
            label="📥 Download Stakeholder Analysis (Excel)",
            data=excel_buffer,
            file_name=f"Stakeholder_Analysis_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True
        )
    st.markdown("---")


# ============================================================
# VOC SLIDE RENDERER (UPDATED: BUTTON AT TOP)
# ============================================================
def render_voc_slide():
    col1, col2 = st.columns([5,5])
    with col1:
        st.markdown('<div class="sub-header">📢 Voice of Customer Summary</div>', unsafe_allow_html=True)
    
    if not st.session_state.specs_list:
        st.warning("⚠️ No data available. Please run the QFD Pipeline first.")
        return

    # --- PREPARE DOWNLOAD DATA (MOVED TO TOP) ---
    # 1. Create Clean DataFrame for Export
    df_voc = pd.DataFrame(st.session_state.specs_list)
    
    # Rename columns to match the Slide Headers for the Excel file
    export_cols = {
        "Product_Requirement": "Customer Feedback (What they want)",
        "Specification_details": "Key Customer Issues (Why they want it)",
        "Technical_Specification": "Critical Customer Requirements (Engineering Target)",
        "Kano_Category": "Kano Category" 
    }
    
    # Filter to ensure columns exist 
    available_cols = {k: v for k, v in export_cols.items() if k in df_voc.columns}
    df_export = df_voc[list(available_cols.keys())].rename(columns=available_cols)
    
    # 2. Generate Buffer
    excel_buffer = export_to_excel({"VOC Summary": df_export})
    
    # 3. Render Button
    # col_btn, col_empty = st.columns([1, 4]) # Use columns to keep button from spanning full width if desired
    with col2:
        st.download_button(
            label="📥 Download VOC Summary (Excel)",
            data=excel_buffer,
            file_name=f"VOC_Summary_Slide_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True
        )
    
    st.markdown("---")

    # --- CUSTOM CSS FOR SLIDE REPLICATION ---
    st.markdown("""
    <style>
        .voc-header {
            background-color: #6b7280; /* Grey header from slide */
            color: white;
            padding: 10px;
            font-weight: bold;
            text-align: center;
            border-radius: 5px 5px 0 0;
            font-size: 1.1rem;
        }
        .voc-sub {
            background-color: #f3f4f6;
            color: #1f2937;
            padding: 8px;
            font-size: 0.85rem;
            text-align: center;
            border-bottom: 2px solid #e5e7eb;
            min-height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .voc-col {
            border: 1px solid #e5e7eb;
            background-color: white;
            padding: 15px;
            height: 100%;
        }
        .voc-item {
            margin-bottom: 12px;
            padding-bottom: 12px;
            border-bottom: 1px solid #eee;
        }
        .voc-item:last-child { border-bottom: none; }

    </style>
    """, unsafe_allow_html=True)

    # --- 3 COLUMN LAYOUT ---
    c1, c2, c3 = st.columns(3)

    # --- COLUMN 1: Customer Feedback ---
    with c1:
        st.markdown('<div class="voc-header">Customer Feedback</div>', unsafe_allow_html=True)
        st.markdown('<div class="voc-sub">What Does the Customer Want From Us?</div>', unsafe_allow_html=True)
        
        with st.container():
            html_content = '<div class="voc-col">'
            for item in st.session_state.specs_list:
                html_content += f'<div class="voc-item">🔹 <b>{item["Product_Requirement"]}</b></div>'
            html_content += '</div>'
            st.markdown(html_content, unsafe_allow_html=True)

    # --- COLUMN 2: Key Customer Issues ---
    with c2:
        st.markdown('<div class="voc-header">Key Customer Issue(s)</div>', unsafe_allow_html=True)
        st.markdown('<div class="voc-sub">Identify the Issue(s) that Prevent Us From Satisfying Our Customers</div>', unsafe_allow_html=True)
        
        with st.container():
            html_content = '<div class="voc-col">'
            for item in st.session_state.specs_list:
                html_content += f'<div class="voc-item">🔸 {item["Specification_details"]}</div>'
            html_content += '</div>'
            st.markdown(html_content, unsafe_allow_html=True)

    # --- COLUMN 3: Critical Requirements ---
    with c3:
        st.markdown('<div class="voc-header">Critical Customer Requirements</div>', unsafe_allow_html=True)
        st.markdown('<div class="voc-sub">Translate Issues into Specific and Measurable Requirements</div>', unsafe_allow_html=True)
        
        with st.container():
            html_content = '<div class="voc-col">'
            for item in st.session_state.specs_list:
                html_content += f'<div class="voc-item"><div class="red-box">🔺 {item["Technical_Specification"]}</div></div>'
            html_content += '</div>'
            st.markdown(html_content, unsafe_allow_html=True)



# ============================================================
# MAIN APPLICATION
# ============================================================
def main():
    """Main application"""
    # Apply custom CSS
    st.markdown(CUSTOM_CSS, unsafe_allow_html=True)
    
    st.markdown('<div class="main-header">📊 Voice of Customer (VOC) / Voice of Sales (VOS) Analytics</div>', unsafe_allow_html=True)
    st.markdown("---")
    
    # Sidebar
    uploaded_zip, manual_input, uploaded_file = render_sidebar()
    
    # Main content
    if st.session_state.expand_qfd:
        render_qfd_section(uploaded_zip, manual_input, uploaded_file)
    elif st.session_state.get("voc_slide", False): # <--- ADD THIS BLOCK
        render_voc_slide()
    elif st.session_state.get("stakeholder_analysis", False):
        render_stakeholder_analysis()
    elif st.session_state.market_analysis:
        market_insights()
    elif st.session_state.competitive_analysis:
        render_competitive_analysis()

    elif st.session_state.new_competitive_analysis:
        render_new_competitive_analysis()
    
    elif st.session_state.strategic_fit:
        render_strategic_fit()
    
    
    else:
        st.info("👈 Select a module from the sidebar")


if __name__ == "__main__":
    main()