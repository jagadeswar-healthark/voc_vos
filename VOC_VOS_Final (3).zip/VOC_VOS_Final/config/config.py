# config.py

LLM_MODEL = "gpt-4o-mini"

DATA_DIR = "data/raw_inputs"
OUTPUT_CLASSIFIED = "outputs/classified.xlsx"
OUTPUT_REQUIREMENTS = "outputs/requirements.xlsx"
