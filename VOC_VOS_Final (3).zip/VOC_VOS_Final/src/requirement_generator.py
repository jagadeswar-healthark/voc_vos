import json
import os
import re
import pandas as pd
import xlsxwriter
import matplotlib.pyplot as plt
import plotly.graph_objects as go
import numpy as np
from openai import OpenAI
from src.llm_client import get_azure_client
from dotenv import load_dotenv

load_dotenv()

client = get_azure_client()
API_KEY = "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" # <--- PASTE KEY HERE
client = OpenAI(api_key=API_KEY)

DEPLOYMENT_NAME = os.getenv("AZURE_DEPLOYMENT_NAME")

print("Using deployment:", DEPLOYMENT_NAME)

def safe_json_loads(text: str) -> dict:
    """Extracts and parses the first JSON object from LLM output."""
    match = re.search(r"\{[\s\S]*\}", text)
    if not match:
        raise ValueError("No JSON object found in LLM response")
    return json.loads(match.group())

# --- 1. KANO GRAPH GENERATOR (UPDATED: LEGEND ON RIGHT) ---
def create_kano_chart(requirements_list, categories_list, output_filename="Kano_Analysis_Graph.png"):
    print("📊 Generating Kano Analysis Graph (Static & Interactive)...")
    
    # ==========================================
    # PART A: MATPLOTLIB (For Excel Export File)
    # ==========================================
    fig_static, ax = plt.subplots(figsize=(14, 8))
    ax.set_xlim(0, 1)
    ax.set_ylim(-1, 1)
    ax.axhline(0, color='black', linewidth=1, alpha=0.5) 
    ax.axvline(0, color='black', linewidth=1, alpha=0.5)
    ax.text(1.02, 0, 'Functionality', va='center', ha='left', fontsize=10, style='italic')
    ax.text(0, 1.02, 'Satisfaction', va='bottom', ha='center', fontsize=10, style='italic')
    
    x = np.linspace(0.05, 0.95, 100)
    y_must = -0.9 * np.exp(-3 * x) - 0.1
    ax.plot(x, y_must, color='#D9534F', linestyle='--', linewidth=2, label='Must-Be')
    y_perf = 1.6 * x - 0.8
    ax.plot(x, y_perf, color='#5BC0DE', linestyle='-', linewidth=2, label='Performance')
    y_delight = 0.9 * np.exp(2 * (x - 1)) + 0.1
    ax.plot(x, y_delight, color='#5CB85C', linestyle='-.', linewidth=2, label='Delighter')

    # Data Processing for Positioning
    zipped_data = sorted(zip(requirements_list, categories_list), key=lambda pair: pair[1])
    count_map = {"Must-Be": 0, "Performance": 0, "Delighter": 0}
    total_map = {"Must-Be": 0, "Performance": 0, "Delighter": 0}
    for _, cat in zipped_data:
        key = "Performance"
        if "Must" in cat: key = "Must-Be"
        elif "Delight" in cat: key = "Delighter"
        total_map[key] += 1

    # Plot Dots (Static)
    for i, (req, cat) in enumerate(zipped_data):
        dot_label = str(i + 1)
        if "Must" in cat:
            cat_key, color = "Must-Be", '#D9534F'
            x_pos = 0.2 + (0.6 * (count_map[cat_key] / (total_map[cat_key] + 1)))
            y_pos = -0.9 * np.exp(-3 * x_pos) - 0.1
        elif "Delight" in cat:
            cat_key, color = "Delighter", '#5CB85C'
            x_pos = 0.2 + (0.6 * (count_map[cat_key] / (total_map[cat_key] + 1)))
            y_pos = 0.9 * np.exp(2 * (x_pos - 1)) + 0.1
        else:
            cat_key, color = "Performance", '#5BC0DE'
            x_pos = 0.2 + (0.6 * (count_map[cat_key] / (total_map[cat_key] + 1)))
            y_pos = 1.6 * x_pos - 0.8
        
        count_map[cat_key] += 1
        ax.scatter(x_pos, y_pos, color=color, s=500, zorder=5, edgecolor='white', linewidth=1.5)
        ax.text(x_pos, y_pos, dot_label, color='white', fontweight='bold', fontsize=10, ha='center', va='center', zorder=10)

    # Save Static File
    ax.grid(True, linestyle=':', alpha=0.4)
    plt.savefig(output_filename, dpi=150, bbox_inches='tight')
    plt.close()

    # ==========================================
    # PART B: PLOTLY (For Interactive UI)
    # ==========================================
    fig_interactive = go.Figure()

    # 1. Add Curves
    x_plot = np.linspace(0.05, 0.95, 100)
    fig_interactive.add_trace(go.Scatter(x=x_plot, y=-0.9 * np.exp(-3 * x_plot) - 0.1, mode='lines', name='Must-Be', line=dict(color='#D9534F', dash='dash')))
    fig_interactive.add_trace(go.Scatter(x=x_plot, y=1.6 * x_plot - 0.8, mode='lines', name='Performance', line=dict(color='#5BC0DE')))
    fig_interactive.add_trace(go.Scatter(x=x_plot, y=0.9 * np.exp(2 * (x_plot - 1)) + 0.1, mode='lines', name='Delighter', line=dict(color='#5CB85C', dash='dot')))

    # 2. Add Dots & Build Side Legend
    count_map = {"Must-Be": 0, "Performance": 0, "Delighter": 0}
    x_vals, y_vals, texts, hover_texts, colors = [], [], [], [], []
    legend_items = [] # Store text for the side panel

    for i, (req, cat) in enumerate(zipped_data):
        dot_label = str(i + 1)
        
        # Build Legend Text (e.g., "1. Leak Proof Cap")
        # Shorten text if too long for the side bar
        display_req = (req[:35] + '...') if len(req) > 35 else req
        legend_items.append(f"<b>{dot_label}.</b> {display_req}")

        if "Must" in cat:
            cat_key, color = "Must-Be", '#D9534F'
            x_pos = 0.2 + (0.6 * (count_map[cat_key] / (total_map[cat_key] + 1)))
            y_pos = -0.9 * np.exp(-3 * x_pos) - 0.1
        elif "Delight" in cat:
            cat_key, color = "Delighter", '#5CB85C'
            x_pos = 0.2 + (0.6 * (count_map[cat_key] / (total_map[cat_key] + 1)))
            y_pos = 0.9 * np.exp(2 * (x_pos - 1)) + 0.1
        else:
            cat_key, color = "Performance", '#5BC0DE'
            x_pos = 0.2 + (0.6 * (count_map[cat_key] / (total_map[cat_key] + 1)))
            y_pos = 1.6 * x_pos - 0.8
            
        count_map[cat_key] += 1
        
        x_vals.append(x_pos)
        y_vals.append(y_pos)
        texts.append(dot_label)
        colors.append(color)
        hover_texts.append(f"<b>#{dot_label}: {req}</b><br>Category: {cat}")

    # Add the dots trace
    fig_interactive.add_trace(go.Scatter(
        x=x_vals, y=y_vals,
        mode='markers+text',
        text=texts,
        textfont=dict(color='white', size=12, family="Arial Black"),
        hoverinfo='text',
        hovertext=hover_texts,
        marker=dict(size=35, color=colors, line=dict(color='white', width=2)),
        showlegend=False
    ))

    # 3. Create the Side Legend Text
    legend_str = "<br>".join(legend_items)

    # 4. Layout Styling with Right Margin for Legend
    fig_interactive.update_layout(
        title="<b>Kano Model Analysis</b>",
        xaxis=dict(title="Functionality (Implementation)", range=[0, 1], showgrid=True),
        yaxis=dict(title="Customer Satisfaction", range=[-1, 1], showgrid=True),
        height=600,
        template="plotly_white",
        
        # --- MARGIN FOR LEGEND ---
        margin=dict(r=300), # Reserve 300px on the right for text
        
        shapes=[
            dict(type="line", x0=0, x1=1, y0=0, y1=0, line=dict(color="black", width=1, dash="dot")),
            dict(type="line", x0=0, x1=0, y0=-1, y1=1, line=dict(color="black", width=1, dash="dot"))
        ],
        
        # --- ANNOTATION (THE LEGEND) ---
        annotations=[
            dict(
                text=legend_str,
                x=1.05,          # Position slightly outside the right edge of plot
                y=1,             # Align to top
                xref="paper",
                yref="paper",
                showarrow=False,
                align="left",
                valign="top",
                font=dict(size=12, color="black"),
                bordercolor="#e5e7eb",
                borderwidth=1,
                bgcolor="#f9fafb",
                xanchor="left",  # Anchor text box by its left side
                yanchor="top"    # Anchor text box by its top
            )
        ]
    )

    return output_filename, fig_interactive

def generate_requirement(input_text, product_name="Generic Product"):
    system_prompt = """You are a Technical Specification Generator and Kano Analyst.
You MUST produce identical output for identical inputs.
Output ONLY valid JSON. No markdown, no explanations."""

    user_prompt = f"""Input: {input_text}
Product Name: {product_name}

CRITICAL RULES FOR CONSISTENCY:
1. Process requirements in alphabetical order by their first keyword
2. Use EXACT wording from the rubric below - no synonyms
3. When multiple categories apply, choose the FIRST applicable one in document order
4. Empty cells MUST be empty string "", never null or omitted

TASK:
Extract distinct engineering requirements. For each:

1. Product_Requirement: 
   - Max 6 words, technical noun phrase
   - Use format: [Adjective] + [Technical Noun]
   - Example: "Leak-proof cap design"

2. Specification_details:
   - State the CUSTOMER PROBLEM, not the solution
   - Format: "[Problem statement] causing [consequence]"
   - Example: "Caps leak during transport, causing contamination risk"
   - NOT: "Ensures no leakage" (this is a benefit)

3. Technical_Specification:
   - Measurable engineering target
   - Format: "[Parameter] [Operator] [Value] [Unit]"
   - Example: "Leak rate < 0.1 mL/hour at 2 bar"

4. Kano_Category (Choose EXACTLY one):

    Select one category that best represents how this feature or requirement affects user satisfaction.

    Must-Be
    Fundamental and non-negotiable expectations. If missing, users will be dissatisfied. If present, users consider it normal and do not explicitly praise it. Typically related to safety, compliance, reliability, hygiene, and basic correctness.
    Examples: mandatory safety warnings, regulatory compliance, basic authentication, data privacy controls, error-free operation.

    Performance
    Satisfaction increases or decreases proportionally with how well the feature performs. Better performance directly leads to higher satisfaction; poor performance leads to dissatisfaction. Usually related to speed, accuracy, throughput, capacity, scalability, or efficiency.
    Examples: faster response time, higher accuracy predictions, larger storage limits, lower latency.

    Delighter
    Unexpected or innovative features that users do not explicitly demand but feel pleasantly surprised by when present. These create differentiation and excitement. Often driven by AI, automation, intelligence, or novel user experiences.
    Examples: automatic insight generation, proactive recommendations, self-healing workflows, intelligent copilots.

    Instruction:
    Return only one of the following values exactly: "Must-Be", "Performance", or "Delighter".

RELATIONSHIP MATRIX SCORING:
Use this EXACT decision tree for each cell. Score in priority order:

H (High/9) - SHOWSTOPPER:
├─ Safety: Injury, contamination, regulatory violation
├─ Function: Primary task impossible
└─ Return: Customer returns product immediately

M (Medium/3) - DEGRADATION:
├─ Friction: Task takes 2x+ longer
├─ Workaround: User must adapt workflow
└─ Complaint: Customer complains but continues use

L (Low/1) - MINOR:
├─ Aesthetic: Cosmetic only
├─ Annoyance: Noticed but no workflow impact
└─ Wish: "Nice to have" future request

"" (Empty) - NO RELATIONSHIP:
Use when the requirement has zero impact on this category

CATEGORY-SPECIFIC TRIGGERS (Apply ONLY these exact mappings):

Quality:
- Description: Physical build condition of the product, including material strength, manufacturing finish, and assembly integrity.
- H: Leaks, cracks, breaks, cannot assemble, non-functional
- M: Rough edges, tight fit, flashing, requires force
- L: Surface scratches, color variance, minor cosmetic
- "": No material/build quality impact

Performance:
- Description: How well the product performs its intended function in terms of accuracy, speed, stability, and output.
- H: Wrong output, motor stops, data loss, function fails
- M: Slow (>2x expected), noisy, high power draw
- L: Minor lag, confusing menu, long boot time
- "": No speed/accuracy/output impact

Safety & Regulatory:
-Description: Any indication of safety risk, hazard, or regulatory and compliance relevance.
- H: Contains "risk", "danger", "sterile", "compliance", "certified", "FDA", "CE"
- M: Ergonomic strain, repetitive stress (long-term risk)
- L: Label font size, warning sticker placement
- "": No safety/regulatory mention

Ease of Use:
- Description: How easily a typical user can operate, understand, and handle the product.
- H: User cannot operate without training, impossible to figure out
- M: "Hard to open", "tips fall off", "heavy to carry"
- L: "Buttons feel cheap", "screen small", "no visual feedback"
- "": No user interaction impact

Reliability:
- Description: The expected durability and consistent performance of the product over time under normal usage conditions.
- H: Fails within warranty, <100 cycles, breaks during normal use
- M: Needs frequent cleaning, monthly maintenance, consumable replacement
- L: Calibration drift over years, minor wear acceptable
- "": No durability/longevity impact

Cost:
- Description: Financial implications of the product including purchase price, operational costs, and maintenance expenses.
- H: Exceeds budget cap, capital expense rejected, unaffordable consumables
- M: High maintenance cost, high energy cost (OpEx burden)
- L: Higher shipping, accessories cost than expected
- "": No cost impact mentioned

Storage Capacity:
- Description: The physical space requirements and volume capacity of the product for storage and usage.
- H: Does not fit space, cannot hold minimum volume, too large for use case
- M: Inefficient shape wastes space, hard to stack, awkward dimensions
- L: Packaging slightly bulky but manageable
- "": No storage/space impact

Appearance:
- Description: The visual aesthetics and design appeal of the product as perceived by users.
- H: Looks dirty/contaminated, rust/corrosion on arrival
- M: Looks outdated vs. market, cheap appearance affects perception
- L: Logo misalignment, color preference, finish preference
- "": No visual impact

Market:
- Description: Competitive positioning and market acceptance factors affecting product success.
- H: Competitor has superior critical feature, missing industry standard
- M: Long lead times (>4 weeks), stock unavailable, market share loss
- L: Marketing lacks detail, website navigation issues
- "": No competitive/market impact

Logistics:
- Description: Shipping, delivery, and supply chain considerations affecting product availability.
- H: Damaged in transit (unusable), missed critical deadline
- M: Difficult disposal, split shipments causing delays
- L: Tracking delay, minor box damage (product intact)
- "": No shipping/delivery impact

Sustainability:
- Description: Environmental impact and eco-friendliness of the product throughout its lifecycle.
- H: Violates green mandate, contains banned substances, regulatory issue
- M: High plastic waste, excessive energy (institutional concern)
- L: Non-recyclable packaging (if not mandated)
- "": No environmental impact mentioned

OUTPUT FORMAT (valid JSON only):
{{
  "QFD_Entries": [
    {{
      "Product_Requirement": "Leak-proof cap design",
      "Specification_details": "Caps leak during transport, causing contamination and product loss",
      "Technical_Specification": "Leak rate < 0.1 mL/hour at 2 bar pressure",
      "Kano_Category": "Must-Be",
      "Relationship_Matrix": {{
        "Quality": "H",
        "Performance": "",
        "Safety & Regulatory": "H",
        "Ease of Use": "M",
        "Reliability": "H",
        "Cost": "",
        "Storage Capacity": "",
        "Appearance": "",
        "Market": "",
        "Logistics": "M",
        "Sustainability": ""
      }}
    }}
  ]
}}

CONSISTENCY CHECKLIST (verify before responding):
☐ All requirements processed in alphabetical order
☐ All matrix cells filled (H/M/L/"" only, no null)
☐ Exact rubric wording used (no paraphrasing)
☐ Specification_details states problem, not solution
☐ Technical_Specification has measurable target
☐ Valid JSON syntax (no trailing commas, proper quotes)
"""

    response = client.chat.completions.create(
        model=DEPLOYMENT_NAME,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        temperature=0.0,      # ← Changed from 0.2
        seed=42,
        top_p=1.0,            # ← Added for determinism
        response_format={"type": "json_object"}
    )

    raw_text = response.choices[0].message.content
    try:
        return safe_json_loads(raw_text), response.usage.total_tokens
    except Exception:
        return {"QFD_Entries": []}, 0


# --- 3. GENERATE ROOF ---
def generate_qfd_roof(roof_cols):
    if not roof_cols: return []
    
    numbered_list = "\n".join([f"{i}. {col}" for i, col in enumerate(roof_cols)])
    
    QFD_ROOF_PROMPT = """
 *** SYSTEM ROLE ***
      You are a Lead Systems Architect with 20 years of experience in hardware product design. 
      Your specialty is identifying engineering trade-offs (conflicts) and synergies (opportunities).

      *** INPUT ***
      You will be provided with a numbered list of "Technical Product Requirements" (The HOWs).

      *** TASK ***
      Perform a Pairwise Correlation Analysis on this list.
      For every unique pair of requirements, determine how improving one impacts the other.

      *** THE CORRELATION RUBRIC (Use ALL 5 symbols) ***

      1. **(++) Strong Positive / Synergy**
        - Definition: Improving A *automatically* improves B due to shared physics or subsystems.
        - Example: "Better Thermal Insulation" ++ "Lower Energy Consumption".

      2. **(+) Positive / Supportive**
        - Definition: Improving A makes it easier to achieve B, but they are not identical.
        - Example: "Standardized Parts" + "Serviceability".

      3. **(0) None / Independent**
        - Definition: A and B are orthogonal. Changing A has no measurable effect on B.
        - Example: "Chassis Color" 0 "Data Upload Speed".

      4. **(-) Negative / Minor Trade-off**
        - Definition: Improving A adds friction or cost to B, but it can be managed.
        - Example: "Robust Security Lock" - "Door Opening Speed".

      5. **(--) Strong Negative / Critical Conflict**
        - Definition: Improving A directly opposes B based on laws of physics or geometry.
        - Example: "Maximize Internal Capacity" -- "Minimize External Dimensions".
        - Example: "Minimize Unit Cost" -- "Maximize Premium Materials".

      *** INSTRUCTIONS ***
      1. Analyze the list.
      2. Use "0" for unrelated pairs (approx 30%).
      3. Identify "Negative" trade-offs (approx 10-15%).
      4. Return the result as a JSON list using the ID numbers provided.

      *** OUTPUT FORMAT (json)***
      {
        "Roof_Correlations": [
          {"ID_A": 0, "ID_B": 1, "Val": "++", "Reason": "Both rely on thermal efficiency."},
          {"ID_A": 2, "ID_B": 5, "Val": "--", "Reason": "Higher speed generates more noise."},
          {"ID_A": 3, "ID_B": 4, "Val": "0", "Reason": "No connection."}
        ]
      }
      """
    
    try:
        response = client.chat.completions.create(
            model=DEPLOYMENT_NAME,
            messages=[
                {"role": "system", "content": QFD_ROOF_PROMPT},
                {"role": "user", "content": f"Analyze:\n{numbered_list}"}
            ],
            response_format={"type": "json_object"},
            temperature=0.0, seed=42
        )
        return json.loads(response.choices[0].message.content).get("Roof_Correlations", [])
    except Exception as e:
        print(f"❌ Error roof: {e}")
        return []
# src/requirement_generator.py

# ... [Keep all existing imports and functions] ...

def analyze_stakeholder_persona(text, filename):
    """
    Analyzes a text document to build a 'Stakeholder Profile' row 
    matching the Thermo Fisher slide format.
    """
    system_prompt = "You are a B2B Market Researcher creating a Buying Center Analysis."
    
    user_prompt = f"""
    Analyze the following feedback text from the file '{filename}'.
    
    *** TEXT CONTENT ***
    {text}
    
    *** TASK ***
    Reverse-engineer the 'Persona' of the person who provided this feedback.
    Fill out the following columns for a Stakeholder Table:

    1. **Type**: Is this person a 'D' (Decision Maker/Check Signer), 'I' (Influencer/User), or 'I/D' (Both)?
       - Hint: 'Purchasing' or 'PI' is usually D. 'Students' or 'Facilities' are usually I.
    2. **Title**: Best guess at their job title (e.g., Principal Investigator, Lab Manager, Purchasing Agent).
    3. **Responsibility**: What is their core job function relative to the lab/product?
    4. **Interaction**: How do they interact with the product? (e.g., "Daily user", "Maintenance only", "Non-user/Buyer").
    5. **Top 3 Requirements**: The top 3 specific things they care about in this text (e.g., "Price", "Sterility", "Sustainability").

    *** OUTPUT FORMAT (JSON) ***
    {{
        "Type": "I/D",
        "Title": "...",
        "Description": "...",
        "Responsibility": "...",
        "Interaction": "...",
        "Top_3_Requirements": "1. ...\\n2. ...\\n3. ..."
    }}
    """

    try:
        response = client.chat.completions.create(
            model=DEPLOYMENT_NAME,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.1,
            response_format={"type": "json_object"}
        )
        return safe_json_loads(response.choices[0].message.content)
    except Exception as e:
        print(f"Error profiling {filename}: {e}")
        return None
    
def customer_need(pdf_text, product_name=""):
    system_prompt = """
    You are an AI that helps generate customer feedback insights based on provided customer feedback, survey data, and voice of customer (VOC) inputs. Your task is to analyze the input data for the given product categorize the main issues . Based on the provided text, identify the top 5 key categories related to the market and for each category, provide 2 to 3 concise problem statements that customers or stakeholders have highlighted.
    """

    user_prompt = f"""
    Analyze the  product feedbak '{product_name}' . Based on the provided customer feedback, survey responses, and VOC data, identify the top 5 categories of problem  and list 2 to 3 specific problem statements under each category. 
    Text: {pdf_text}
    """

    response = client.chat.completions.create(
        model=DEPLOYMENT_NAME,
        messages=[{"role": "system", "content": system_prompt},
                  {"role": "user", "content": user_prompt}],
        temperature=0.1,
        seed=42,
    )
    return response.choices[0].message.content

# --- 4. WRITE EXCEL HOUSE (ADVANCED) ---
# --- 4. WRITE EXCEL HOUSE (UPDATED: FIXED IMAGE OVERLAP) ---
def write_excel_house(df_body, roof_data, roof_cols, score_df, specs_list, kano_map, OUTPUT_EXCEL_NAME="Final_QFD_Output.xlsx", kano_image_path=None):
    score_df = score_df.fillna("")
    score_df = score_df.replace([float('inf'), float('-inf')], ["INF", "-INF"])
    writer = pd.ExcelWriter(OUTPUT_EXCEL_NAME, engine='xlsxwriter')
    workbook = writer.book
    worksheet = workbook.add_worksheet("House of Quality")

    # --- FORMATS ---
    fmt_header_rot = workbook.add_format({'rotation': 90, 'bold': True, 'align': 'center', 'valign': 'bottom', 'border': 1, 'bg_color': '#D9E1F2'})
    fmt_header_row = workbook.add_format({'bold': True, 'align': 'left', 'valign': 'vcenter', 'border': 1, 'bg_color': '#D9E1F2'})
    fmt_center = workbook.add_format({'align': 'center', 'valign': 'vcenter', 'border': 1})
    fmt_large_label = workbook.add_format({'bold': True, 'align': 'right', 'valign': 'bottom', 'font_size': 14, 'font_color': '#203764'})
    fmt_score_total = workbook.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter', 'border': 1, 'bg_color': '#4472C4', 'font_color': 'white'})
    fmt_roof_title = workbook.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter', 'bg_color': '#4472C4', 'font_color': 'white'})
    
    fmt_strong_pos = workbook.add_format({'align': 'center', 'valign': 'vcenter', 'bold': True, 'bg_color': '#00B050', 'font_color': 'white', 'border': 1})
    fmt_pos = workbook.add_format({'align': 'center', 'valign': 'vcenter', 'bold': True, 'bg_color': '#92D050', 'border': 1})
    fmt_neg = workbook.add_format({'align': 'center', 'valign': 'vcenter', 'bold': True, 'bg_color': '#FFC000', 'border': 1})
    fmt_strong_neg = workbook.add_format({'align': 'center', 'valign': 'vcenter', 'bold': True, 'bg_color': '#FF0000', 'font_color': 'white', 'border': 1})
    fmt_none = workbook.add_format({'align': 'center', 'valign': 'vcenter', 'bg_color': '#FFFFFF', 'border': 1})
    
    fmt_red = workbook.add_format({'bg_color': '#FFC7CE', 'font_color': '#9C0006', 'align': 'center', 'border': 1}) 
    fmt_yellow = workbook.add_format({'bg_color': '#FFEB9C', 'font_color': '#9C5700', 'align': 'center', 'border': 1})
    fmt_green = workbook.add_format({'bg_color': '#C6EFCE', 'font_color': '#006100', 'align': 'center', 'border': 1})

    fmt_kano_M = workbook.add_format({'align': 'center', 'valign': 'vcenter', 'font_size': 8, 'bold': True, 'border': 1, 'bg_color': '#FFCCCC', 'font_color': '#9C0006'}) 
    fmt_kano_P = workbook.add_format({'align': 'center', 'valign': 'vcenter', 'font_size': 8, 'bold': True, 'border': 1, 'bg_color': '#CCFFCC', 'font_color': '#006100'}) 
    fmt_kano_D = workbook.add_format({'align': 'center', 'valign': 'vcenter', 'font_size': 8, 'bold': True, 'border': 1, 'bg_color': '#CCFFFF', 'font_color': '#0000FF'}) 
    
    fmt_legend_header = workbook.add_format({'bold': True, 'font_size': 11, 'bottom': 1})
    fmt_legend_item = workbook.add_format({'font_size': 10})

    # Layout Setup
    num_cols = len(roof_cols)
    col_width = 2
    col_start_data = 2 
    roof_height = num_cols
    start_row_headers = roof_height + 2
    start_row_kano = start_row_headers + 1 
    start_row_body = start_row_kano + 1
    
    worksheet.write(start_row_headers, 0, "Customer Expectations", fmt_header_row)
    worksheet.merge_range(start_row_headers - 1, col_start_data, start_row_headers - 1, col_start_data + 10, "PRODUCT REQUIREMENTS ->", fmt_large_label)

    # ROOF Construction
    roof_map = {}
    roof_reasons = {}
    for item in roof_data:
        try:
            id_a, id_b = int(item['ID_A']), int(item['ID_B'])
            key = (min(id_a, id_b), max(id_a, id_b))
            roof_map[key] = item['Val']
            roof_reasons[key] = item.get('Reason', '')
        except: continue

    worksheet.merge_range(0, 0, 0, col_start_data + (num_cols * col_width) - 1, "ROOF: Correlation Matrix", fmt_roof_title)
    
    for diag in range(1, num_cols):
        roof_row = roof_height - diag + 1
        for k in range(num_cols - diag):
            col_i, col_j = k, k + diag
            key = (col_i, col_j)
            val = roof_map.get(key, "0")
            reason = roof_reasons.get(key, "")
            
            if val == "++": cfmt = fmt_strong_pos
            elif val == "+": cfmt = fmt_pos
            elif val == "-": cfmt = fmt_neg
            elif val == "--": cfmt = fmt_strong_neg
            else: cfmt, val = fmt_none, "0"
            
            excel_col = col_start_data + col_i * col_width + 1
            cell_col = excel_col + (diag - 1)
            worksheet.write(roof_row, cell_col, val, cfmt)
            
            if (val != "0" and val != "") or reason:
                worksheet.write_comment(roof_row, cell_col, f"Pair: {roof_cols[col_i]} vs {roof_cols[col_j]}\nVal: {val}\nReason: {reason}", {'width': 250, 'height': 100})

    # Headers & Kano Row
    worksheet.set_row(start_row_headers, 200) 
    for i, col_name in enumerate(roof_cols):
        col_pos = col_start_data + i * col_width
        worksheet.merge_range(start_row_headers, col_pos, start_row_headers, col_pos + col_width - 1, f"{i+1}. {col_name}", fmt_header_rot)
        
        cat = kano_map.get(col_name, "Performance")
        if "Must" in cat: k_fmt = fmt_kano_M
        elif "Delight" in cat: k_fmt = fmt_kano_D
        else: k_fmt = fmt_kano_P
        worksheet.merge_range(start_row_kano, col_pos, start_row_kano, col_pos + col_width - 1, cat, k_fmt)

    worksheet.write(start_row_kano, 0, "KANO CATEGORY", fmt_header_row)
    worksheet.write(start_row_kano, 1, "", fmt_center)

    # Body & Scoring
    score_map = {"H": 9, "M": 3, "L": 1, "": 0, "None": 0}
    importance_values = { "Quality": 5, "Performance": 5, "Safety & Regulatory": 5, "Ease of Use": 4, "Reliability": 5, "Cost": 4, "Storage Capacity": 3, "Appearance": 2, "Market": 2, "Logistics": 1, "Sustainability": 3 }
    
    worksheet.write(start_row_headers, 1, "Importance", fmt_header_rot)
    
    row_sums = []
    col_sums = [0] * num_cols 
    
    for r, exp in enumerate(df_body.index): 
        worksheet.write(start_row_body + r, 0, exp, fmt_header_row)
        imp = importance_values.get(exp, 3)
        worksheet.write(start_row_body + r, 1, imp, fmt_center)
        
        row_score = 0
        for c, req in enumerate(roof_cols):
            val_text = df_body.at[exp, req]
            if pd.isna(val_text) or str(val_text).strip() == "None": 
                val_text = ""
            
            cfmt = fmt_center
            if val_text == "H": cfmt = fmt_red
            elif val_text == "M": cfmt = fmt_yellow
            elif val_text == "L": cfmt = fmt_green
            else: cfmt = fmt_center
            
            row_score += imp * score_map.get(val_text, 0)
            c_pos = col_start_data + c * col_width
            worksheet.merge_range(start_row_body + r, c_pos, start_row_body + r, c_pos + col_width - 1, val_text, cfmt)
        
        row_sums.append(row_score)
        
    end_col = col_start_data + num_cols * col_width
    worksheet.write(start_row_headers, end_col, "Row Score", fmt_header_rot)
    for r, score in enumerate(row_sums):
        worksheet.write(start_row_body + r, end_col, score, fmt_center)

    # Total Weighted Score
    total_row_idx = start_row_body + len(df_body.index)
    worksheet.write(total_row_idx, 0, "Total Weighted Score", fmt_score_total)
    
    col_weighted_sums = []
    for c, req in enumerate(roof_cols):
        col_weighted_sum = 0
        for r, exp in enumerate(df_body.index):
            imp = importance_values.get(exp, 3)
            val_text = df_body.at[exp, req]
            col_weighted_sum += (imp * score_map.get(val_text, 0))
            
        col_weighted_sums.append(col_weighted_sum)
        c_pos = col_start_data + c * col_width
        worksheet.merge_range(total_row_idx, c_pos, total_row_idx, c_pos + col_width - 1, col_weighted_sum, fmt_score_total)

    worksheet.set_column(0, 0, 30)
    worksheet.set_column(col_start_data, end_col, 4)
    
    # --- INSERT KANO IMAGE & INDEX LIST (UPDATED) ---
    if kano_image_path and os.path.exists(kano_image_path):
        image_col = end_col + 2
        
        # 1. Insert Image (Reduced scale to 0.55 to prevent overlap)
        worksheet.insert_image(0, image_col, kano_image_path, {'x_scale': 0.55, 'y_scale': 0.55})
        
        # 2. Generate Sorted List (MUST match graph logic)
        req_cat_pairs = [(r, kano_map.get(r, "Performance")) for r in roof_cols]
        sorted_pairs = sorted(req_cat_pairs, key=lambda pair: pair[1])
        
        # 3. Write Index List further to the right (image_col + 10 for safety)
        legend_start_col = image_col + 10
        worksheet.write(1, legend_start_col, "Kano Graph Index", fmt_legend_header)
        worksheet.set_column(legend_start_col, legend_start_col, 50) 
        
        for idx, (req, cat) in enumerate(sorted_pairs, start=1):
            text = f"{idx}. {req} ({cat})"
            worksheet.write(2 + idx, legend_start_col, text, fmt_legend_item)

    # SHEET 2: REASONS & SCORES
    score_table_start_row = total_row_idx + 4
    
    fmt_table_title = workbook.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter', 'font_size': 12, 'bg_color': '#4472C4', 'font_color': 'white'})
    worksheet.merge_range(score_table_start_row, 0, score_table_start_row, len(score_df.columns) + 1, "Score Analysis Table", fmt_table_title)

    header_row = score_table_start_row + 1
    worksheet.write(header_row, 0, score_df.index.name or 'Index', fmt_header_rot)
    for col_idx, col_name in enumerate(score_df.columns, start=1):
        worksheet.write(header_row, col_idx, col_name, fmt_header_rot)

    for row_idx, (index_val, row_data) in enumerate(score_df.iterrows()):
        worksheet.write(header_row + 1 + row_idx, 0, index_val, fmt_header_row)
        for col_idx, value in enumerate(row_data, start=1):
            worksheet.write(header_row + 1 + row_idx, col_idx, value, fmt_header_row)
    
    # --- BAR CHART ---
    bar_chart = workbook.add_chart({'type': 'column'})
    
    categories = []
    values_list = []
    
    for c in range(num_cols):
        c_pos = col_start_data + c * col_width
        categories.append(['House of Quality', start_row_headers, c_pos, start_row_headers, c_pos])
        values_list.append(col_weighted_sums[c])
    
    bar_chart.add_series({
        'name':       'Total Weighted Score',
        'categories': ['House of Quality', start_row_headers, col_start_data, 
                      start_row_headers, col_start_data + (num_cols * col_width) - 1],
        'values':     ['House of Quality', total_row_idx, col_start_data, 
                      total_row_idx, col_start_data + (num_cols * col_width) - 1],
        'fill':       {'color': '#4472C4'},
    })
    
    bar_chart.set_title({'name': 'Product Requirements - Total Weighted Score'})
    bar_chart.set_x_axis({'name': 'Product Requirements', 'num_font': {'rotation': -45}})
    bar_chart.set_y_axis({'name': 'Total Weighted Score'})
    bar_chart.set_legend({'position': 'none'})
    bar_chart.set_size({'width': 720, 'height': 500})
    
    chart_row = total_row_idx + len(score_df) + 9
    worksheet.insert_chart(chart_row, 0, bar_chart)

    # --- PIE CHART ---
    pie_chart = workbook.add_chart({'type': 'pie'})
    
    pie_chart.add_series({
        'name':       'Customer Expectations',
        'categories': ['House of Quality', start_row_body, 0, start_row_body + len(df_body.index) - 1, 0],
        'values':     ['House of Quality', start_row_body, end_col, start_row_body + len(df_body.index) - 1, end_col],
        'data_labels': {'percentage': True, 'category': True},
    })
    
    pie_chart.set_title({'name': 'Customer Expectations - Row Score Distribution'})
    pie_chart.set_size({'width': 500, 'height': 500})
    
    worksheet.insert_chart(chart_row, 18, pie_chart)

    # --- SHEET 2: CORRELATION REASONS ---
    ws_reasons = workbook.add_worksheet("Correlation Reasons")
    ws_reasons.write(0, 0, "Req A", fmt_header_row)
    ws_reasons.write(0, 1, "Req B", fmt_header_row)
    ws_reasons.write(0, 2, "Val", fmt_center)
    ws_reasons.write(0, 3, "Reason", fmt_header_row)
    
    r_idx = 1
    for item in roof_data:
        try:
            id_a, id_b = int(item['ID_A']), int(item['ID_B'])
            if item['Val'] != "0":
                ws_reasons.write(r_idx, 0, roof_cols[id_a])
                ws_reasons.write(r_idx, 1, roof_cols[id_b])
                ws_reasons.write(r_idx, 2, item['Val'], fmt_center)
                ws_reasons.write(r_idx, 3, item.get('Reason', ''))
                r_idx += 1
        except: continue
    ws_reasons.set_column(3, 3, 70)

    # SHEET 3: SPECIFICATIONS
    ws_specs = workbook.add_worksheet("Specifications")
    ws_specs.write(0, 0, "Product Requirement", fmt_header_row)
    ws_specs.write(0, 1, "Kano Category", fmt_header_row)
    ws_specs.write(0, 2, "Technical Specification", fmt_header_row)
    ws_specs.write(0, 3, "Specification Details", fmt_header_row)
    
    fmt_wrap = workbook.add_format({'text_wrap': True, 'valign': 'top'})
    for i, s in enumerate(specs_list):
        ws_specs.write(i+1, 0, s["Product_Requirement"], fmt_wrap)
        ws_specs.write(i+1, 1, kano_map.get(s["Product_Requirement"], ""), fmt_wrap)
        ws_specs.write(i+1, 2, s["Technical_Specification"], fmt_wrap)
        ws_specs.write(i+1, 3, s["Specification_details"], fmt_wrap)
        
    ws_specs.set_column(0, 0, 30)
    ws_specs.set_column(1, 1, 20)
    ws_specs.set_column(2, 2, 40)
    ws_specs.set_column(3, 3, 60)

    writer.close()