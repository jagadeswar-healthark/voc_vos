
import os
import json
import requests
from typing import List, Dict, Any
from dotenv import load_dotenv
import re
import streamlit as st

# Load environment variables
load_dotenv()



# ==================== CONFIGURATION ====================
PERPLEXITY_API_KEY = os.getenv('PERPLEXITY_API_KEY')
AZURE_API_KEY = os.getenv('AZURE_GEMINI_KEY')
PERPLEXITY_API_URL = "https://api.perplexity.ai/chat/completions"
PERPLEXITY_MODEL = "sonar"

if not PERPLEXITY_API_KEY:
    st.error("❌ Perplexity API key not found. Please set PERPLEXITY_API_KEY in .env file")
    st.stop()

# ==================== UTILITY ====================
def get_gemini_client():
    try:
        from openai import OpenAI
        if not AZURE_API_KEY: return None
        return OpenAI(
            base_url="https://api.geneai.thermofisher.com/dev/gemini/deployments/gemini-2.0-flash",
            api_key="", default_headers={"api-key": AZURE_API_KEY},
        )
    except ImportError: return None

# ==================== STEP 1: DISCOVER (Updated: Normalize Thermo Fisher) ====================
def discover_companies(region: str, product: str) -> Dict:
    query = f"""
Using Thermo Fisher Scientific as the benchmark, identify the TOP 10 companies or brands that customers realistically recognize, evaluate, and shortlist when purchasing "{product}" in {region}.

OBJECTIVE:
- Surface the most commercially relevant and customer-facing competitors for "{product}".
- Focus on how buyers actually shortlist vendors, not theoretical market participants.

SELECTION CRITERIA (apply strictly and rank in this exact order):
1. Market leaders cited in analyst reports (ResearchAndMarkets, Grand View Research, Mordor Intelligence)
2. Vendors most frequently referenced on lab comparison and review platforms (SelectScience, Labcompare)
3. Companies with at least TWO purchasable HARDWARE product families in this category
4. Global OEM or private-label manufacturers (EXCLUDE distributors, resellers, integrators)
5. Strong regional players, ONLY if credible {region}-specific market presence exists

CRITICAL COMPANY / BRAND LISTING RULES:
- List companies strictly at the BRAND LEVEL that customers recognize and shortlist.
- The list may include:
  • OEM manufacturers
  • Strong customer-facing brands
- DO NOT list product lines, series, platforms, or model families.
- DO NOT list both a parent company and its brand separately.
  • If a brand is owned by a parent company, list ONLY the brand.
  • Ownership clarification will be handled in later steps.
- DO NOT merge brand and parent names.
  • Example: "BioTek" (NOT "Agilent BioTek")
  • Example: "Molecular Devices" (NOT "Danaher")
- Each listed company must have an active, commercially meaningful presence in the "{product}" category.

THERMO FISHER SCIENTIFIC RULE (MANDATORY):
- If Thermo Fisher Scientific is relevant to "{product}", it MUST appear within the FIRST 3 positions.

OUTPUT FORMAT (STRICT):
- Output EXACTLY 10 companies
- One company per bullet point
- Company name ONLY (no descriptions, no parentheses, no notes)
- Do NOT include explanations or commentary

OUTPUT EXAMPLE (illustrative only):
- Company Name 1
- Company Name 2
- Company Name 3
...
- Company Name 10
"""

    try:
        res = requests.post(PERPLEXITY_API_URL, headers={"Authorization": f"Bearer {PERPLEXITY_API_KEY}"}, json={"model": PERPLEXITY_MODEL, 
            "messages": [
            {
                "role": "system",
                "content": (
                    "You are a market intelligence analyst. "
                    "Follow selection criteria strictly and output ONLY company names."
                )
            },
            {
                "role": "user",
                "content": query
            }
            ], "temperature": 0.0}).json()
        content = res["choices"][0]["message"]["content"]
        
        companies = []
        citations = res.get("citations", [])
        
        for line in content.splitlines():
            # 1. Cleaning
            clean = line.replace('**', '')
            clean = re.sub(r'\[[\d,\s]+\]', '', clean)
            clean = re.sub(r'\s*\(.*?\)', '', clean)
            clean = re.sub(r'^[\d\-\.\s]+', '', clean)
            clean = clean.strip()
            
            # 2. Validity Check
            if (len(clean) > 2) and (len(clean) < 50) and (":" not in clean) and ("Here" not in clean):
                
                # --- NORMALIZE THERMO FISHER NAMES ---
                # Check for variations and standardize to parent company
                lower_clean = clean.lower()
                if "thermo scientific" in lower_clean or "fisher scientific" in lower_clean or "thermo fisher" in lower_clean:
                    clean = "Thermo Fisher Scientific"
                # -------------------------------------

                companies.append(clean)
        
        # 3. Deduplicate (Preserving Order)
        # This handles cases where the AI listed both "Thermo Scientific" and "Fisher Scientific"
        seen = set()
        unique_companies = []
        for c in companies:
            if c not in seen:
                unique_companies.append(c)
                seen.add(c)
                
        return {"companies": unique_companies[:10], "status": "success"}, citations
    except Exception as e:
        return {"error": str(e), "status": "error"}, []
    
# ==================== STEP 2: GATHER INTELLIGENCE (Updated: Strict Validation) ====================
def retrieve_company_data(company: str, product: str, region: str) -> Dict:

   
    query = f"""
    Act as a senior Market Research Analyst. Perform a rigorous market assessment of {company}'s "{product}" portfolio in {region} using ONLY information from the top 10 most authoritative and credible industry sources.

Your task is to validate product ownership, brand positioning, and market standing with evidence-driven reasoning. Accuracy is critical.

────────────────────────────────────────
CRITICAL ENFORCEMENT RULES
────────────────────────────────────────

1. PRODUCT VERIFICATION  
   - Confirm that each product line listed is genuinely owned and marketed by {company}.  
   - Do NOT misattribute well-known product families to incorrect manufacturers  
     (e.g., Do NOT assign "SpectraMax" to Thermo Fisher).

2. REBRANDING / ACQUISITION CHECK  
   - If {company} has undergone acquisition or rebranding  
     (e.g., PerkinElmer Life Sciences → Revvity), explicitly acknowledge the current brand identity.

3. NO ASSUMPTIONS  
   - Do not infer manufacturing status, pricing, or brand tier without logical justification.  
   - When direct evidence is missing, use conservative, market-consistent inference.

 
4. **NO FABRICATION**
- Do NOT invent product names, technologies, certifications, or competitors.
- Every listed product series MUST be real and verifiable as belonging to "{company}" or its parent.

5. **CONTROLLED INFERENCE (ALLOWED & REQUIRED)**
- If exact figures (e.g., pricing, market share) are not publicly disclosed:
    - Use industry-standard inference based on brand tier, portfolio depth, and peer positioning.
    - Clearly label such values as **(Inferred)**.
- Do NOT fabricate precise figures (e.g., "$42,350").

6. **PRODUCT VERIFICATION (STRICT)**
- Verify that each listed product line genuinely belongs to "{company}".
- Do NOT attribute competitor or sibling-brand products.
- Do NOT include adjacent instrument categories.

────────────────────────────────────────
REQUIRED FIELDS
────────────────────────────────────────

1. Manufacturer_Status  
Determine the company’s operational role in product creation. Return ONLY ONE:

- OEM  
  The company designs, engineers, and manufactures products in-house.  
  Indicators: owned manufacturing facilities, proprietary R&D, patents, internally developed product families.

- Private Label  
  The company rebrands or resells products manufactured by another OEM.  
  Indicators: “distributed by”, “manufactured for”, white-label sourcing, lack of proprietary technology.

- Unknown  
  Use ONLY when evidence is insufficient or contradictory.

Rules:  
- Investigate control of manufacturing and R&D.  
- Do NOT default to OEM.  
- Return exactly one label.

2. Brand_Classification

Assign ONE category reflecting the company’s global brand strength, breadth of portfolio, innovation intensity, and strategic influence in the life-science instrumentation market.

    Market Leader (Innovation Leader)
    Multinational, top-tier life-science companies with broad multi-category portfolios, sustained high R&D investment, and category-defining or industry-standard technologies. These brands influence market direction and are commonly present across pharma, clinical, academic, and industrial labs worldwide.

    Established Core Player
    Well-known and widely adopted specialist brands with a strong installed base in one or a few domains (e.g., microbiology, food safety, sample prep). Recognized for reliability and consistent performance, but with narrower portfolio breadth or lower strategic influence than Market Leaders.

    Value-Focused / Emerging Player
    Brands primarily competing on affordability, regional presence, distribution/private-label models, or limited proprietary differentiation. Typically offer functional solutions rather than technology-leading platforms.

Rules:

    Evaluate using global brand status, not regional popularity.

    Market Leader should be rare and selective.

    Do not default all well-known brands to Established Core Player.

    Base classification on portfolio breadth, innovation depth, and industry influence—not only price.

3. Product_Lines  
- List ONLY short, commercially named product SERIES or TIERS do not include number like pro-3, 5, etc.  
- Exclude platforms, software, and generic category terms.  
- Exclude competitor products.  
- Return as comma-separated list.

4. Positioning  
- Identify primary customer segments (e.g., University Labs, Pharma QC, Clinical Diagnostics, Startups).

5. Pricing  
- Provide a realistic portfolio-wide PRICE RANGE.  
- Do NOT return "unknown".  
- If direct pricing is unavailable, infer using comparable brands and tier logic.  
- Do NOT apply flagship pricing across all models.

6. Presence  
- Identify major sales channels (Direct, key distributors).  
- Describe geographic reach.

7. Differentiators  
- List concrete technical or engineering differentiators  
  (e.g., patented drive systems, energy certifications, unique control architectures).

8. Advantages  
- State practical buyer-facing reasons to choose this brand.

────────────────────────────────────────
PERFORMANCE SCORE (1–10)
────────────────────────────────────────

Assign ONE integer score from 1 to 10 based on holistic evaluation of:

- Market Leadership & Reach  
- Technology & Product Excellence  
- Brand Tier & Perceived Value  
- Reputation & Customer Experience  

Rules:  
- Do NOT return "unknown".  
- If evidence is insufficient, return: can't calculate.  
- Otherwise return a single integer only.

────────────────────────────────────────
OUTPUT FORMAT
────────────────────────────────────────

Provide results as a clear, numbered, structured list matching the fields above."""
    


    try:
        # Using a slightly higher temperature (0.1) allows the model to process the 
        # complex instructions while the strict prompt keeps it grounded.
        res = requests.post(
            PERPLEXITY_API_URL, 
            headers={"Authorization": f"Bearer {PERPLEXITY_API_KEY}"}, 
            json={
                "model": PERPLEXITY_MODEL, 
                "messages": [{"role": "user", "content": query}], 
                "temperature": 0.1,
                "seed":42,
                "top_p":0.1

            }
        ).json()
        
        content = res["choices"][0]["message"]["content"]
        return {"company": company, "content": content, "status": "success"}, res.get("citations",[])

    except Exception as e:
        return {"company": company, "status": "error"}, []

# ==================== STEP 3: COMPETITOR ASSESSMENT ====================
def generate_competitor_assessment(results: List[Dict], product: str) -> Dict:
    combined_text = "\n".join([f"--- {r['company']} ---\n{r['content']}" for r in results if r['status']=='success'])
    prompt = f"""
RAW DATA:
{combined_text[:60000]}

Create a high-quality "Competitor Assessment – Manufacturer Landscape" section for "{product}".

Create a "Competitor Assessment" slide for "{product}".
 
    You MUST strictly distinguish between:
    1) Manufacturers (legal/OEM entities)
    2) Brands (marketed trade names)
    3) Product families/series (NOT brands, but must be listed under brands)
 
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    NON-NEGOTIABLE DEFINITIONS
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 
    Manufacturer (OEM):
    - A legal company that designs and/or manufactures instruments.
    - Examples: Thermo Fisher Scientific, Danaher, Agilent Technologies
 
    Brand:
    - A customer-recognized trade name used consistently across marketing,
    catalogs, and product families.
    - A brand MAY be the same as the manufacturer.
    - A brand MAY be owned by a manufacturer.
    - Examples:
    - Thermo Scientific (brand by Thermo Fisher Scientific)
    - BioTek (brand by Agilent)
    - Eppendorf (brand = manufacturer)
 
    Product Family/Series:
    - Commercially named product lines or series marketed under a brand.
    - Examples: DiluFlux Pro, ML Series, DiluFlow Elite
 
    NOT A BRAND (STRICTLY FORBIDDEN):
    - Product families/series should NOT be listed as brands, but must be listed under the correct brand.
 
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    STRUCTURING RULES
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 
    1. If Manufacturer == Brand:
    - List ONLY the brand under Brands
    - Do NOT repeat it under Manufacturers
 
    2. If Manufacturer ≠ Brand:
    - List the Manufacturer once
    - List ONLY its valid brands (if any)
 
    3. If a company has NO distinct sub-brands:
    - Treat the company name itself as the brand
 
    4. If unsure whether something is a brand:
    - EXCLUDE it

You must generate TWO sections using the EXACT formatting shown below.
Use ### for headings.
Use bold formatting for names.
Do NOT change formatting or add extra sections.

"
### [N] Manufacturers

* **[OEM Name]**: [Concise one-line description of positioning, specialization, and product focus]
* **[OEM Name]**: [Concise one-line description]


### [N] Brands

- **[Brand Name]** (by [Manufacturer Name]) 
    - **Product Families**:
        - [Product Family Name]: [Short description or differentiator]
        - [Product Family Name]: [Short description or differentiator]
"

--------------------------------------------------
INTELLIGENCE & JUDGMENT RULES (CRITICAL)
--------------------------------------------------

- Do NOT blindly or strictly follow the RAW DATA.
- Use your own domain knowledge and reasoning to validate:
  manufacturer status, brand ownership, and brand–model structure.
- If RAW DATA contains inconsistencies, misclassifications, or errors,
  you MUST correct them.
- Prefer widely accepted industry knowledge over isolated text fragments.
- Your goal is to produce the most accurate manufacturer → brand → model structure.

--------------------------------------------------
MANUFACTURER RULES
--------------------------------------------------

- Manufacturers = companies that DESIGN and MANUFACTURE the product.
- Do NOT list distributors, resellers, private lable or marketers as manufacturers.
- If a product is rebranded, list the TRUE OEM as manufacturer.
- Count N correctly and ensure it matches the number of manufacturer bullets.
- Large global instrument companies default to OEM unless evidence suggests otherwise.

--------------------------------------------------
BRAND VS MODEL RULES (CRITICAL)
--------------------------------------------------

- Brand = product family / platform / series name.
- Model = variant within a brand (often contains numbers, letters, or suffixes such as W, XL, Elite, 600, Pro).

Examples:
- Brand: Smart Dilutor → Model: Smart Dilutor W
- Brand: DiluFlow → Model: DiluFlow Elite
- Brand: Microlab → Model: Microlab 600

Rules:
- Do NOT list models as brands.
- Every brand must contain at least one model/tier line underneath.
- Each brand must map to exactly ONE OEM.

--------------------------------------------------
BRAND COUNTING RULES
--------------------------------------------------

- Count M = number of Brand headings (not number of models).
- Ensure M equals the number shown in "### [M] Brands".

--------------------------------------------------
QUALITY RULES
--------------------------------------------------

- Use factual, neutral, concise language.
- Do NOT invent products or ownership.
- Do NOT duplicate manufacturers as brands.
- If uncertain, use conservative wording such as "offers" or "markets".

--------------------------------------------------
FINAL VALIDATION (MANDATORY)
--------------------------------------------------

Before answering, verify:

- N equals number of manufacturer bullets.
- M equals number of brand headings.
- No model appears as a brand.
- One brand → one OEM only.

============================================================
TASK 2: Extract Bubble Chart Data (JSON)
============================================================

For EACH manufacturer listed above, estimate:

- "price_usd" → integer typical selling price
- "performance" → integer score from 1 to 10
- "market_share" → integer score from 1 to 10

------------------------------------------------------------
PRICE BAND GUARDRAILS
------------------------------------------------------------

- Market Leader manufacturer: 20000–50000 USD typical range
- Established Core manufacturer: 12000–40000 USD typical range
- Value-Focused / Emerging manufacturer: 7000–25000 USD typical range

Use midpoints unless strong evidence suggests otherwise.

------------------------------------------------------------
SCORING GUIDANCE
------------------------------------------------------------

- Performance:
  9–10 = Category leaders
  7–8  = Strong specialists
  5–6  = Functional/basic offerings

- Market Share:
  8–10 = Dominant or top-3 globally
  5–7  = Recognized niche specialists
  2–4  = Smaller or regional players

- Do NOT use "unknown".
- Use reasonable market inference if exact data is unavailable.

============================================================
OUTPUT FORMAT (STRICT)
============================================================

Return ONLY valid JSON in this structure:

{{
  "assessment_text": "...",
  "chart_data": [
    {{ "MANUFACTURER": "...", "price_usd": 0, "performance": 0, "market_share": 0 }}
  ],
  "bottom_box_text": "..."
}}

============================================================
AUTO-VALIDATION & DEDUPLICATION (MANDATORY)
============================================================

- Every manufacturer in chart_data MUST appear in Manufacturer Landscape.
- Number of manufacturer in chart_data MUST equal M.
- Remove duplicates automatically.
- One Brand → one OEM only.
- No extra text outside JSON.


Return ONLY the formatted Manufacturer and Brand sections.
"""



    client = get_gemini_client()
    if not client: return None
    res = client.chat.completions.create(model="gemini-2.0-flash", messages=[{"role": "user", "content": prompt}, {"role": "system", "content": "Output valid JSON."}], temperature=0.2)
    return json.loads(res.choices[0].message.content.replace("```json", "").replace("```", "").strip())

# ==================== STEP 4: STRATEGIC FIT (Fixed "Consultant Tone") ====================
def generate_strategic_fit(comp_a: str, comp_b: str, product: str) -> Dict:
    # 1. Define the Prompt with "Style Transfer" instructions
    query = f"""
    Act as a Product Strategy Director. Create a "Strategic Fit" analysis comparing "{comp_a}" (Benchmark) vs "{comp_b}" (Challenger) for {product}.

    ### REQUIREMENT 1: PRICING DATA (Estimates Required)
    Estimate List Prices (USD) for 3 sizes: Small (~23 cu.ft), Medium (~30 cu.ft), Large (~50 cu.ft).
    * Prices MUST increase with size.
    * Prices MUST be non-zero integers.

    ### REQUIREMENT 2: STRATEGIC TEXT (Style Transfer)
    Generate 5 bullet points analyzing the fit. 
    CRITICAL: You must use the **sentence structure** below, but replace the [Bracketed Content] with REAL facts about {comp_a} and {comp_b}.

    * "Similar feature set between {comp_a} and {comp_b} [Mention key shared spec]"
    * "Differentiated messaging - {comp_b} will not have sufficient [Key Performance Metric] for [Target High-End App]"
    * "{comp_a} positioned as only suitable option for [Critical Use Case]"
    * "{comp_b} limitation - [Mention a specific lower spec, e.g. Controller Type, Recovery Time, or Warranty] (Cannot guarantee stability for [Use Case])"
    * "Maintain ~[20-40]% delta between {comp_a} and {comp_b} dealer pricing"

    Output strictly valid JSON:
    {{
        "prices": {{
            "{comp_a}": [price_s, price_m, price_l],
            "{comp_b}": [price_s, price_m, price_l]
        }},
        "sizes": ["23 cu.ft", "30 cu.ft", "50 cu.ft"],
        "strategy_text": [
            "Bullet 1 (Feature comparison)",
            "Bullet 2 (The Messaging Gap)",
            "Bullet 3 (The 'Premium' Positioning)",
            "Bullet 4 (The Technical Limitation)",
            "Bullet 5 (The Pricing Delta Goal)"
        ],
        "highlight_box": "Differentiation will be achieved by focusing training and messaging around customer applications"
    }}
    """
    
    # Smart Fallback Data (If API fails, use this generic "Premium vs Value" template)
    default_data = {
        "prices": {comp_a: [7500, 8500, 10500], comp_b: [5500, 6200, 7800]},
        "sizes": ["23 cu.ft", "30 cu.ft", "50 cu.ft"],
        "strategy_text": [
            f"Similar feature set between {comp_a} and {comp_b}, both offering standard microprocessor controls.",
            f"Differentiated messaging - {comp_b} lacks the advanced recovery speed required for frequent door openings.",
            f"{comp_a} positioned as the only suitable option for critical GMP/GLP storage applications.",
            f"{comp_b} limitation - Standard Compressor Cycle (Cannot guarantee tight uniformity during peak usage).",
            f"Maintain ~30% delta between {comp_a} and {comp_b} dealer pricing to protect margin."
        ],
        "highlight_box": "Differentiation driven by application-specific performance messaging."
    }

    try:
        # 1. Get raw data from Perplexity
        client = get_gemini_client()
        if not client: return default_data

        raw_content = ""
        try:
            px_payload = {"model": PERPLEXITY_MODEL, "messages": [{"role": "user", "content": query}]}
            px_res = requests.post(PERPLEXITY_API_URL, headers={"Authorization": f"Bearer {PERPLEXITY_API_KEY}"}, json=px_payload).json()
            if "choices" in px_res:
                raw_content = px_res["choices"][0]["message"]["content"]
        except:
            raw_content = "" 

        # 2. Structure with Gemini (Force it to generate estimates if Perplexity failed)
        res = client.chat.completions.create(
            model="gemini-2.0-flash",
            messages=[
                {"role": "system", "content": "You are a Strategy Consultant. Generate realistic strategic analysis. Output valid JSON."},
                {"role": "user", "content": f"Extract JSON from this research. If empty, generate the JSON yourself based on the prompt requirements:\n\nPrompt: {query}\n\nResearch: {raw_content}"}
            ],
            temperature=0.2
        )
        
        clean_json = res.choices[0].message.content.replace("```json", "").replace("```", "").strip()
        data = json.loads(clean_json)
        
        # --- DATA CLEANING (Fixes Flat Lines) ---
        for company in [comp_a, comp_b]:
            prices = data["prices"].get(company, [0,0,0])
            
            # If empty or all zero, generate a synthetic curve
            if not prices or sum(prices) == 0:
                base = 6000 if company == comp_a else 4500
                data["prices"][company] = [base, int(base*1.2), int(base*1.5)]
            
            # If flat line (all same price), create a synthetic curve
            elif len(set(prices)) == 1:
                base = prices[0]
                data["prices"][company] = [base, int(base*1.2), int(base*1.5)]
                
            # Ensure strictly 3 points
            data["prices"][company] = data["prices"][company][:3]
            
        return data

    except Exception as e:
        print(f"Strategic Fit Error: {e}")
        return default_data