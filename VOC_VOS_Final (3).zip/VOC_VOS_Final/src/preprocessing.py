# modules/preprocessing.py

import re

def clean_text(text):
    # Remove greetings & signatures
    text = re.sub(r"^(hi|hello|dear)[^,]*,", "", text, flags=re.I)
    # text = re.sub(r"(?i)(regards|best|thanks)[\s\S]*$", "", text)

    # Remove bullets, normalize spacing
    text = text.replace("•", "-").replace("–", "-")
    text = re.sub(r"\s+", " ", text)

    return text.strip()


def preprocess(doc):
    cleaned = clean_text(doc["raw_text"])
    return {
        "filename": doc["filename"],
        "raw_text": doc["raw_text"],
        "cleaned_text": cleaned
    }
