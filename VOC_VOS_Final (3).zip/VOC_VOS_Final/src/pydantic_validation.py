from enum import Enum
from typing import Any
from pydantic import BaseModel, Field, field_validator


# -----------------------------
# Classification Output Model
# -----------------------------
class ClassificationResult(BaseModel):
    product_line: str = Field(..., description="General product family")
    subsystem: str = Field(..., description="Component involved")
    customer_pain_point: str = Field(..., description="Problem expressed")

    @field_validator("*", mode="before")
    @classmethod
    def clean_field(cls, v):
        if isinstance(v, str):
            v = v.strip()
            return v if v else "Unknown"
        return "Unknown"


# -----------------------------
# Priority Enum
# -----------------------------
class PriorityEnum(str, Enum):
    High = "High"
    Medium = "Medium"
    Low = "Low"


# -----------------------------
# Requirement Model (FIXED)
# -----------------------------
class Requirement(BaseModel):
    req_id: str
    requirement_statement: str
    priority: PriorityEnum = Field(..., description="High | Medium | Low")
    source: str

    # ✅ FIX: normalize requirement_statement
    @field_validator("requirement_statement", mode="before")
    @classmethod
    def normalize_requirement_statement(cls, v: Any) -> str:
        """
        Handles:
        - string
        - list[dict] from LLM output
        - dict
        """
        # Case 1: already a string
        if isinstance(v, str):
            v = v.strip()
            return v if v else "Unknown requirement"

        # Case 2: list of dicts (your current error)
        if isinstance(v, list) and len(v) > 0:
            first = v[0]
            if isinstance(first, dict):
                return first.get("statement", "Unknown requirement")

        # Case 3: dict directly
        if isinstance(v, dict):
            return v.get("statement", "Unknown requirement")

        return "Unknown requirement"

    # Priority normalization (already good)
    @field_validator("priority", mode="before")
    @classmethod
    def normalize_priority(cls, v):
        if isinstance(v, str):
            v = v.strip().lower()
            if "high" in v:
                return PriorityEnum.High
            if "medium" in v:
                return PriorityEnum.Medium
            if "low" in v:
                return PriorityEnum.Low
        return PriorityEnum.Medium  # safe default
