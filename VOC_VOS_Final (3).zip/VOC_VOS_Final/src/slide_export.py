import os
import re
from io import BytesIO
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
import streamlit as st


# ============================================================
# CONSTANTS
# ============================================================
COLORS = {
    'primary_red': RGBColor(220, 38, 38),
    'dark_blue': RGBColor(30, 58, 138),
    'white': RGBColor(255, 255, 255),
    'light_gray': RGBColor(243, 244, 246),
    'medium_gray': RGBColor(107, 114, 128),
    'dark_gray': RGBColor(75, 85, 99),
    'text_dark': RGBColor(31, 41, 55),
    'black': RGBColor(0, 0, 0),
    'teal': RGBColor(2, 128, 144),
    'terracotta': RGBColor(180, 80, 66),
    'dark_red': RGBColor(153, 0, 17),
}

SLIDE_WIDTH = Inches(13.333)
SLIDE_HEIGHT = Inches(7.5)

# Font sizes
TITLE_FONT_SIZE = Pt(28)
HEADER_FONT_SIZE = Pt(18)
SUBHEADER_FONT_SIZE = Pt(22) # For A, B, C
BODY_FONT_SIZE = Pt(16)
SUB_BULLET_FONT_SIZE = Pt(14)
TABLE_FONT_SIZE = Pt(13)

# Layout constants
LEFT_MARGIN = Inches(0.75)
RIGHT_MARGIN = Inches(0.75)
TOP_MARGIN = Inches(0.5)
BOTTOM_MARGIN = Inches(0.5)
CONTENT_WIDTH = Inches(11.83)
TITLE_HEIGHT = Inches(0.8)

# Content boundaries
CONTENT_TOP = Inches(1.4)
CONTENT_BOTTOM = Inches(6.9)

# Limits
MAX_BULLETS_PER_SLIDE = 9 
TABLE_DATA_ROWS_PER_SLIDE = 4
TABLE_MIN_ROW_HEIGHT = Inches(0.4)

# ============================================================
# UTILITY FUNCTIONS
# ============================================================
def clean_markdown_text(text):
    """Remove markdown formatting and invalid control characters."""
    if not text:
        return ""
    # Remove XML-invalid control characters
    text = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', '', text)
    
    # Remove markdown code blocks
    text = re.sub(r'```\w*\n?', '', text)
    text = re.sub(r'```', '', text)
    text = re.sub(r'`([^`]+)`', r'\1', text)
    
    # Remove bold/italic markers but keep text
    text = re.sub(r'\*\*([^*]+)\*\*', r'\1', text) 
    text = re.sub(r'__([^_]+)__', r'\1', text)
    text = re.sub(r'\*([^*]+)\*', r'\1', text) 
    text = re.sub(r'_([^_]+)_', r'\1', text)
    
    # Aggressive cleanup: remove ANY remaining asterisks
    text = text.replace('*', '')
    
    # Remove headers syntax
    text = re.sub(r'^#+\s*', '', text, flags=re.MULTILINE)
    
    # Remove citations
    text = re.sub(r'\[\d+(?:,\s*\d+)*\]|\[\d+\]', '', text)
    
    text = re.sub(r'\n\s*\n\s*\n', '\n\n', text)
    return text.strip()

def add_citations_to_notes(slide, citations):
    """
    Add clickable citations to slide Notes section.
    """
    if not citations:
        return

    notes_tf = slide.notes_slide.notes_text_frame
    notes_tf.clear()

    header = notes_tf.paragraphs[0]
    header.text = "Sources & Citations:"
    header.font.bold = True

    for i, cite in enumerate(citations, 1):

        # Ensure proper URL format
        clean_url = cite.strip()
        if not clean_url.startswith(("http://", "https://")):
            clean_url = "https://" + clean_url

        p = notes_tf.add_paragraph()
        run = p.add_run()
        run.text = f"{i}. {clean_url}"

        run.font.size = Pt(10)
        run.font.color.rgb = COLORS['dark_blue']
        run.font.underline = True  # Important for visual hyperlink cue

        run.hyperlink.address = clean_url


def parse_hierarchical_bullets(text):
    """Standard parser for basic bullet lists."""
    if not text: return []
    lines = text.split('\n')
    bullets = []
    
    for line in lines:
        stripped = line.strip()
        if not stripped: continue
        
        leading_spaces = len(line) - len(line.lstrip())
        is_sub = (leading_spaces >= 4 or stripped.startswith('○') or stripped.startswith('◦'))
        
        # Strip existing bullets
        clean_text = re.sub(r'^[\•\-\*○◦]\s*', '', stripped).strip()
        clean_text = clean_markdown_text(clean_text)
        
        if not clean_text: continue
        # Double check for dashes
        clean_text = re.sub(r'^[-–—]\s*', '', clean_text)

        if is_sub and bullets:
            bullets.append((1, clean_text))
        else:
            bullets.append((0, clean_text))
    
    return bullets

def parse_structured_content(text):
    """
    Advanced parser for Strategy/Cost slides.
    Detects numbered items as HEADERS, unless they are clearly sub-points like 'Examples' or 'Buyer logic'.
    """
    items = []
    lines = text.split('\n')
    
    # Regex for "1. Title" or "1) Title"
    header_pattern = re.compile(r'^\s*\d+[\.\)]\s+(.+)')
    
    for line in lines:
        stripped = line.strip()
        if not stripped: continue
        
        match = header_pattern.match(stripped)
        if match:
            content = match.group(1).strip()
            # If line starts with specific keywords, treat as BULLET
            if content.lower().startswith(('example', 'buyer logic', 'note', 'logic', 'position')):
                items.append({'type': 'BULLET', 'text': clean_markdown_text(content)})
            else:
                # It's a true Header (e.g., "1. Value Tier")
                items.append({'type': 'HEADER', 'text': clean_markdown_text(stripped)})
        else:
            # Standard bullet
            clean_text = re.sub(r'^[\•\-\*○◦]\s*', '', stripped)
            clean_text = clean_markdown_text(clean_text)
            clean_text = re.sub(r'^[-–—]\s*', '', clean_text)
            if clean_text:
                items.append({'type': 'BULLET', 'text': clean_text})
                
    return items

def parse_markdown_table(text):
    lines = text.strip().split('\n')
    table_data = []

    for line in lines:

        # Skip separator rows like |----|
        if re.match(r'^[\|\s\-:]+$', line):
            continue

        if '|' in line:

            # Split and KEEP empty cells
            cells = line.split('|')

            # Remove first/last empty caused by leading/trailing |
            if cells and cells[0].strip() == "":
                cells = cells[1:]
            if cells and cells[-1].strip() == "":
                cells = cells[:-1]

            # Strip whitespace but DO NOT drop empty cells
            cells = [cell.strip() for cell in cells]

            table_data.append(cells)

    return table_data
def add_footer_note(slide):
    """
    Adds small grey footer text: 'Sources in notes'
    """
    footer_box = slide.shapes.add_textbox(
        LEFT_MARGIN,
        SLIDE_HEIGHT - Inches(0.4),
        Inches(3),
        Inches(0.3)
    )

    tf = footer_box.text_frame
    tf.clear()

    p = tf.paragraphs[0]
    p.text = "Sources in notes"
    p.font.size = Pt(10)
    p.font.color.rgb = COLORS['medium_gray']

# ============================================================
# SLIDE ELEMENTS
# ============================================================
def add_title_to_slide(slide, title_text, include_subtitle=False, subtitle_text=""):
    title_box = slide.shapes.add_textbox(LEFT_MARGIN, TOP_MARGIN, CONTENT_WIDTH, TITLE_HEIGHT)
    tf = title_box.text_frame; tf.word_wrap = True; tf.auto_size = None
    p = tf.paragraphs[0]
    p.text = clean_markdown_text(title_text)
    p.font.size = TITLE_FONT_SIZE; p.font.bold = True; p.font.color.rgb = COLORS['primary_red']
    
    if include_subtitle and subtitle_text:
        p2 = tf.add_paragraph()
        p2.text = clean_markdown_text(subtitle_text)
        p2.font.size = Pt(18); p2.font.color.rgb = COLORS['dark_gray']; p2.font.italic = True
    return title_box

def add_section_header(slide, header_text, left, top, width=Inches(11.8)):
    """Creates the Blue Highlight Header (Used for Anchor/Product slides)"""
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, Inches(0.5))
    shape.fill.solid(); shape.fill.fore_color.rgb = COLORS['dark_blue']
    shape.line.fill.background()
    tf = shape.text_frame; tf.margin_left = Pt(10)
    p = tf.paragraphs[0]; p.text = clean_markdown_text(header_text)
    p.font.size = HEADER_FONT_SIZE; p.font.bold = True; p.font.color.rgb = COLORS['white']
    return shape

def add_hierarchical_bullets(slide, bullets, left, top, width, max_height=None):
    if max_height is None: max_height = CONTENT_BOTTOM - top
    if max_height <= 0: max_height = Inches(1)
    
    content_box = slide.shapes.add_textbox(left, top, width, max_height)
    tf = content_box.text_frame; tf.word_wrap = True; tf.auto_size = None
    
    for i, (level, text) in enumerate(bullets):
        if i == 0: p = tf.paragraphs[0]
        else: p = tf.add_paragraph()
        
        p.text = ("• " if level == 0 else "    ○ ") + text
        p.font.size = BODY_FONT_SIZE if level == 0 else SUB_BULLET_FONT_SIZE
        p.font.color.rgb = COLORS['text_dark'] if level == 0 else COLORS['dark_gray']
        p.space_after = Pt(6) if level == 0 else Pt(2)

def add_structured_textbox(slide, items, left, top, width, max_height=None):
    """
    Renders structured content (Headers vs Bullets).
    Headers = Bold, Blue. Bullets = Indented, Pure Black.
    """
    if max_height is None: max_height = CONTENT_BOTTOM - top
    if max_height <= 0: max_height = Inches(1)

    content_box = slide.shapes.add_textbox(left, top, width, max_height)
    tf = content_box.text_frame; tf.word_wrap = True; tf.auto_size = None
    
    for i, item in enumerate(items):
        if i == 0: p = tf.paragraphs[0]
        else: p = tf.add_paragraph()
        
        if item['type'] == 'HEADER':
            p.text = item['text']
            p.font.size = Pt(16)
            p.font.bold = True
            p.font.color.rgb = COLORS['dark_blue']
            p.space_before = Pt(12)
            p.space_after = Pt(3)
        else:
            p.text = "• " + item['text']
            p.font.size = Pt(14)
            p.font.color.rgb = COLORS['black'] # User requested Pure Black
            p.level = 1 # Force Indentation
            p.space_after = Pt(2)

def create_table_on_slide(slide, table_data, left, top, width, available_height):

    if not table_data or len(table_data) < 1:
        return None

    rows = len(table_data)
    cols = len(table_data[0])
    if cols == 0:
        return None

    # Ensure consistent column count
    table_data = [row for row in table_data if len(row) == cols]
    rows = len(table_data)

    # ✅ DYNAMIC HEIGHT FIX
    row_height = TABLE_MIN_ROW_HEIGHT
    table_height = rows * row_height

    # Prevent exceeding available height
    table_height = min(table_height, available_height)

    table = slide.shapes.add_table(rows, cols, left, top, width, table_height).table

    # Set consistent row height
    for r in range(rows):
        table.rows[r].height = row_height

    # Column widths
    if cols >= 6:
        widths = [1.8, 1.6, 1.8, 0.7, 0.8, 5.13]
        for i in range(min(cols, len(widths))):
            table.columns[i].width = Inches(widths[i])
    else:
        for i in range(cols):
            table.columns[i].width = int(width / cols)

    # Fill table safely
    for r, row in enumerate(table_data):
        for c, val in enumerate(row):
            cell = table.cell(r, c)

            safe_text = clean_markdown_text(str(val))
            safe_text = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', '', safe_text)

            cell.text = safe_text

            p = cell.text_frame.paragraphs[0]
            p.font.size = TABLE_FONT_SIZE

            if r == 0:
                p.font.bold = True
                p.font.color.rgb = COLORS['white']
                cell.fill.solid()
                cell.fill.fore_color.rgb = COLORS['dark_blue']
            else:
                p.font.color.rgb = COLORS['text_dark']
                cell.fill.solid()
                cell.fill.fore_color.rgb = (
                    COLORS['light_gray'] if r % 2 == 0 else COLORS['white']
                )

    return table

# ============================================================
# SPECIFIC SLIDE GENERATORS
# ============================================================

def create_title_slide(prs, product_name, manufacturer="", product_image=None):

    slide = prs.slides.add_slide(prs.slide_layouts[6])
    
    # ---------------- TITLE ----------------
    tb = slide.shapes.add_textbox(LEFT_MARGIN, Inches(2.2), CONTENT_WIDTH, Inches(1.5))
    tf = tb.text_frame
    tf.clear()

    p = tf.paragraphs[0]
    p.text = product_name if product_name else "Competitive Analysis"
    p.font.size = Pt(48)
    p.font.bold = True
    p.font.color.rgb = COLORS['primary_red']
    
    p2 = tf.add_paragraph()
    p2.text = "Competitive Analysis"
    p2.font.size = Pt(28)
    p2.font.color.rgb = COLORS['text_dark']
    p2.space_before = Pt(10)
    
    if manufacturer:
        p3 = tf.add_paragraph()
        p3.text = f"Manufacturer: {manufacturer}"
        p3.font.size = Pt(18)
        p3.font.color.rgb = COLORS['dark_gray']
        p3.space_before = Pt(20)

    # ---------------- KEY ELEMENTS ----------------
    eb = slide.shapes.add_textbox(LEFT_MARGIN, Inches(4.8), Inches(6), Inches(2))
    etf = eb.text_frame
    etf.clear()

    p = etf.paragraphs[0]
    p.text = "Key elements of competitive study:"
    p.font.size = Pt(16)
    p.font.bold = True
    p.font.color.rgb = COLORS['dark_blue']
    
    for item in [
        "Product Anchor & Market Positioning",
        "Competitive Benchmarking",
        "Strategic Analysis",
        "SWOT Analysis",
        "IP & Technology Positioning"
    ]:
        p = etf.add_paragraph()
        p.text = f"• {item}"
        p.font.size = Pt(14)
        p.font.color.rgb = COLORS['text_dark']
        p.space_before = Pt(4)

    # ---------------- PRODUCT IMAGE ----------------
    if product_image:
        try:
            # CRITICAL FIX: duplicate stream safely
            from io import BytesIO
            img_stream = BytesIO(product_image.getvalue())
            img_stream.seek(0)

            slide.shapes.add_picture(
                img_stream,
                Inches(8.3),
                Inches(1.6),
                width=Inches(4.5),
                height=Inches(3.8)
            )

            print("✅ Image successfully inserted into PPT")

        except Exception as e:
            print(f"❌ Image insertion failed: {e}")

    return slide

def create_product_anchor_slides(prs, anchor_info, benchmark_product):
    slides = []

    content = anchor_info.get('content', '') if isinstance(anchor_info, dict) else str(anchor_info)

    # Remove unwanted lines
    content = re.sub(r'(?im)^product anchor.*$', '', content).strip()

    # Normalize flattened bullets and force newline before numbered headers
    content = content.replace('•', '\n•')
    content = re.sub(r'\s*(\d+\.)', r'\n\1', content)

    lines = content.split('\n')

    sections = []
    current_section = None

    header_regex = re.compile(r'^\s*(\d+)\.\s*(.+)')

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue

        match = header_regex.match(stripped)

        # ---------------- HEADER ----------------
        if match:
            if current_section:
                sections.append(current_section)

            current_section = {
                "title": stripped,
                "bullets": []
            }

        # ---------------- BULLETS ----------------
        elif current_section:
            clean_line = clean_markdown_text(stripped)
            clean_line = re.sub(r'^[\•\-\*]+', '', clean_line).strip()

            if clean_line:
                current_section["bullets"].append((0, clean_line))

    if current_section:
        sections.append(current_section)

    # Fallback safety
    if not sections:
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        add_title_to_slide(slide, f"Product Anchor: {benchmark_product}")
        bullets = parse_hierarchical_bullets(content)
        add_hierarchical_bullets(slide, bullets, LEFT_MARGIN, CONTENT_TOP, CONTENT_WIDTH)
        return [slide]

    # ---------------- IMPROVED PAGINATION ----------------
    page_sections = []
    current_height = 0
    MAX_HEIGHT = 5.2  # usable content area

    for sec in sections:

        header_h = 0.7
        bullet_h = len(sec["bullets"]) * 0.42
        spacing = 0.35

        estimated_height = header_h + bullet_h + spacing

        if (current_height + estimated_height > MAX_HEIGHT) and page_sections:
            slides.append(_render_anchor_page(prs, page_sections, benchmark_product))
            page_sections = []
            current_height = 0

        page_sections.append(sec)
        current_height += estimated_height

    if page_sections:
        slides.append(_render_anchor_page(prs, page_sections, benchmark_product))

    return slides
def _render_anchor_page(prs, sections, benchmark_product):
    slide = prs.slides.add_slide(prs.slide_layouts[6])

    add_title_to_slide(slide, f"Product Anchor: {benchmark_product}")

    top_position = CONTENT_TOP
    MAX_BOTTOM = CONTENT_BOTTOM

    for sec in sections:

        # ---------------- HEADER ----------------
        header_height = Inches(0.6)

        # If header doesn't fit → skip rendering
        if top_position + header_height > MAX_BOTTOM:
            break

        add_section_header(
            slide,
            sec["title"],
            LEFT_MARGIN,
            top_position,
            CONTENT_WIDTH
        )

        top_position += header_height + Inches(0.2)

        # ---------------- BULLETS ----------------
        if sec["bullets"]:

            bullet_height = Inches(len(sec["bullets"]) * 0.4)

            # If bullets don't fit → stop here
            if top_position + bullet_height > MAX_BOTTOM:
                break

            add_hierarchical_bullets(
                slide,
                sec["bullets"],
                LEFT_MARGIN,
                top_position,
                CONTENT_WIDTH,
                bullet_height
            )

            top_position += bullet_height + Inches(0.35)

    return slide



def create_strategic_analysis_slides(prs, strategy_info, benchmark_product):
    slides = []
    sections = [
        ('A', 'Strategic group map (Quality ceiling vs Cost)'),
        ('B', f'Where {benchmark_product} is competitively strong'),
        ('C', f'Where competitors can outflank {benchmark_product}')
    ]
    
    for key, title in sections:
        raw_text = strategy_info.get(key, '') if isinstance(strategy_info, dict) else ''
        if not raw_text: continue
        
        # Remove the section title from the body to avoid duplication
        clean_body = re.sub(r'^[A-C]\).*?\n', '', raw_text, flags=re.DOTALL | re.IGNORECASE).strip()
        
        items = parse_structured_content(clean_body)
        if not items: items = [{'type': 'BULLET', 'text': "See detailed analysis"}]
        
        current_items = []; current_lines = 0; MAX_LINES = 16; page = 1
        
        for item in items:
            weight = 2 if item['type'] == 'HEADER' else 1
            if current_lines + weight > MAX_LINES and current_items:
                slides.append(_render_strategy_page(prs, key, title, current_items, page, benchmark_product))
                page += 1; current_items = [item]; current_lines = weight
            else:
                current_items.append(item); current_lines += weight
        
        if current_items:
            slides.append(_render_strategy_page(prs, key, title, current_items, page, benchmark_product))
            
    return slides

def _render_strategy_page(prs, key, section_title, items, page, benchmark_product):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    
    main_title = f"Strategic analysis: where {benchmark_product} wins / loses"
    add_title_to_slide(slide, main_title)
    
    # Subheader A/B/C: Plain Black Text, Bold, Larger Font (No Blue Box)
    sub_title = f"{key}) {section_title}"
    if page > 1: sub_title += f" (cont.)"
    
    tb = slide.shapes.add_textbox(LEFT_MARGIN, Inches(1.4), CONTENT_WIDTH, Inches(0.6))
    p = tb.text_frame.paragraphs[0]
    p.text = clean_markdown_text(sub_title)
    p.font.size = SUBHEADER_FONT_SIZE
    p.font.bold = True
    p.font.color.rgb = COLORS['black']
    
    # Render Content
    add_structured_textbox(slide, items, LEFT_MARGIN, Inches(2.0), CONTENT_WIDTH)
    return slide

def create_cost_structure_slides(prs, cost_info, benchmark_product):
    slides = []
    content = cost_info.get("content", "") if isinstance(cost_info, dict) else str(cost_info)

    
    # Aggressively remove title from body
    content = re.sub(r'^[\•\-\*]*\s*Cost Structure.*?(?:\n|$)', '', content, flags=re.MULTILINE | re.IGNORECASE).strip()
    
    items = parse_structured_content(content)
    if not items: items = [{'type': 'BULLET', 'text': "See detailed analysis"}]
    
    current_items = []; current_lines = 0; MAX_LINES = 12; page = 1
    
    for item in items:
        weight = 2 if item['type'] == 'HEADER' else 1
        if current_lines + weight > MAX_LINES and current_items:
            slides.append(_render_cost_page(prs, current_items, page, benchmark_product))
            page += 1; current_items = [item]; current_lines = weight
        else:
            current_items.append(item); current_lines += weight
            
    if current_items:
        slides.append(_render_cost_page(prs, current_items, page, benchmark_product))
    return slides

def _render_cost_page(prs, items, page, benchmark_product):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    
    title = "Cost Structure:"
    subtitle = f"what drives price (and how {benchmark_product} compares)"
    if page > 1: title += f" ({page})"
    
    add_title_to_slide(slide, title, include_subtitle=True, subtitle_text=subtitle)
    add_structured_textbox(slide, items, LEFT_MARGIN, Inches(1.8), CONTENT_WIDTH)
    return slide

# ============================================================
# LEGACY WRAPPERS (Unchanged logic for others)
# ============================================================
def create_like_for_like_slides(prs, like_info, benchmark_product):
    slides = []
    content = str(like_info.get('content', '') if isinstance(like_info, dict) else like_info)
    bullets = parse_hierarchical_bullets(content)
    if not bullets: bullets = [(0, "See details")]
    
    curr = []; count = 0; page = 1
    for lvl, txt in bullets:
        if lvl == 0:
            count += 1
            if count > MAX_BULLETS_PER_SLIDE and curr:
                slides.append(_lfl_page(prs, curr, benchmark_product, page)); page += 1; curr = []
                count = 1
        curr.append((lvl, txt))
    if curr: slides.append(_lfl_page(prs, curr, benchmark_product, page))
    return slides

def _lfl_page(prs, bullets, benchmark_product, page):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    t = f'"Like-for-like" competitive set for {benchmark_product}'
    if page > 1: t += f" ({page})"
    add_title_to_slide(slide, t)
    
    tb = slide.shapes.add_textbox(LEFT_MARGIN, Inches(1.3), CONTENT_WIDTH, Inches(0.4))
    p = tb.text_frame.paragraphs[0]
    p.text = "Core competitors (most frequently cross-shopped)"
    p.font.size = Pt(16); p.font.bold = True; p.font.color.rgb = COLORS['dark_gray']
    
    add_hierarchical_bullets(slide, bullets, LEFT_MARGIN, Inches(1.8), CONTENT_WIDTH)
    return slide

def sanitize_table_data(table_data):
    clean_data = []

    if not table_data:
        return clean_data

    expected_cols = len(table_data[0])

    for row in table_data:
        if len(row) != expected_cols:
            continue

        clean_row = []
        for cell in row:
            cell = str(cell)

            # Remove control characters only
            cell = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', '', cell)

            # Remove stray pipes that break parsing
            cell = cell.replace('|', '')

            # Remove line breaks inside cells
            cell = cell.replace('\n', ' ').replace('\r', ' ').strip()

            clean_row.append(cell)

        clean_data.append(clean_row)

    return clean_data
def create_competitive_benchmarking_slides(prs, benchmarking_info):
    slides = []

    content = str(
        benchmarking_info.get('content', '')
        if isinstance(benchmarking_info, dict)
        else benchmarking_info
    )

    data = parse_markdown_table(content)
    if not data or len(data) <= 1:
        return slides

    header = data[0]
    rows = data[1:]

    # 🔥 Dynamically calculate how many rows fit
    usable_height = Inches(5.5)
    max_rows_fit = int(usable_height / TABLE_MIN_ROW_HEIGHT) - 1  # minus header row

    r_idx = 0
    page = 1

    while r_idx < len(rows):
        slide = prs.slides.add_slide(prs.slide_layouts[6])

        title = "Competitive Benchmark Table"
        if len(rows) > max_rows_fit:
            title += f" ({page})"

        add_title_to_slide(slide, title)

        chunk_rows = rows[r_idx:r_idx + max_rows_fit]

        chunk = sanitize_table_data([header] + chunk_rows)

        create_table_on_slide(
            slide,
            chunk,
            LEFT_MARGIN,
            Inches(1.4),
            CONTENT_WIDTH,
            usable_height
        )
        slides.append(slide)
        r_idx += max_rows_fit
        page += 1

    return slides
def create_swot_slides(prs, swot_info, benchmark_product):
    slides = []
    content = str(swot_info.get('content', '') if isinstance(swot_info, dict) else swot_info)
    sections = {'Strengths': [], 'Weaknesses': [], 'Opportunities': [], 'Threats': []}
    curr_sec = None; curr_txt = ""
    
    for line in content.split('\n'):
        l = line.lower().strip()
        if 'strength' in l and (':' in l or l.startswith('strength')):
            if curr_sec: sections[curr_sec] = parse_hierarchical_bullets(curr_txt)
            curr_sec = 'Strengths'; curr_txt = ""
        elif 'weakness' in l and (':' in l or l.startswith('weakness')):
            if curr_sec: sections[curr_sec] = parse_hierarchical_bullets(curr_txt)
            curr_sec = 'Weaknesses'; curr_txt = ""
        elif 'opportunit' in l and (':' in l or l.startswith('opportunit')):
            if curr_sec: sections[curr_sec] = parse_hierarchical_bullets(curr_txt)
            curr_sec = 'Opportunities'; curr_txt = ""
        elif 'threat' in l and (':' in l or l.startswith('threat')):
            if curr_sec: sections[curr_sec] = parse_hierarchical_bullets(curr_txt)
            curr_sec = 'Threats'; curr_txt = ""
        elif curr_sec: curr_txt += line + '\n'
    if curr_sec: sections[curr_sec] = parse_hierarchical_bullets(curr_txt)
    
    colors = {'Strengths': COLORS['dark_blue'], 'Weaknesses': COLORS['dark_red'], 
              'Opportunities': COLORS['teal'], 'Threats': COLORS['terracotta']}
    
    for sec, bullets in sections.items():
        if not bullets: continue
        curr = []; cnt = 0; page = 1
        for lvl, txt in bullets:
            if lvl == 0:
                cnt += 1
                if cnt > MAX_BULLETS_PER_SLIDE and curr:
                    slides.append(_swot_page(prs, sec, colors[sec], curr, page)); page += 1; curr = []
            curr.append((lvl, txt))
        if curr: slides.append(_swot_page(prs, sec, colors[sec], curr, page))
    return slides

def _swot_page(prs, sec, col, bullets, page):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    t = f"SWOT Analysis: {sec}"
    if page > 1: t += f" ({page})"
    add_title_to_slide(slide, t)
    
    sh = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, LEFT_MARGIN, Inches(1.3), Inches(3), Inches(0.5))
    sh.fill.solid(); sh.fill.fore_color.rgb = col
    sh.text_frame.paragraphs[0].text = sec; sh.text_frame.paragraphs[0].font.color.rgb = COLORS['white']
    sh.text_frame.paragraphs[0].alignment = PP_ALIGN.CENTER
    
    add_hierarchical_bullets(slide, bullets, LEFT_MARGIN, Inches(2.0), CONTENT_WIDTH)
    return slide

def create_ip_technology_slides(prs, ip_info):
    slides = []
    content = str(ip_info.get('content', '') if isinstance(ip_info, dict) else ip_info)
    content = re.sub(r'```\w*\n?', '', content).replace('```', '')
    
    items = []; curr = None
    for line in content.split('\n'):
        if not line.strip(): continue
        clean = clean_markdown_text(line)
        if 'COMPARATIVE INSIGHT' in clean.upper():
            if curr: items.append(curr)
            curr = {'company': clean, 'details': [], 'is_header': True}; continue
        
        is_head = line.strip().startswith(('•', '*')) and '/' in line
        if is_head:
            if curr: items.append(curr)
            curr = {'company': clean.lstrip('•*- '), 'details': [], 'is_header': False}
        elif curr:
            curr['details'].append(clean.lstrip('•*- '))
    if curr: items.append(curr)
    if not items: items = [{'company': 'Details', 'details': ['See report'], 'is_header': False}]

    curr_pg = []; slots = 0; page = 1
    for item in items:
        cost = 2 if item.get('is_header') else 1
        if slots + cost > 3 and curr_pg:
            slides.append(_ip_page(prs, curr_pg, page)); page += 1; curr_pg = []; slots = 0
        curr_pg.append(item); slots += cost
    if curr_pg: slides.append(_ip_page(prs, curr_pg, page))
    return slides

def _ip_page(prs, items, page):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    t = "IP & Technology Positioning"
    if page > 1: t += f" ({page})"
    add_title_to_slide(slide, t, include_subtitle=(page==1), subtitle_text="IP moat summary by player")
    
    top = Inches(1.6) if page == 1 else Inches(1.4)
    tb = slide.shapes.add_textbox(LEFT_MARGIN, top, CONTENT_WIDTH, Inches(5.5))
    tf = tb.text_frame; tf.word_wrap = True
    
    first = True
    for item in items:
        p = tf.paragraphs[0] if first else tf.add_paragraph(); first = False
        p.text = "• " + item['company']
        p.font.size = BODY_FONT_SIZE; p.font.bold = True
        p.font.color.rgb = COLORS['primary_red'] if item.get('is_header') else COLORS['dark_blue']
        p.space_before = Pt(16) if item.get('is_header') else Pt(10); p.space_after = Pt(4)
        
        for d in item['details']:
            p2 = tf.add_paragraph()
            p2.text = "    - " + re.sub(r'^[-–—]\s*', '', d)
            p2.font.size = SUB_BULLET_FONT_SIZE; p2.font.color.rgb = COLORS['text_dark']
    return slide

# ============================================================
# MAIN EXPORT
# ============================================================
def initialize_presentation(product_name, manufacturer="", product_image=None):
    prs = Presentation()
    prs.slide_width = SLIDE_WIDTH; prs.slide_height = SLIDE_HEIGHT
    create_title_slide(prs, product_name, manufacturer, product_image)
    return prs

def add_slide_to_presentation(slide_type, data, benchmark_product=""):
    prs = st.session_state.export_presentation
    if not prs:
        return False

    try:
        # Extract citations safely
        citations = []
        if isinstance(data, dict):
            citations = data.get("citations", [])

        # ---------------- PRODUCT ANCHOR ----------------
        if slide_type == 'product_anchor':
            slides = create_product_anchor_slides(prs, data, benchmark_product)
            for slide in slides:
                add_citations_to_notes(slide, citations)
                add_footer_note(slide)

        # ---------------- LIKE FOR LIKE ----------------
        elif slide_type == 'like_for_like':
            slides = create_like_for_like_slides(prs, data, benchmark_product)
            for slide in slides:
                add_citations_to_notes(slide, citations)
                add_footer_note(slide)

        # ---------------- COMPETITIVE BENCHMARKING ----------------
        elif slide_type == 'competitive_benchmarking':
            slides = create_competitive_benchmarking_slides(prs, data)
            for slide in slides:
                add_citations_to_notes(slide, citations)
                add_footer_note(slide)

        # ---------------- STRATEGIC ANALYSIS ----------------
        elif slide_type == 'strategic_analysis':
            slides = create_strategic_analysis_slides(prs, data, benchmark_product)
            for slide in slides:
                add_citations_to_notes(slide, citations)
                add_footer_note(slide)

        # ---------------- COST STRUCTURE ----------------
        elif slide_type == 'cost_structure':
            slides = create_cost_structure_slides(prs, data, benchmark_product)
            for slide in slides:
                add_citations_to_notes(slide, citations)
                add_footer_note(slide)

        # ---------------- SWOT ----------------
        elif slide_type == 'swot':
            slides = create_swot_slides(prs, data, benchmark_product)
            for slide in slides:
                add_citations_to_notes(slide, citations)
                add_footer_note(slide)

        # ---------------- IP & TECHNOLOGY ----------------
        elif slide_type == 'ip_technology':
            slides = create_ip_technology_slides(prs, data)
            for slide in slides:
                add_citations_to_notes(slide, citations)
                add_footer_note(slide)

        else:
            return False

        st.session_state.slides_added.add(slide_type)
        return True

    except Exception as e:
        st.error(f"Error adding slide: {e}")
        return False


def export_presentation_to_bytes():
    prs = st.session_state.export_presentation
    if not prs: return None
    buffer = BytesIO()
    prs.save(buffer)
    buffer.seek(0)
    return buffer