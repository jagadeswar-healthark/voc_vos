"""
Standalone Product Image Extractor using Selenium
This is a separate utility - integrate later when needed.

Requirements:
    pip install selenium pillow requests

Usage:
    from image_extractor import fetch_product_image
    
    image_bytes = fetch_product_image("Varioskan LUX", "Thermo Fisher Scientific")
    if image_bytes:
        # Use with pptx
        slide.shapes.add_picture(image_bytes, left, top, width=width)
"""

import requests
from io import BytesIO
from PIL import Image


def fetch_product_image(product_name, manufacturer):
    """
    Fetch product image from web using Selenium.
    
    Args:
        product_name: Name of the product (e.g., "Varioskan LUX")
        manufacturer: Manufacturer name (e.g., "Thermo Fisher Scientific")
    
    Returns:
        BytesIO object containing JPEG image, or None if not found
    """
    try:
        from selenium import webdriver
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.webdriver.chrome.options import Options
        
        print(f"🔍 Searching for product image: {manufacturer} {product_name}...")
        
        # Setup Chrome options for headless mode
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--window-size=1920,1080")
        chrome_options.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
        
        driver = webdriver.Chrome(options=chrome_options)
        wait = WebDriverWait(driver, 15)
        
        manufacturer_lower = manufacturer.lower() if manufacturer else ""
        img_url = None
        
        if 'thermo' in manufacturer_lower:
            # Thermo Fisher specific search
            url = "https://www.thermofisher.com/in/en/home/life-science/lab-equipment.html"
            driver.get(url)
            
            # Accept cookies if popup appears
            try:
                accept_btn = wait.until(EC.element_to_be_clickable((By.ID, "truste-consent-button")))
                accept_btn.click()
            except:
                pass
            
            # Search for product
            search_box = wait.until(EC.presence_of_element_located((By.ID, "suggest1")))
            search_box.clear()
            search_box.send_keys(product_name)
            
            search_button = driver.find_element(By.ID, "searchButton")
            search_button.click()
            
            # Wait for results
            wait.until(EC.presence_of_all_elements_located((By.CLASS_NAME, "search-card")))
            
            # Open first product card
            first_card_link = driver.find_element(By.CSS_SELECTOR, ".search-card .search-result-title-brand a")
            product_url = first_card_link.get_attribute("href")
            
            driver.execute_script("window.open(arguments[0], '_blank');", product_url)
            driver.switch_to.window(driver.window_handles[1])
            
            # Get product image
            product_img = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, ".pdp-item-image")))
            img_url = product_img.get_attribute("src")
            
            if img_url and img_url.startswith("/"):
                img_url = "https://www.thermofisher.com" + img_url
        
        else:
            # For other manufacturers, use Google Image Search
            import time
            search_query = f"{manufacturer} {product_name} product"
            url = f"https://www.google.com/search?q={search_query.replace(' ', '+')}&tbm=isch"
            
            driver.get(url)
            time.sleep(2)
            
            images = driver.find_elements(By.CSS_SELECTOR, "img.rg_i")
            for img in images[:5]:
                src = img.get_attribute("src") or img.get_attribute("data-src")
                if src and src.startswith("http") and "gstatic" not in src:
                    img_url = src
                    break
        
        driver.quit()
        
        if img_url:
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
            response = requests.get(img_url, stream=True, timeout=10, headers=headers)
            if response.status_code == 200:
                img = Image.open(BytesIO(response.content)).convert("RGB")
                img_buffer = BytesIO()
                img.save(img_buffer, format="JPEG", quality=90)
                img_buffer.seek(0)
                print(f"✅ Product image found and downloaded")
                return img_buffer
        
        print("❌ No product image found")
        return None
        
    except Exception as e:
        print(f"❌ Error fetching product image: {e}")
        try:
            driver.quit()
        except:
            pass
        return None


# Example usage
if __name__ == "__main__":
    # Test the function
    img = fetch_product_image("Varioskan LUX", "Thermo Fisher Scientific")
    if img:
        print("Image fetched successfully!")
        # Save to file for testing
        with open("test_product_image.jpg", "wb") as f:
            f.write(img.getvalue())
        print("Saved to test_product_image.jpg")
    else:
        print("Failed to fetch image")