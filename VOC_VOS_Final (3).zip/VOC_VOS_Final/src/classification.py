# modules/classification.py

import json
from src.pydantic_validation import ClassificationResult
from src.llm_client import get_azure_client
import os
from dotenv import load_dotenv
from src.requirement_generator import safe_json_loads
import streamlit as st

load_dotenv()
client = get_azure_client()
DEPLOYMENT_NAME = os.getenv("AZURE_DEPLOYMENT_NAME")

if not DEPLOYMENT_NAME:
    DEPLOYMENT_NAME = "gpt-4o"
    
def classify(cleaned_text: str,pruduct_name: str) -> ClassificationResult:

    system_prompt = """
You are a Technical VOC Analyst. Your goal is to extract specific entities from the text into a
SINGLE structured JSON record.
    """

    user_prompt = f"""
    *** YOUR TASK ***
    Analyze the following text block and product name basd on this output ONE JSON object:
    {cleaned_text} ,product name: {pruduct_name} 

  *** MAPPING RULES (Strict Adherence) ***
1. PRODUCT_LINE (The Broad Category):
   - Extract the highest-level product family mentioned.
   - Example: If text says "Lab Plastics", extract "Lab Plastics".
   - Example: If text says "Filtration Products", extract "Filtration Products".
2. SUBSYSTEM (The Specific Variant or Application):
   - Extract the specific types, applications, or sub-components mentioned.
   - Example: If text mentions "PCR and cell culture plastics", map this to SUBSYSTEM.
   - Example: If text mentions "membranes" or "caps", map this to SUBSYSTEM.
   - DO NOT put these in Product_Line. Keep Product_Line broad.
3. CUSTOMER_PAIN_POINT (The Full Narrative):
   - Consolidate ALL objections, risks, requirements, and needs into one continuous, comma-separated text.
   - Use the user's exact phrasing.
   - Include the "Why" (e.g., "perceived risk of experiment failures").
   - Include the "Solution" (e.g., "need for sterility certifications").
   if in excel or csv file, consider product name as well for classification.  and consider all row records which are related to product name and summarize pain points accordingly.
*** FEW-SHOT EXAMPLE (Your Exact Scenario) ***
Input: 
"Subject: Key objections - Lab Plastics Accounts Team. Across multiple accounts, the most common objection we’re hearing is not price but perceived risk. Customers worry about experiment failures if they switch suppliers, especially for PCR and cell culture plastics. When we provide sterility certifications, lot traceability, and proof of compatibility with major pipette brands, conversations move faster. Samples and limited pilots are critical to close these deals. Also seeing increased interest in sustainable packaging."

Output:
{{

  "product_line": "Lab Plastics",
  "subsystem": "PCR and cell culture plastics",
  "customer_pain_point": "Perceived risk of experiment failures when switching suppliers; need for sterility certifications, lot traceability, and proof of compatibility with major pipette brands; interest in sustainable packaging."

}}



  
    """

    response = client.chat.completions.create(
        model=DEPLOYMENT_NAME,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        temperature=0.0
    )

    try:
        
        content = response.choices[0].message.content
        if content is None:
            raise ValueError("Empty response content")
        # data = json.loads(content)
        data = safe_json_loads(content)
        return ClassificationResult(**data), response.usage.total_tokens
    except Exception:
        return ClassificationResult(
            product_line="Unknown",
            subsystem="Unknown",
            customer_pain_point=cleaned_text[:200]
        ), 0
