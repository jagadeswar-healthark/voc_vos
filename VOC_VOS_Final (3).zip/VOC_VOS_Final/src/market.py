import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from src.ingestion import load_files, read_pdf
import json
import os
import re
import numpy as np
from openai import OpenAI
from src.llm_client import get_azure_client
from dotenv import load_dotenv

load_dotenv()

client = get_azure_client()
API_KEY = "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"
client = OpenAI(api_key=API_KEY)

DEPLOYMENT_NAME = os.getenv("AZURE_DEPLOYMENT_NAME")

CUSTOM_CSS = """
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: 700;
        color: #1e40af;
        margin-bottom: 0.5rem;
    }
    .sub-header {
        font-size: 1.5rem;
        font-weight: 600;
        color: #1e40af;
        margin-bottom: 1rem;
        padding-bottom: 0.5rem;
    }
    .red-header {
        font-size: 1.3rem;
        font-weight: 600;
        color: #dc2626;
        margin-bottom: 0.8rem;
    }
    .card {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 0.5rem;
        padding: 1.5rem;
        line-height: 1.6;
    }
    .grey-box {
        background: #f3f4f6;
        border-left: 4px solid #6b7280;
        padding: 1rem;
        border-radius: 0.25rem;
        margin-top: 1rem;
    }
</style>
"""
st.session_state.market_analysis_button = False
st.session_state.market_uploaded_file = None
st.session_state.visualization_data = None
st.session_state.market_problem_opportunity = ""
st.session_state.market_size_potential = ""
st.session_state.market_run_completed = False

# Function to get the market problem or opportunity
def get_market_problem_opportunity(pdf_text, region, product_name, client, DEPLOYMENT_NAME):
    system_prompt = """
    You are an AI that helps generate market insights based on provided data. You need to analyze the current market problem or opportunity for the given product in the specified region. Your final output should be a single, concise paragraph, summarizing the main market problem or opportunity in 4 to 5 lines, without going into too much detail. The goal is to provide an easy-to-understand overview of the market situation for Thermo Fisher in this region.
    """
    user_prompt = f"""
    Analyze the market for the product '{product_name}' in the region '{region}'. Based on the provided PDF text, identify the main problem or opportunity in the market for Thermo Fisher in this region for the product.
    Text: {pdf_text}
    """
    response = client.chat.completions.create(
        model=DEPLOYMENT_NAME,
        messages=[{"role": "system", "content": system_prompt},
                  {"role": "user", "content": user_prompt}],
        temperature=0.1,
        seed=42,
    )
    return response.choices[0].message.content

# Function to generate market size and potential
def get_market_size_potential(pdf_text, region, product_name, client, DEPLOYMENT_NAME):
    system_prompt = """
    You are an AI that helps generate market size and potential insights based on the provided data. You need to analyze the market size and potential for the given product in the specified region. Your final output should be a single, concise paragraph, summarizing the key market size, growth potential, and revenue outlook in 4 to 5 lines, without going into too much detail. The goal is to provide a high-level overview of the market opportunity for Thermo Fisher in this region.
    """
    user_prompt = f"""
    Analyze the market for the product '{product_name}' in the region '{region}'. Based on the provided PDF text, extract the market size and potential in terms of revenue and growth rate for Thermo Fisher's product in this region.
    Text: {pdf_text}
    """
    response = client.chat.completions.create(
        model=DEPLOYMENT_NAME,
        messages=[{"role": "system", "content": system_prompt},
                  {"role": "user", "content": user_prompt}],
        temperature=0.1,
        seed=42,
    )
    return response.choices[0].message.content

# ENHANCED: Function to intelligently extract visualization data with AI-driven insights
def extract_visualization_data(pdf_text, region, product_name, client, DEPLOYMENT_NAME):
    system_prompt = """
    You are an advanced AI data analyst that extracts data for creating insightful visualizations from market research documents.
    
    Your task is to:
    1. Analyze the provided text and identify ALL relevant data points that can be visualized
    2. Extract standard metrics (sales by segment, competitor share, regional growth)
    3. USE YOUR INTELLIGENCE to identify additional meaningful metrics and relationships in the data
    4. Suggest NEW visualizations based on patterns, trends, or insights you discover
    
    Standard charts to extract:
    - Product Sales by Segment (bar chart)
    - Competitor Market Share (pie chart)
    - Regional Growth Matrix (heatmap with growth rate % and market size $B or $million)
    - Market Size Trends Over Time (line chart - if temporal data exists)
    - Price Point Analysis (bar/scatter chart - if pricing data exists)
    
    Intelligent/Discovery charts (analyze and suggest based on data):
    - Customer Segment Distribution (if customer data exists)
    - Technology Adoption Rates (if tech/innovation data exists)
    - Distribution Channel Performance (if channel data exists)
    - Product Portfolio Mix (if multiple products mentioned)
    - Regulatory Impact Analysis (if regulatory data exists)
    - Market Penetration by Country (if multi-country data exists)
    - CAGR Comparison Across Segments (if growth data exists)
    - Price vs Performance Matrix (if both metrics exist)
    - Market Maturity Index (analyze market development stage)
    - Opportunity Score by Region (create composite score from multiple factors)
    - Risk-Return Matrix (if enough data for analysis)
    - Customer Needs vs Current Offering Gap (if customer pain points and features exist)
    
    Return ONLY a valid JSON object with this structure:
    {
        "visualizations": [
            {
                "chart_name": "product_sales_by_segment",
                "chart_type": "bar",
                "chart_title": "Product Sales by Segment",
                "insight": "based on  the chart, and input text write detailed insight here ",
                "x_label": "Sales",
                "y_label": "Segment",
                "value_format": "billion",
                "data": {
                    "Segment1": 5.94,
                    "Segment2": 1.26
                }
            },
            {
                "chart_name": "competitor_market_share",
                "chart_type": "pie",
                "chart_title": "Competitor Market Share (2024)",
                "insight": "based on the chart, and input text write detailed insight here ",
                "value_format": "percentage",
                "data": {
                    "Competitor1": 5.6,
                    "Competitor2": 5.6
                }
            },
            {
                "chart_name": "growth_matrix",
                "chart_type": "heatmap",
                "chart_title": "Growth Matrix for Regions",
                "insight": "based on the chart, and input text write detailed insight here ",
                "x_label": "Metrics",
                "y_label": "Region",
                "value_format": "mixed",
                "data": {
                    "Region1": [8.7, 19.60],
                    "Region2": [8.3, 14.51]
                }
            },
            {
                "chart_name": "market_trends_timeline",
                "chart_type": "line",
                "chart_title": "Market Size Evolution (2020-2025)",
                "insight": "based on the chart, and input text write detailed insight here ",
                "x_label": "Year",
                "y_label": "Market Size",
                "value_format": "million",
                "data": {
                    "2020": 45.2,
                    "2021": 48.1,
                    "2022": 52.3
                }
            }
        ]
    }
    
    Chart type options: "bar", "pie", "heatmap", "line", "scatter", "grouped_bar", "stacked_bar"
    
    IMPORTANT - For each chart, specify:
    - x_label: Label for x-axis (e.g., "Revenue", "Year", "Price")
    - y_label: Label for y-axis (e.g., "Segment", "Growth Rate", "Market Share")
    - value_format: One of ["billion", "million", "thousand", "percentage", "number", "currency", "mixed"]
      * "billion" - values in billions ($5.94B)
      * "million" - values in millions ($120.5M)
      * "thousand" - values in thousands ($45.2K)
      * "percentage" - values as percentages (23.5%)
      * "number" - plain numbers (1234)
      * "currency" - currency values ($1,234.56)
      * "mixed" - for heatmaps with different units
    
    For data format based on chart_type:
    - bar/pie: {"Category1": value1, "Category2": value2}
    - line: {"X1": Y1, "X2": Y2} (often time series)
    - heatmap: {"Row1": [col1_val, col2_val], "Row2": [col1_val, col2_val]}
    - scatter: {"point1": [x, y], "point2": [x, y]}
    - grouped_bar: {"Category1": {"Group1": val, "Group2": val}, "Category2": {...}}
    
    Be creative and insightful. If you find interesting patterns, create visualizations for them.
    Only include charts where you have actual data. Use empty dict {} if no data available.
    """
    
    user_prompt = f"""
    Analyze this market research document for '{product_name}' in '{region}'.
    
    Extract ALL standard metrics AND intelligently identify new visualization opportunities.
    Look for:
    - Sales figures across different dimensions
    - Competitor information and positioning
    - Growth rates, market sizes, trends over time
    - Pricing data, customer segments, distribution channels
    - Technology trends, regulatory factors, market dynamics
    - ANY other numerical data or patterns that would benefit from visualization
    
    For each visualization, provide a brief insight about what it reveals.
    
    Document Text:
    {pdf_text}
    """
    
    response = client.chat.completions.create(
        model=DEPLOYMENT_NAME,
        messages=[{"role": "system", "content": system_prompt},
                  {"role": "user", "content": user_prompt}],
        temperature=0.3,  # Slightly higher for creativity in finding patterns
        seed=42,
        response_format={"type": "json_object"}
    )
    
    raw_text = response.choices[0].message.content
    
    # Parse the JSON response
    try:
        parsed = json.loads(raw_text)
        if isinstance(parsed, dict) and 'visualizations' in parsed:
            return parsed['visualizations']
        elif isinstance(parsed, dict) and 'charts' in parsed:
            return parsed['charts']
        elif isinstance(parsed, list):
            return parsed
        else:
            return [parsed]
    except json.JSONDecodeError as e:
        st.error(f"Error parsing LLM response: {e}")
        st.text(f"Raw response: {raw_text}")
        return []

# Helper function to format values based on format type
def format_value(value, format_type):
    """Format numerical values with appropriate suffixes"""
    if format_type == "billion":
        return f"${value:.2f}B"
    elif format_type == "million":
        return f"${value:.2f}M"
    elif format_type == "thousand":
        return f"${value:.2f}K"
    elif format_type == "percentage":
        return f"{value:.1f}%"
    elif format_type == "currency":
        return f"${value:,.2f}"
    elif format_type == "number":
        return f"{value:,.0f}"
    else:
        return f"{value:.2f}"

def get_axis_label_with_unit(label, format_type):
    """Add unit information to axis label"""
    unit_map = {
        "billion": "($ Billions)",
        "million": "($ Millions)",
        "thousand": "($ Thousands)",
        "percentage": "(%)",
        "currency": "($)",
        "number": ""
    }
    unit = unit_map.get(format_type, "")
    return f"{label} {unit}".strip()

# Enhanced visualization functions

def visualize_bar_chart(data, title, xlabel="Value", ylabel="Category", value_format="number"):
    if not data:
        return None
    
    categories = list(data.keys())
    values = list(data.values())
    
    df = pd.DataFrame({ylabel: categories, xlabel: values})
    
    fig, ax = plt.subplots(figsize=(10, 6))
    bars = ax.barh(df[ylabel], df[xlabel], color=sns.color_palette("viridis", len(categories)))
    ax.set_xlabel(get_axis_label_with_unit(xlabel, value_format), fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=14, fontweight='bold')
    
    # Add value labels on bars
    for i, (bar, value) in enumerate(zip(bars, values)):
        width = bar.get_width()
        ax.text(width, bar.get_y() + bar.get_height()/2, 
                f' {format_value(value, value_format)}',
                ha='left', va='center', fontsize=10, fontweight='bold')
    
    plt.tight_layout()
    return fig

def visualize_pie_chart(data, title, value_format="percentage"):
    if not data:
        return None
    
    labels = list(data.keys())
    sizes = list(data.values())
    
    fig, ax = plt.subplots(figsize=(8, 8))
    colors = sns.color_palette("Set2", len(labels))
    
    # Custom autopct to show formatted values
    def make_autopct(values, format_type):
        def my_autopct(pct):
            total = sum(values)
            val = pct * total / 100.0
            if format_type == "percentage":
                return f'{pct:.1f}%'
            else:
                return f'{pct:.1f}%\n({format_value(val, format_type)})'
        return my_autopct
    
    ax.pie(sizes, labels=labels, autopct=make_autopct(sizes, value_format), 
           startangle=140, colors=colors, textprops={'fontsize': 10})
    ax.set_title(title, fontsize=14, fontweight='bold', pad=20)
    
    plt.tight_layout()
    return fig

def visualize_heatmap(data, title, col_labels=None, value_format="number", x_label="Metrics", y_label="Categories"):
    if not data:
        return None
    
    rows = list(data.keys())
    
    # Handle different data formats
    if isinstance(list(data.values())[0], list):
        matrix = np.array([data[row] for row in rows])
        if col_labels is None:
            col_labels = [f"Metric {i+1}" for i in range(matrix.shape[1])]
    else:
        # Single column heatmap
        matrix = np.array([[v] for v in data.values()])
        col_labels = ["Value"]
    
    fig, ax = plt.subplots(figsize=(10, 7))
    
    # Format annotations based on value_format
    if value_format == "mixed":
        # For mixed formats, assume first column is percentage, second is billion
        annot_matrix = np.empty(matrix.shape, dtype=object)
        for i in range(matrix.shape[0]):
            for j in range(matrix.shape[1]):
                if j == 0:
                    annot_matrix[i, j] = f"{matrix[i, j]:.1f}%"
                else:
                    annot_matrix[i, j] = f"${matrix[i, j]:.2f}B"
        sns.heatmap(matrix, annot=annot_matrix, fmt='', xticklabels=col_labels,
                    yticklabels=rows, cmap="YlOrRd", ax=ax, cbar_kws={'label': 'Value'})
    else:
        sns.heatmap(matrix, annot=True, xticklabels=col_labels,
                    yticklabels=rows, cmap="YlOrRd", ax=ax, fmt='.2f', 
                    cbar_kws={'label': get_axis_label_with_unit('Value', value_format)})
    
    ax.set_xlabel(x_label, fontsize=12, fontweight='bold')
    ax.set_ylabel(y_label, fontsize=12, fontweight='bold')
    ax.set_title(title, fontsize=14, fontweight='bold')
    
    plt.tight_layout()
    return fig

def visualize_line_chart(data, title, xlabel="Time", ylabel="Value", value_format="number"):
    if not data:
        return None
    
    x_vals = list(data.keys())
    y_vals = list(data.values())
    
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(x_vals, y_vals, marker='o', linewidth=2, markersize=8, color='#2E86AB')
    ax.set_xlabel(xlabel, fontsize=12, fontweight='bold')
    ax.set_ylabel(get_axis_label_with_unit(ylabel, value_format), fontsize=12, fontweight='bold')
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3)
    
    # Add value labels on points
    for i, (x, y) in enumerate(zip(x_vals, y_vals)):
        ax.annotate(format_value(y, value_format), 
                   (x, y), 
                   textcoords="offset points", 
                   xytext=(0, 10), 
                   ha='center',
                   fontsize=9,
                   fontweight='bold')
    
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    return fig

def visualize_scatter_plot(data, title, xlabel="X", ylabel="Y", value_format="number"):
    if not data:
        return None
    
    points = list(data.keys())
    coords = list(data.values())
    
    x_vals = [coord[0] for coord in coords]
    y_vals = [coord[1] for coord in coords]
    
    fig, ax = plt.subplots(figsize=(10, 7))
    scatter = ax.scatter(x_vals, y_vals, s=100, alpha=0.6, c=range(len(points)), cmap='viridis')
    
    for i, point in enumerate(points):
        ax.annotate(f'{point}\n({format_value(x_vals[i], value_format)}, {format_value(y_vals[i], value_format)})', 
                   (x_vals[i], y_vals[i]), 
                   fontsize=9, 
                   alpha=0.8,
                   xytext=(5, 5),
                   textcoords='offset points')
    
    ax.set_xlabel(get_axis_label_with_unit(xlabel, value_format), fontsize=12, fontweight='bold')
    ax.set_ylabel(get_axis_label_with_unit(ylabel, value_format), fontsize=12, fontweight='bold')
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    return fig

def visualize_grouped_bar(data, title, value_format="number", x_label="Category", y_label="Value"):
    if not data:
        return None
    
    # Convert nested dict to DataFrame
    df = pd.DataFrame(data).T
    
    fig, ax = plt.subplots(figsize=(12, 6))
    df.plot(kind='bar', ax=ax, rot=45, colormap='Set3')
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.set_xlabel(x_label, fontsize=12, fontweight='bold')
    ax.set_ylabel(get_axis_label_with_unit(y_label, value_format), fontsize=12, fontweight='bold')
    ax.legend(title="Groups", bbox_to_anchor=(1.05, 1), loc='upper left')
    ax.grid(True, alpha=0.3, axis='y')
    
    plt.tight_layout()
    return fig

def visualize_stacked_bar(data, title, value_format="number", x_label="Category", y_label="Value"):
    if not data:
        return None
    
    df = pd.DataFrame(data).T
    
    fig, ax = plt.subplots(figsize=(12, 6))
    df.plot(kind='bar', stacked=True, ax=ax, rot=45, colormap='Spectral')
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.set_xlabel(x_label, fontsize=12, fontweight='bold')
    ax.set_ylabel(get_axis_label_with_unit(y_label, value_format), fontsize=12, fontweight='bold')
    ax.legend(title="Components", bbox_to_anchor=(1.05, 1), loc='upper left')
    ax.grid(True, alpha=0.3, axis='y')
    
    plt.tight_layout()
    return fig

# Function to render visualizations based on chart data
def render_visualization(chart_info):
    chart_name = chart_info.get("chart_name", "")
    chart_type = chart_info.get("chart_type", "bar")
    chart_title = chart_info.get("chart_title", "Chart")
    data = chart_info.get("data", {})
    value_format = chart_info.get("value_format", "number")
    x_label = chart_info.get("x_label", "Value")
    y_label = chart_info.get("y_label", "Category")
    
    # Route to appropriate visualization function
    if chart_type == "bar":
        return visualize_bar_chart(data, chart_title, x_label, y_label, value_format)
    elif chart_type == "pie":
        return visualize_pie_chart(data, chart_title, value_format)
    elif chart_type == "heatmap":
        # For growth matrix, use specific labels
        if "growth" in chart_name.lower() and "matrix" in chart_name.lower():
            return visualize_heatmap(data, chart_title, ['Growth Rate (%)', 'Market Size ($B)'], 
                                   value_format, x_label, y_label)
        else:
            return visualize_heatmap(data, chart_title, None, value_format, x_label, y_label)
    elif chart_type == "line":
        return visualize_line_chart(data, chart_title, x_label, y_label, value_format)
    elif chart_type == "scatter":
        return visualize_scatter_plot(data, chart_title, x_label, y_label, value_format)
    elif chart_type == "grouped_bar":
        return visualize_grouped_bar(data, chart_title, value_format, x_label, y_label)
    elif chart_type == "stacked_bar":
        return visualize_stacked_bar(data, chart_title, value_format, x_label, y_label)
    else:
        st.warning(f"Unknown chart type: {chart_type}")
        return None

# Streamlit UI integration
def market_insights():
    col1, col2 = st.columns([5,5])
    with col1:
       st.markdown('<div class="sub-header">📋 Market Analysis and Insights </div>', unsafe_allow_html=True)
    
    col11,col12 = st.columns([5,5])
    
    with col11:
        product_name = st.text_input("Enter Product Name", "Refrigeration Equipment")
    with col12:
        region = st.selectbox("Select Region", ["North America", "Europe", "APAC", "MEA", "LATAM"])

    with st.sidebar:
        # Inputs from the user 
        
        
        # Upload PDF text content
        st.session_state.market_uploaded_file = st.file_uploader("Upload Market Research Document (PDF/TXT)", type=["txt", "pdf"])
    
    if st.session_state.market_uploaded_file is None :

        if st.session_state.market_run_completed == True:
           pass
        else:
            st.info("👈 Upload data to start")
            st.session_state.market_run_completed == False
            return
    
    # Generate Market Report
    with col2:
        st.session_state.market_analysis_button = False
        if st.button("🚀 Generate Intelligent Market Report", type="primary"):
            st.session_state.market_analysis_button = True

    if st.session_state.market_analysis_button:
        with st.spinner("Analyzing document and generating insights..."):
            temp_dir = "temp_files"
            os.makedirs(temp_dir, exist_ok=True)
            temp_file_path = os.path.join(temp_dir, st.session_state.market_uploaded_file.name)

            with open(temp_file_path, "wb") as f:
                f.write(st.session_state.market_uploaded_file.getbuffer())

            pdf_text = read_pdf(temp_file_path)
            
            
            st.session_state.market_problem_opportunity = get_market_problem_opportunity(
                    pdf_text, region, product_name, client, DEPLOYMENT_NAME
                )
            st.session_state.market_size_potential = get_market_size_potential(
                    pdf_text, region, product_name, client, DEPLOYMENT_NAME
                )
            
            st.session_state.visualization_data = extract_visualization_data(
                pdf_text, region, product_name, client, DEPLOYMENT_NAME
            )
            st.session_state.market_run_completed = True
            
    if st.session_state.market_run_completed:
            
            col1, col2 = st.columns(2)
            
            with col1:
                
                st.subheader("🎯 Problem/Opportunity")
                st.info(st.session_state.market_problem_opportunity)
            
            with col2:
                
                st.subheader("💰 Market Size & Potential")
                st.info(st.session_state.market_size_potential)
            
            st.divider()
            
            
            
            # Display extracted data for debugging
            with st.expander("🔍 View AI-Extracted Visualization Data (JSON)"):
                st.json(st.session_state.visualization_data)
            
            # Render each visualization
            if st.session_state.visualization_data:
                # Organize visualizations in a grid
                num_charts = len(st.session_state.visualization_data)
                
                for idx in range(0, num_charts, 2):
                    # Create two columns
                    col1, col2 = st.columns(2)
                    
                    # First chart in left column
                    with col1:
                        chart_info = st.session_state.visualization_data[idx]
                        chart_title = chart_info.get("chart_title", "Chart")
                        insight = chart_info.get("insight", "")
                        
                        st.subheader(f"📊 {chart_title}")
                        
                        if insight:
                            st.markdown(f"**AI Insight:** *{insight}*")
                        
                        fig = render_visualization(chart_info)
                        if fig:
                            st.pyplot(fig)
                            plt.close(fig)
                        else:
                            st.info(f"No data available for {chart_title}")
                    
                    # Second chart in right column (if exists)
                    with col2:
                        if idx + 1 < num_charts:
                            chart_info = st.session_state.visualization_data[idx + 1]
                            chart_title = chart_info.get("chart_title", "Chart")
                            insight = chart_info.get("insight", "")
                            
                            st.subheader(f"📊 {chart_title}")
                            
                            if insight:
                                st.markdown(f"**AI Insight:** *{insight}*")
                            
                            fig = render_visualization(chart_info)
                            if fig:
                                st.pyplot(fig)
                                plt.close(fig)
                            else:
                                st.info(f"No data available for {chart_title}")
                    
                    # Add separator between rows (but not after last row)
                    if idx + 2 < num_charts:
                        st.divider()
                
                # Summary stats
                st.success(f"✅ Generated {len(st.session_state.visualization_data)} visualizations from the document")
            else:
                st.warning("⚠️ No visualization data could be extracted from the document. Please ensure the document contains numerical data and market insights.")