
import os
import json
import requests
from typing import List, Dict, Any
from dotenv import load_dotenv

import streamlit as st

# Load environment variables
load_dotenv()



# ==================== CONFIGURATION ====================
PERPLEXITY_API_KEY = os.getenv('PERPLEXITY_API_KEY')
AZURE_API_KEY = os.getenv('AZURE_GEMINI_KEY')
PERPLEXITY_API_URL = "https://api.perplexity.ai/chat/completions"
PERPLEXITY_MODEL = "sonar"

if not PERPLEXITY_API_KEY:
    st.error("❌ Perplexity API key not found. Please set PERPLEXITY_API_KEY in .env file")
    st.stop()

# ==================== UTILITY ====================
def get_gemini_client():
    try:
        from openai import OpenAI
        if not AZURE_API_KEY: return None
        return OpenAI(
            base_url="https://api.geneai.thermofisher.com/dev/gemini/deployments/gemini-2.0-flash",
            api_key="", default_headers={"api-key": AZURE_API_KEY},
        )
    except ImportError: return None

    
def generate_strategic_fit(comp_a: str, comp_b: str, product: str) -> Dict:
    # 1. Define the Prompt with "Style Transfer" instructions
    query = f"""
    Act as a Product Strategy Director. Create a "Strategic Fit" analysis comparing "{comp_a}" (Benchmark) vs "{comp_b}" (Challenger) for {product}.

    ### REQUIREMENT 1: PRICING DATA (Estimates Required)
    Estimate List Prices (USD) for 3 sizes: Small (~23 cu.ft), Medium (~30 cu.ft), Large (~50 cu.ft).
    * Prices MUST increase with size.
    * Prices MUST be non-zero integers.

    ### REQUIREMENT 2: STRATEGIC TEXT (Style Transfer)
    Generate 5 bullet points analyzing the fit. 
    CRITICAL: You must use the **sentence structure** below, but replace the [Bracketed Content] with REAL facts about {comp_a} and {comp_b}.

    * "Similar feature set between {comp_a} and {comp_b} [Mention key shared spec]"
    * "Differentiated messaging – {comp_b} will not have sufficient [Key Performance Metric] for [Target High-End App]"
    * "{comp_a} positioned as only suitable option for [Critical Use Case]"
    * "{comp_b} limitation – [Mention a specific lower spec, e.g. Controller Type, Recovery Time, or Warranty] (Cannot guarantee stability for [Use Case])"
    * "Maintain ~[20-40]% delta between {comp_a} and {comp_b} dealer pricing"

    Output strictly valid JSON:
    {{
        "prices": {{
            "{comp_a}": [price_s, price_m, price_l],
            "{comp_b}": [price_s, price_m, price_l]
        }},
        "sizes": ["23 cu.ft", "30 cu.ft", "50 cu.ft"],
        "strategy_text": [
            "Bullet 1 (Feature comparison)",
            "Bullet 2 (The Messaging Gap)",
            "Bullet 3 (The 'Premium' Positioning)",
            "Bullet 4 (The Technical Limitation)",
            "Bullet 5 (The Pricing Delta Goal)"
        ],
        "highlight_box": "Differentiation will be achieved by focusing training and messaging around customer applications"
    }}
    """
    
    # Smart Fallback Data (If API fails, use this generic "Premium vs Value" template)
    default_data = {
        "prices": {comp_a: [7500, 8500, 10500], comp_b: [5500, 6200, 7800]},
        "sizes": ["23 cu.ft", "30 cu.ft", "50 cu.ft"],
        "strategy_text": [
            f"Similar feature set between {comp_a} and {comp_b}, both offering standard microprocessor controls.",
            f"Differentiated messaging – {comp_b} lacks the advanced recovery speed required for frequent door openings.",
            f"{comp_a} positioned as the only suitable option for critical GMP/GLP storage applications.",
            f"{comp_b} limitation – Standard Compressor Cycle (Cannot guarantee tight uniformity during peak usage).",
            f"Maintain ~30% delta between {comp_a} and {comp_b} dealer pricing to protect margin."
        ],
        "highlight_box": "Differentiation driven by application-specific performance messaging."
    }

    try:
        # 1. Get raw data from Perplexity
        client = get_gemini_client()
        if not client: return default_data

        raw_content = ""
        try:
            px_payload = {"model": PERPLEXITY_MODEL, "messages": [{"role": "user", "content": query}]}
            px_res = requests.post(PERPLEXITY_API_URL, headers={"Authorization": f"Bearer {PERPLEXITY_API_KEY}"}, json=px_payload).json()
            if "choices" in px_res:
                raw_content = px_res["choices"][0]["message"]["content"]
        except:
            raw_content = "" 

        # 2. Structure with Gemini (Force it to generate estimates if Perplexity failed)
        res = client.chat.completions.create(
            model="gemini-2.0-flash",
            messages=[
                {"role": "system", "content": "You are a Strategy Consultant. Generate realistic strategic analysis. Output valid JSON."},
                {"role": "user", "content": f"Extract JSON from this research. If empty, generate the JSON yourself based on the prompt requirements:\n\nPrompt: {query}\n\nResearch: {raw_content}"}
            ],
            temperature=0.2
        )
        
        clean_json = res.choices[0].message.content.replace("```json", "").replace("```", "").strip()
        data = json.loads(clean_json)
        
        # --- DATA CLEANING (Fixes Flat Lines) ---
        for company in [comp_a, comp_b]:
            prices = data["prices"].get(company, [0,0,0])
            
            # If empty or all zero, generate a synthetic curve
            if not prices or sum(prices) == 0:
                base = 6000 if company == comp_a else 4500
                data["prices"][company] = [base, int(base*1.2), int(base*1.5)]
            
            # If flat line (all same price), create a synthetic curve
            elif len(set(prices)) == 1:
                base = prices[0]
                data["prices"][company] = [base, int(base*1.2), int(base*1.5)]
                
            # Ensure strictly 3 points
            data["prices"][company] = data["prices"][company][:3]
            
        return data

    except Exception as e:
        print(f"Strategic Fit Error: {e}")
        return default_data