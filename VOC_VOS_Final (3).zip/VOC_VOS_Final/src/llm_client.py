# modules/llm_client.py

import os
from dotenv import load_dotenv
from openai import AzureOpenAI


load_dotenv()

def get_azure_client():
    """
    Initializes and returns Azure OpenAI client.
    """

    AZURE_KEY = os.getenv("AZURE_OPENAI_KEY")
    AZURE_ENDPOINT = os.getenv("AZURE_ENDPOINT")
    AZURE_VERSION = os.getenv("AZURE_VERSION", "2024-05-01-preview")

    if not AZURE_KEY or not AZURE_ENDPOINT:
        raise ValueError("Azure OpenAI environment variables are not set")

    client = AzureOpenAI(
        api_key=AZURE_KEY,
        api_version=AZURE_VERSION,
        azure_endpoint=AZURE_ENDPOINT,
    )

    return client
