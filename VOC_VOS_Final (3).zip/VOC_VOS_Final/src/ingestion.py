# modules/ingestion.py

# modules/ingestion.py
import os
from docx import Document
import openpyxl
import fitz  # PyMuPDF
import pdfplumber


def read_txt(path: str) -> str:
    # Best-effort utf-8 read
    for enc in ("utf-8", "utf-8-sig", "cp1252", "latin-1"):
        try:
            with open(path, "r", encoding=enc, errors="strict") as f:
                return f.read()
        except Exception:
            pass
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def read_docx(path: str) -> str:

    doc = Document(path)
    parts = []
    for p in doc.paragraphs:
        if p.text and p.text.strip():
            parts.append(p.text.strip())
    # include table cells if present
    for t in doc.tables:
        for row in t.rows:
            for cell in row.cells:
                txt = (cell.text or "").strip()
                if txt:
                    parts.append(txt)
    return "\n".join(parts)

def read_xlsx(xlsx_path):
    """Extracts text from an XLSX file."""
    text = "Extracted data from XLSX file:\n"
    try:
        workbook = openpyxl.load_workbook(xlsx_path)
        for sheet in workbook.sheetnames:
            worksheet = workbook[sheet]
            for row in worksheet.iter_rows():
                for cell in row:
                    if cell.value is not None:
                        text += str(cell.value ) + " | "
                text += "\n"
    except Exception as e:
        print(f"Error processing XLSX file {xlsx_path}: {e}")
    return text.strip() + "\n"

def read_csv(csv_path):
    """Extracts text from a CSV file."""
    text = "Extracted data from CSV file:\n"
    try:
        with open(csv_path, "r", encoding="utf-8") as f:
            for line in f:
                text += line.strip() + "\n"
    except Exception as e:
        print(f"Error processing CSV file {csv_path}: {e}")
    return text.strip() + "\n"

def read_pdf(pdf_path):
    """
    Extract text and tables from a PDF file, merged into one string.
    Returns:
      - result (str): Text + tables combined
    """
    pdf_name = os.path.basename(pdf_path)
    result = "file name: " + pdf_name + "\n\n"

    # 1️⃣ Extract text with fitz
    with fitz.open(pdf_path) as doc:
        for page in doc:
            result += page.get_text("text") + "\n"
    

    # 2️⃣ Extract tables with pdfplumber
    table_strings = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page_num, page in enumerate(pdf.pages, start=1):
            tables = page.extract_tables()
            for i, table in enumerate(tables, start=1):
                if table:
                    headers = [cell if cell else "" for cell in table[0]]
                    table_str = f"\n--- Page {page_num} | Table {i} ---\n"
                    table_str += "headers:- " + "| ".join(headers) + "\n"

                    # Add each row with prefix "rows:"
                    i=1
                    for row in table[1:]:
                        row_str = "| ".join(cell if cell else "" for cell in row)
                        table_str += f"\n row_{i}: " + row_str + "\n"
                        i+=1


                    table_strings += table_str

    # Merge text + tables
    if table_strings:
        result += "\n\nExtracted Tables:\n" + table_strings

    return result


def load_files(data_dir):
    docs = []
    for root, _, files in os.walk(data_dir):
        for f in files:
            
            if f.endswith(".txt"):
                    docs.append({
                        "filename": f,
                        "raw_text": read_txt(os.path.join(root, f))
                    })
            if f.endswith(".docx"):
                    docs.append({
                        "filename": f,
                        "raw_text": read_docx(os.path.join(root, f))
                    })
            if f.endswith(".xlsx"):
                    docs.append({
                        "filename": f,
                        "raw_text": read_xlsx(os.path.join(root, f))
                    })
            if f.endswith(".csv"):
                    docs.append({
                        "filename": f,
                        "raw_text": read_csv(os.path.join(root, f))
                    })
            if f.endswith(".pdf"):
                    docs.append({
                        "filename": f,
                        "raw_text": read_pdf(os.path.join(root, f))
                    })

    return docs
