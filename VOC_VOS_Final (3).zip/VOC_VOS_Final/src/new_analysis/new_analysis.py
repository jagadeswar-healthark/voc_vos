
import os
import json
import requests
from typing import List, Dict, Any
from dotenv import load_dotenv
import re
import streamlit as st
from openai import OpenAI
# Load environment variables
load_dotenv()



# ==================== CONFIGURATION ====================
PERPLEXITY_API_KEY = os.getenv('PERPLEXITY_API_KEY')
AZURE_API_KEY = os.getenv('AZURE_GEMINI_KEY')
PERPLEXITY_API_URL = "https://api.perplexity.ai/chat/completions"
PERPLEXITY_MODEL = "sonar"

# GPT
API_KEY = "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" # <--- PASTE KEY HERE
client = OpenAI(api_key=API_KEY)


if not PERPLEXITY_API_KEY:
    st.error("❌ Perplexity API key not found. Please set PERPLEXITY_API_KEY in .env file")
    st.stop()

# ==================== UTILITY ====================
def get_gemini_client():
    try:
        from openai import OpenAI
        if not AZURE_API_KEY: return None
        return OpenAI(
            base_url="https://api.geneai.thermofisher.com/dev/gemini/deployments/gemini-2.0-flash",
            api_key="", default_headers={"api-key": AZURE_API_KEY},
        )
    except ImportError: return None

# ==================== STEP 1: DISCOVER (Updated: Normalize Thermo Fisher) ====================
def discover_companies(region: str, product: str) -> Dict:
    query = f"""
Using Thermo Fisher Scientific as the benchmark, identify the TOP 10 companies or brands that customers realistically recognize, evaluate, and shortlist when purchasing "{product}" in {region}.

OBJECTIVE:
- Surface the most commercially relevant and customer-facing competitors for "{product}".
- Focus on how buyers actually shortlist vendors, not theoretical market participants.

SELECTION CRITERIA (apply strictly and rank in this exact order):
1. Market leaders cited in analyst reports (ResearchAndMarkets, Grand View Research, Mordor Intelligence)
2. Vendors most frequently referenced on lab comparison and review platforms (SelectScience, Labcompare)
3. Companies with at least TWO purchasable HARDWARE product families in this category
4. Global OEM or private-label manufacturers (EXCLUDE distributors, resellers, integrators)
5. Strong regional players, ONLY if credible {region}-specific market presence exists

CRITICAL COMPANY / BRAND LISTING RULES:
- List companies strictly at the BRAND LEVEL that customers recognize and shortlist.
- The list may include:
  • OEM manufacturers
  • Strong customer-facing brands
- DO NOT list product lines, series, platforms, or model families.
- DO NOT list both a parent company and its brand separately.
  • If a brand is owned by a parent company, list ONLY the brand.
  • Ownership clarification will be handled in later steps.
- DO NOT merge brand and parent names.
  • Example: "BioTek" (NOT "Agilent BioTek")
  • Example: "Molecular Devices" (NOT "Danaher")
- Each listed company must have an active, commercially meaningful presence in the "{product}" category.

THERMO FISHER SCIENTIFIC RULE (MANDATORY):
- If Thermo Fisher Scientific is relevant to "{product}", it MUST appear within the FIRST 3 positions.

OUTPUT FORMAT (STRICT):
- Output EXACTLY 10 companies
- One company per bullet point
- Company name ONLY (no descriptions, no parentheses, no notes)
- Do NOT include explanations or commentary

OUTPUT EXAMPLE (illustrative only):
- Company Name 1
- Company Name 2
- Company Name 3
...
- Company Name 10
"""

    try:
        res = requests.post(PERPLEXITY_API_URL, headers={"Authorization": f"Bearer {PERPLEXITY_API_KEY}"}, json={"model": PERPLEXITY_MODEL, 
            "messages": [
            {
                "role": "system",
                "content": (
                    "You are a market intelligence analyst. "
                    "Follow selection criteria strictly and output ONLY company names."
                )
            },
            {
                "role": "user",
                "content": query
            }
            ], "temperature": 0.0}).json()
        content = res["choices"][0]["message"]["content"]
        
        companies = []
        citations = res.get("citations", [])
        
        for line in content.splitlines():
            # 1. Cleaning
            clean = line.replace('**', '')
            clean = re.sub(r'\[[\d,\s]+\]', '', clean)
            clean = re.sub(r'\s*\(.*?\)', '', clean)
            clean = re.sub(r'^[\d\-\.\s]+', '', clean)
            clean = clean.strip()
            
            # 2. Validity Check
            if (len(clean) > 2) and (len(clean) < 50) and (":" not in clean) and ("Here" not in clean):
                
                # --- NORMALIZE THERMO FISHER NAMES ---
                # Check for variations and standardize to parent company
                lower_clean = clean.lower()
                if "thermo scientific" in lower_clean or "fisher scientific" in lower_clean or "thermo fisher" in lower_clean:
                    clean = "Thermo Fisher Scientific"
                # -------------------------------------

                companies.append(clean)
        
        # 3. Deduplicate (Preserving Order)
        # This handles cases where the AI listed both "Thermo Scientific" and "Fisher Scientific"
        seen = set()
        unique_companies = []
        for c in companies:
            if c not in seen:
                unique_companies.append(c)
                seen.add(c)
                
        return {"companies": unique_companies[:10], "status": "success"}, citations
    except Exception as e:
        return {"error": str(e), "status": "error"}, []
    
# ==================== STEP 2: GATHER INTELLIGENCE (Updated: Strict Validation) ====================
def retrieve_company_data(company: str, product: str, region: str) -> Dict:

   
    query = f"""
    Act as a senior Market Research Analyst. Perform a rigorous market assessment of {company}'s "{product}" portfolio in {region} using ONLY information from the top 10 most authoritative and credible industry sources.

Your task is to validate product ownership, brand positioning, and market standing with evidence-driven reasoning. Accuracy is critical.

────────────────────────────────────────
CRITICAL ENFORCEMENT RULES
────────────────────────────────────────

1. PRODUCT VERIFICATION  
   - Confirm that each product line listed is genuinely owned and marketed by {company}.  
   - Do NOT misattribute well-known product families to incorrect manufacturers  
     (e.g., Do NOT assign "SpectraMax" to Thermo Fisher).

2. REBRANDING / ACQUISITION CHECK  
   - If {company} has undergone acquisition or rebranding  
     (e.g., PerkinElmer Life Sciences → Revvity), explicitly acknowledge the current brand identity.

3. NO ASSUMPTIONS  
   - Do not infer manufacturing status, pricing, or brand tier without logical justification.  
   - When direct evidence is missing, use conservative, market-consistent inference.

 
4. **NO FABRICATION**
- Do NOT invent product names, technologies, certifications, or competitors.
- Every listed product series MUST be real and verifiable as belonging to "{company}" or its parent.

5. **CONTROLLED INFERENCE (ALLOWED & REQUIRED)**
- If exact figures (e.g., pricing, market share) are not publicly disclosed:
    - Use industry-standard inference based on brand tier, portfolio depth, and peer positioning.
    - Clearly label such values as **(Inferred)**.
- Do NOT fabricate precise figures (e.g., "$42,350").

6. **PRODUCT VERIFICATION (STRICT)**
- Verify that each listed product line genuinely belongs to "{company}".
- Do NOT attribute competitor or sibling-brand products.
- Do NOT include adjacent instrument categories.

────────────────────────────────────────
REQUIRED FIELDS
────────────────────────────────────────

1. Manufacturer_Status  
Determine the company’s operational role in product creation. Return ONLY ONE:

- OEM  
  The company designs, engineers, and manufactures products in-house.  
  Indicators: owned manufacturing facilities, proprietary R&D, patents, internally developed product families.

- Private Label  
  The company rebrands or resells products manufactured by another OEM.  
  Indicators: “distributed by”, “manufactured for”, white-label sourcing, lack of proprietary technology.

- Unknown  
  Use ONLY when evidence is insufficient or contradictory.

Rules:  
- Investigate control of manufacturing and R&D.  
- Do NOT default to OEM.  
- Return exactly one label.

2. Brand_Classification

Assign ONE category reflecting the company’s global brand strength, breadth of portfolio, innovation intensity, and strategic influence in the life-science instrumentation market.

    Market Leader (Innovation Leader)
    Multinational, top-tier life-science companies with broad multi-category portfolios, sustained high R&D investment, and category-defining or industry-standard technologies. These brands influence market direction and are commonly present across pharma, clinical, academic, and industrial labs worldwide.

    Established Core Player
    Well-known and widely adopted specialist brands with a strong installed base in one or a few domains (e.g., microbiology, food safety, sample prep). Recognized for reliability and consistent performance, but with narrower portfolio breadth or lower strategic influence than Market Leaders.

    Value-Focused / Emerging Player
    Brands primarily competing on affordability, regional presence, distribution/private-label models, or limited proprietary differentiation. Typically offer functional solutions rather than technology-leading platforms.

Rules:

    Evaluate using global brand status, not regional popularity.

    Market Leader should be rare and selective.

    Do not default all well-known brands to Established Core Player.

    Base classification on portfolio breadth, innovation depth, and industry influence—not only price.

3. Product_Lines  
- List ONLY short, commercially named product SERIES or TIERS do not include number like pro-3, 5, etc.  
- Exclude platforms, software, and generic category terms.  
- Exclude competitor products.  
- Return as comma-separated list.

4. Positioning  
- Identify primary customer segments (e.g., University Labs, Pharma QC, Clinical Diagnostics, Startups).

5. Pricing  
- Provide a realistic portfolio-wide PRICE RANGE.  
- Do NOT return "unknown".  
- If direct pricing is unavailable, infer using comparable brands and tier logic.  
- Do NOT apply flagship pricing across all models.

6. Presence  
- Identify major sales channels (Direct, key distributors).  
- Describe geographic reach.

7. Differentiators  
- List concrete technical or engineering differentiators  
  (e.g., patented drive systems, energy certifications, unique control architectures).

8. Advantages  
- State practical buyer-facing reasons to choose this brand.

────────────────────────────────────────
PERFORMANCE SCORE (1–10)
────────────────────────────────────────

Assign ONE integer score from 1 to 10 based on holistic evaluation of:

- Market Leadership & Reach  
- Technology & Product Excellence  
- Brand Tier & Perceived Value  
- Reputation & Customer Experience  

Rules:  
- Do NOT return "unknown".  
- If evidence is insufficient, return: can't calculate.  
- Otherwise return a single integer only.

────────────────────────────────────────
OUTPUT FORMAT
────────────────────────────────────────

Provide results as a clear, numbered, structured list matching the fields above."""
    


    try:
        # Using a slightly higher temperature (0.1) allows the model to process the 
        # complex instructions while the strict prompt keeps it grounded.
        res = requests.post(
            PERPLEXITY_API_URL, 
            headers={"Authorization": f"Bearer {PERPLEXITY_API_KEY}"}, 
            json={
                "model": PERPLEXITY_MODEL, 
                "messages": [{"role": "user", "content": query}], 
                "temperature": 0.1,
                "seed":42,
                "top_p":0.1

            }
        ).json()
        
        content = res["choices"][0]["message"]["content"]
        return {"company": company, "content": content, "status": "success"}, res.get("citations",[])

    except Exception as e:
        return {"company": company, "status": "error"}, []

# ==================== STEP 3: COMPETITOR ASSESSMENT ====================
def generate_competitor_assessment(results: List[Dict], product: str) -> Dict:
    combined_text = "\n".join([f"--- {r['company']} ---\n{r['content']}" for r in results if r['status']=='success'])
    prompt = f"""
RAW DATA:
{combined_text[:60000]}

Create a high-quality "Competitor Assessment – Manufacturer Landscape" section for "{product}".

Create a "Competitor Assessment" slide for "{product}".
 
    You MUST strictly distinguish between:
    1) Manufacturers (legal/OEM entities)
    2) Brands (marketed trade names)
    3) Product families/series (NOT brands, but must be listed under brands)
 
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    NON-NEGOTIABLE DEFINITIONS
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 
    Manufacturer (OEM):
    - A legal company that designs and/or manufactures instruments.
    - Examples: Thermo Fisher Scientific, Danaher, Agilent Technologies
 
    Brand:
    - A customer-recognized trade name used consistently across marketing,
    catalogs, and product families.
    - A brand MAY be the same as the manufacturer.
    - A brand MAY be owned by a manufacturer.
    - Examples:
    - Thermo Scientific (brand by Thermo Fisher Scientific)
    - BioTek (brand by Agilent)
    - Eppendorf (brand = manufacturer)
 
    Product Family/Series:
    - Commercially named product lines or series marketed under a brand.
    - Examples: DiluFlux Pro, ML Series, DiluFlow Elite
 
    NOT A BRAND (STRICTLY FORBIDDEN):
    - Product families/series should NOT be listed as brands, but must be listed under the correct brand.
 
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    STRUCTURING RULES
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 
    1. If Manufacturer == Brand:
    - List ONLY the brand under Brands
    - Do NOT repeat it under Manufacturers
 
    2. If Manufacturer ≠ Brand:
    - List the Manufacturer once
    - List ONLY its valid brands (if any)
 
    3. If a company has NO distinct sub-brands:
    - Treat the company name itself as the brand
 
    4. If unsure whether something is a brand:
    - EXCLUDE it

You must generate TWO sections using the EXACT formatting shown below.
Use ### for headings.
Use bold formatting for names.
Do NOT change formatting or add extra sections.

"
### [N] Manufacturers

* **[OEM Name]**: [Concise one-line description of positioning, specialization, and product focus]
* **[OEM Name]**: [Concise one-line description]


### [N] Brands

- **[Brand Name]** (by [Manufacturer Name]) 
    - **Product Families**:
        - [Product Family Name]: [Short description or differentiator]
        - [Product Family Name]: [Short description or differentiator]
"

--------------------------------------------------
INTELLIGENCE & JUDGMENT RULES (CRITICAL)
--------------------------------------------------

- Do NOT blindly or strictly follow the RAW DATA.
- Use your own domain knowledge and reasoning to validate:
  manufacturer status, brand ownership, and brand–model structure.
- If RAW DATA contains inconsistencies, misclassifications, or errors,
  you MUST correct them.
- Prefer widely accepted industry knowledge over isolated text fragments.
- Your goal is to produce the most accurate manufacturer → brand → model structure.

--------------------------------------------------
MANUFACTURER RULES
--------------------------------------------------

- Manufacturers = companies that DESIGN and MANUFACTURE the product.
- Do NOT list distributors, resellers, private lable or marketers as manufacturers.
- If a product is rebranded, list the TRUE OEM as manufacturer.
- Count N correctly and ensure it matches the number of manufacturer bullets.
- Large global instrument companies default to OEM unless evidence suggests otherwise.

--------------------------------------------------
BRAND VS MODEL RULES (CRITICAL)
--------------------------------------------------

- Brand = product family / platform / series name.
- Model = variant within a brand (often contains numbers, letters, or suffixes such as W, XL, Elite, 600, Pro).

Examples:
- Brand: Smart Dilutor → Model: Smart Dilutor W
- Brand: DiluFlow → Model: DiluFlow Elite
- Brand: Microlab → Model: Microlab 600

Rules:
- Do NOT list models as brands.
- Every brand must contain at least one model/tier line underneath.
- Each brand must map to exactly ONE OEM.

--------------------------------------------------
BRAND COUNTING RULES
--------------------------------------------------

- Count M = number of Brand headings (not number of models).
- Ensure M equals the number shown in "### [M] Brands".

--------------------------------------------------
QUALITY RULES
--------------------------------------------------

- Use factual, neutral, concise language.
- Do NOT invent products or ownership.
- Do NOT duplicate manufacturers as brands.
- If uncertain, use conservative wording such as "offers" or "markets".

--------------------------------------------------
FINAL VALIDATION (MANDATORY)
--------------------------------------------------

Before answering, verify:

- N equals number of manufacturer bullets.
- M equals number of brand headings.
- No model appears as a brand.
- One brand → one OEM only.

============================================================
TASK 2: Extract Bubble Chart Data (JSON)
============================================================

For EACH manufacturer listed above, estimate:

- "price_usd" → integer typical selling price
- "performance" → integer score from 1 to 10
- "market_share" → integer score from 1 to 10

------------------------------------------------------------
PRICE BAND GUARDRAILS
------------------------------------------------------------

- Market Leader manufacturer: 20000–50000 USD typical range
- Established Core manufacturer: 12000–40000 USD typical range
- Value-Focused / Emerging manufacturer: 7000–25000 USD typical range

Use midpoints unless strong evidence suggests otherwise.

------------------------------------------------------------
SCORING GUIDANCE
------------------------------------------------------------

- Performance:
  9–10 = Category leaders
  7–8  = Strong specialists
  5–6  = Functional/basic offerings

- Market Share:
  8–10 = Dominant or top-3 globally
  5–7  = Recognized niche specialists
  2–4  = Smaller or regional players

- Do NOT use "unknown".
- Use reasonable market inference if exact data is unavailable.

============================================================
OUTPUT FORMAT (STRICT)
============================================================

Return ONLY valid JSON in this structure:

{{
  "assessment_text": "...",
  "chart_data": [
    {{ "MANUFACTURER": "...", "price_usd": 0, "performance": 0, "market_share": 0 }}
  ],
  "bottom_box_text": "..."
}}

============================================================
AUTO-VALIDATION & DEDUPLICATION (MANDATORY)
============================================================

- Every manufacturer in chart_data MUST appear in Manufacturer Landscape.
- Number of manufacturer in chart_data MUST equal M.
- Remove duplicates automatically.
- One Brand → one OEM only.
- No extra text outside JSON.


Return ONLY the formatted Manufacturer and Brand sections.
"""



    client = get_gemini_client()
    if not client: return None
    res = client.chat.completions.create(model="gemini-2.0-flash", messages=[{"role": "user", "content": prompt}, {"role": "system", "content": "Output valid JSON."}], temperature=0.2)
    return json.loads(res.choices[0].message.content.replace("```json", "").replace("```", "").strip())



# ============================== NEW COMPETITOR Analysis ==========================================
# def product_anchor(product_category, benchmark_product, benchmark_manufacturer):
#     query = f"""
# You are a senior procurement analyst and market intelligence specialist.

# For the benchmark product "{benchmark_product}" by "{benchmark_manufacturer}" in the "{product_category}" category, create a comprehensive "Product Anchor" analysis for use in vendor negotiations and competitive benchmarking.

# IMPORTANT: Keep each bullet to 1–2 lines max. Use bullet points (•) only. No citations like [1][2][3]. No verbose explanations.

# ---

# **1. What It Is (Capability + Positioning)**
# • ONE sentence: describe as a [modular/fixed/upgradeable] [product type] supporting [X measurement technologies]
# • List the specific measurement technologies (single bullet, one line)
# • List 2–3 key usability/software features (one line each)
# • State market positioning: [entry-level / mid-range / flagship / niche premium]

# ---

# **2. Key Configurations & Options**
# • List the main configuration tiers (e.g., base, standard, advanced) with what differentiates each
# • List the most common add-on modules/options and their approximate price impact (e.g., "+$X–$Yk for top+bottom option")
# • Note any mandatory vs. optional accessories that affect total system cost

# ---

# **3. Public Price Point (One Concrete Reference)**
# • Find ANY publicly displayed price on manufacturer sites, distributor listings, official product pages, or market reports
# • Report EXACTLY as: "A publicly displayed online price ([region] site) for a base configuration ([brief config description]; Product code [CODE] / Supplier No. [NUMBER]) is shown as: €/$/£[AMOUNT] (valid until [DATE], per listing)"
# • If no exact date, state "per listing" only
# • If multiple regional prices found, list up to 2 (e.g., US vs EU) to show regional variance

# ---

# **4. Total Cost of Ownership (TCO) Elements**
# • Consumables: list key consumables and approximate annual cost or replacement frequency (e.g., injectors, seals, gas cylinders, tips)
# • Service contract: typical annual service/maintenance contract cost as % of purchase price or absolute range (e.g., "~8–12% of list price/year")
# • Installation & training: note if typically bundled or charged separately and approximate cost
# • Estimated 5-year TCO range: "Estimated 5-yr TCO for a base system: ~$[X]k–$[Y]k including consumables and service"

# ---

# **5. Competitor Alternatives (Negotiation Leverage)**
# • List 2–3 direct competitors with their flagship competing model and approximate price positioning relative to {benchmark_product} (e.g., "Competitor A – Model X: ~10–15% cheaper, fewer modules")
# • Note which competitor is most commonly used as a swap-out alternative in deals
# • ONE line on what {benchmark_manufacturer} typically concedes when a competitor quote is presented

# ---

# **6. Used & Refurbished Market Signal**
# • Used {benchmark_product} units are commonly listed in the ~US$[X]k–$[Y]k band on secondary marketplaces (condition/config varies heavily)
# • Note key refurbishers or certified pre-owned programs if available (e.g., manufacturer CPO program)
# • State the typical age/vintage of units appearing on the used market (e.g., "mostly 3–7 year old units")

# ---

# **7. Negotiation Levers & Typical Deal Structure**
# • Standard list-to-net discount range observed in the market (e.g., "Typical achievable discount: 15–25% off list for academic; 10–18% for commercial")
# • Key levers: list 3–4 specific tactics that move price (e.g., end-of-quarter timing, multi-unit orders, trade-in, service bundle, demo unit)
# • Typical lead time and whether faster delivery commands a premium or creates negotiation room
# • Note if financing/leasing options are commonly offered and at what rate/term

# ---

# **8. Warranty & Support Terms**
# • Standard warranty period and what it covers
# • Extended warranty options and cost
# • Note support model: local field service vs. depot repair vs. remote support, and typical response SLA

# ---

# **9. Red Flags & Watch-Outs**
# • List 2–3 known issues: hidden costs, platform lock-in risks, software licensing fees, forced upgrade cycles, or discontinued support for older configs
# • Note any supply chain or lead time risks specific to this product

# ---

# FORMAT REQUIREMENTS:
# - Bullet points (•) only — no numbered sub-lists within bullets
# - Maximum 1–2 lines per bullet
# - NO verbose explanations or reference brackets
# - Extract pricing data with product codes wherever possible
# - Focus on concrete numbers, ranges, and actionable intelligence

# Research using: manufacturer websites, authorized distributor listings, secondary marketplaces (eBay, BioSurplus, LabX, etc.), industry procurement databases, and published market reports.
# """
    

#     try:
#         # Using a slightly higher temperature (0.1) allows the model to process the 
#         # complex instructions while the strict prompt keeps it grounded.
#         res = requests.post(
#             PERPLEXITY_API_URL, 
#             headers={"Authorization": f"Bearer {PERPLEXITY_API_KEY}"}, 
#             json={
#                 "model": PERPLEXITY_MODEL, 
#                 "messages": [{"role": "user", "content": query}], 
#                 "temperature": 0.2,
#                 "seed":42,
#                 "top_p":0.1

#             }
#         ).json()
        
#         content = res["choices"][0]["message"]["content"]
#     except Exception as e:
#         content = e
    

#     formatting_prompt = f"""
#         Clean and format the following product anchor analysis text.

#         RULES:
#         1. Remove all citation numbers in brackets like [1], [2], [3], etc.
#         2. Fix any spacing issues or concatenated text
#         3. Ensure proper bullet points (•) are used
#         4. Keep all section headers as-is
#         5. Preserve all actual content - only remove noise

#         INPUT TEXT:
#         {content}

#         OUTPUT:
#         Return the cleaned, properly formatted text with the same structure but no citation numbers or formatting errors.
#         """

#     try:
#         response = client.chat.completions.create(
#             model="gpt-4o",
#             messages=[{"role": "user", "content": formatting_prompt}],
#             temperature=0.2
#         )
#         content = response.choices[0].message.content.strip()
#     except Exception as e:
#         content = f"Error: {e}"
 
#     return {
#         "content": content
#     }

    
def product_anchor(product_category, benchmark_product, benchmark_manufacturer):
    
    query = f"""
You are a market research analyst.

For the benchmark product "{benchmark_product}" by "{benchmark_manufacturer}" in the "{product_category}" category, create a concise "Product Anchor" analysis.

IMPORTANT: Keep the output brief and structured exactly as specified below.

**1. What it is (capability + positioning)**
ONE sentence describing it as a [modular/fixed/upgradeable] [product type] supporting [X measurement technologies]
List the specific measurement technologies in a single bullet and in new line
List 2-3 key usability/software features in 1 or 2 line 
Keep each bullet to ONE line maximum

**2. Public price point (one concrete reference)**
Find ANY publicly displayed price on manufacturer sites, distributor listings, official product pages, any Reports, or  market reports 
Report it EXACTLY as: "A publicly displayed online price ([region] site) for a base configuration ([brief config description]; Product code [CODE] / Supplier No. [NUMBER]) is shown as: €/$/£[AMOUNT] (valid until [DATE], per listing)"
If no exact date, state "per listing" only
Include product/supplier codes if available

**3. Important & Used market signal (helps frame negotiation)**
ONE bullet on how pricing varies with common options (be specific: Top vs Top+Bottom, modules, injectors, gas control, etc.) and note this gives a "floor" for new systems
ONE bullet on used market: "Used {benchmark_product} units are commonly listed in the ~US$[X]k–$[Y]k band on secondary marketplaces (condition/config varies heavily)."

FORMAT REQUIREMENTS:
Bullet points (•) only — no numbered sub-lists within bullets 
Maximum 1–2 lines per bullet
NO verbose explanations or reference brackets
Extract pricing data with product codes wherever possible
Focus on concrete numbers, ranges, and actionable intelligence
"""

    try:
        res = requests.post(
            PERPLEXITY_API_URL, 
            headers={"Authorization": f"Bearer {PERPLEXITY_API_KEY}"}, 
            json={
                "model": PERPLEXITY_MODEL, 
                "messages": [{"role": "user", "content": query}], 
                "temperature": 0.2,
                "seed": 42,
                "top_p": 0.1
            }
        ).json()
        
        content = res["choices"][0]["message"]["content"]
        citations = res.get("citations", [])

    except Exception as e:
        content = str(e)
        citations = []

    formatting_prompt = f"""
Clean and format the following product anchor analysis text.

RULES:
1. Remove all citation numbers in brackets like [1], [2], [3], etc.
2. Fix any spacing issues or concatenated text
3. Ensure proper bullet points (•) are used
One bullet point per line
4. Keep all section headers as-is
5. Preserve all actual content - only remove noise

INPUT TEXT:
{content}

OUTPUT:
Return the cleaned, properly formatted text with the same structure but no citation numbers or formatting errors.
"""

    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": formatting_prompt}],
            temperature=0.2
        )
        content = response.choices[0].message.content.strip()
    except Exception as e:
        content = f"Error: {e}"

    return {
        "content": content,
        "citations": citations
    }


def like_for_like(product_category, benchmark_product, benchmark_manufacturer, text=""):

    query = f"""
You are a competitive intelligence analyst in the laboratory instrumentation market.

Research the global “like-for-like” competitive set for:

Benchmark Product: {benchmark_product}
Manufacturer: {benchmark_manufacturer}
Category: {product_category}

Task:

Identify the top 7–10 global competitors.

Strict Instructions:
DO NOT SAY I cannot provide the competitive intelligence analysis you've requested because the search results do not contain information about the Varioskan LUX or sufficient detail about the specific competitive positioning of multimode microplate readers that would directly compete with it.
1. Do NOT describe the benchmark product.
2. Do NOT provide explanations.
3. Do NOT summarize findings.
4. Do NOT include commentary.
5. Do NOT include incomplete competitors.
6. Identify ALL major global manufacturers competing in this segment.
7. For each manufacturer, list ONLY the specific product series or key models that directly compete with the benchmark product in terms of core capabilities (Abs + FI).

Output Format (TEXT ONLY):

* Manufacturer 1 → Product Series / Key Models

* Manufacturer 2 → Product Series / Key Models
Example format:
Molecular Devices → SpectraMax iSeries (iD3, iD5, i3x)

ONLY RETURN THE OUTPUT IN THE ARROW MARK FORMAT DO NOT CHANGE THIS
Only return competitor mappings in the exact format above.

if any competitor does not have a clear product series or key models that match the benchmark's core capabilities, try to find the closest offering but do NOT include it if it's not a clear match.
One competitor per line.
No additional text before or after.
find the most accurate and direct competitors based on publicly available information from manufacturer websites, distributor listings, and reputable lab equipment resellers, privetely held market research, and industry reports.
"""

    try:
        res = requests.post(
            PERPLEXITY_API_URL,
            headers={"Authorization": f"Bearer {PERPLEXITY_API_KEY}"},
            json={
                "model": PERPLEXITY_MODEL,
                "messages": [{"role": "user", "content": query}],
                "temperature": 0.3,
            }
        ).json()

        content = res["choices"][0]["message"]["content"]
        citations = res.get("citations", [])

    except Exception as e:
        content = str(e)
        citations = []

    return {
        "content": content,
        "citations": citations
    }


def compititive_table(product_category, benchmark_product, benchmark_manufacturer, competitors=None, like_for_like_info=None):
    """
    Generate competitive benchmark table.
    
    Args:
        product_category: The product category
        benchmark_product: The benchmark product name
        benchmark_manufacturer: The benchmark manufacturer
        competitors: List of competitor company names from Discover step (optional)
        like_for_like_info: Dict with 'content' from Like-for-Like step (optional)
    """
    
    # # Build competitor context from provided data
    # like_for_like_content = ""
    # if like_for_like_info and like_for_like_info.get('content'):
    #     like_for_like_content = like_for_like_info['content']

    prompt = f"""
You are a market research analyst creating a competitive benchmark table.

BENCHMARK PRODUCT:
- Product: {benchmark_product}
- Manufacturer: {benchmark_manufacturer}  
- Category: {product_category}


═══════════════════════════════════════════════════════════════════════════════
STRICT RULES - FOLLOW EXACTLY:
═══════════════════════════════════════════════════════════════════════════════

1. **FIRST ROW** = {benchmark_manufacturer} with {benchmark_product}

2. **REMAINING ROWS** = One row for each manufacturer from the like-for-like data above
   - Extract each unique manufacturer from the like-for-like list
   - Each manufacturer appears EXACTLY ONCE
   - NO manufacturer repetition allowed

3. **REPRESENTATIVE MODEL** = Pick ONLY ONE product per manufacturer
   - If like-for-like shows "Manufacturer → Product1, Product2, Product3"
   - You pick ONE (usually the first or most comparable to {benchmark_product})
   - Write only that ONE product name in the cell



4. **NUMBER OF ROWS** = 1 (benchmark) + number of unique manufacturers from like-for-like
   - Do NOT add extra manufacturers not in the like-for-like list
   - Do NOT skip any manufacturer from the like-for-like list


UNDERSTANDING "SEGMENT":
A "Segment" is a SHORT PHRASE (3-5 words) describing how THIS SPECIFIC product is uniquely positioned in the market. 
It answers: "What niche does this product fill?"

Good segment examples (each unique):
- "Upgradeable research multimode"
- "HTS / screening-grade multimode"
- "High-performance multimode"
- "Flexible multimode"


QUALITY GRADE:
- A+ = Premium, market-leading technology
- A = Professional research-grade
- A-B+ = Strong mid-tier
- B+ = Capable mid-tier, good value
- B = Entry-level or value-focused

COST GRADE (relative to this category):
- $$$$$ = Premium tier
- $$$$ = Upper tier
- $$$ = Mid tier
- $$-$$$ = Lower-mid
- $$ = Value/entry tier
- $ = Budget tier

PUBLIC COST SIGNAL:
Search for actual pricing evidence:
- Exact prices with currency and config details
- Distributor/reseller prices
- Used market prices (LabX, etc.)
- If none found: "Quote-only; [brief positioning context]"

OUTPUT FORMAT:
Return as a markdown table:

| Segment | Manufacturer | Representative model(s) | Quality grade | Cost grade | Public cost signal (examples) |
|---------|--------------|-------------------------|---------------|------------|-------------------------------|
| [segment] | [company] | [model] | [A+/A/B+/B] | [$-tier] | [specific pricing evidence with source context] |

═══════════════════════════════════════════════════════════════════════════════
VALIDATION CHECKLIST:
═══════════════════════════════════════════════════════════════════════════════

Before outputting, verify:
□ Row 1 is {benchmark_manufacturer} with {benchmark_product}
□ Every manufacturer from like-for-like appears exactly ONCE
□ No manufacturer is repeated
□ Each "Representative model(s)" cell has only ONE product
□ All segments are UNIQUE (no duplicates)

Generate the table:
"""
    try:
        res = requests.post(
            PERPLEXITY_API_URL, 
            headers={"Authorization": f"Bearer {PERPLEXITY_API_KEY}"}, 
            json={
                "model": PERPLEXITY_MODEL, 
                "messages": [{"role": "user", "content": prompt}], 
                "temperature": 0.2,
            }
        ).json()
        
        content = res["choices"][0]["message"]["content"]
        citations = res.get("citations", [])

    except Exception as e:
        content = str(e)
        citations = []
    formatting_prompt = f"""
Clean the following competitive benchmark table.

RULES:
1. Remove all citation numbers like [1], [2], [3]
2. Keep ONLY the markdown table
3. Remove ALL text before the table
4. Remove ALL text after the table
5. Ensure proper | separators
6. Remove all markdown bold markers ** (double asterisks)
7. Remove all markdown italic markers * (single asterisks around words)

INPUT:
{content}

OUTPUT:
Return ONLY the markdown table, nothing else.
"""
    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": formatting_prompt}],
            temperature=0.2
        )
        content = response.choices[0].message.content.strip()
    except Exception as e:
        content = f"Error: {e}"
 
    return {
        "content": content,
        "citations": citations
    }



def generate_swot_analysis(
    product_category: str,
    benchmark_product: str,
    benchmark_manufacturer: str,
    competitors: List[str],
    region: str = "Global"
) -> Dict:
 
    # 1. Use Perplexity to get web-based intelligence
    px_query = f"""
Act as a market research assistant.
 
Collect only publicly stated, factual competitive information related to the following:
 
Product Category: {product_category}
Benchmark Product: {benchmark_product}
Competitors: {", ".join(competitors)}
Region: {region}
 
Focus strictly on:
- Marketed feature claims
- Publicly described technology positioning
- Widely referenced competitive comparisons
- Analyst-style positioning statements
 
Do NOT include:
- SWOT interpretations
- Opinions or recommendations
- Speculative trends (AI, IoT, automation, future roadmap)
- Generic market growth commentary
 
Return a concise list of externally stated competitive claims and positioning signals.
"""
 
    px_content = ""
    try:
        px_payload = {
            "model": PERPLEXITY_MODEL,
            "messages": [{"role": "user", "content": px_query}],
            "temperature": 0.1,
            "top_p": 0.1,
            "seed": 42
        }
        px_res = requests.post(
            PERPLEXITY_API_URL,
            headers={"Authorization": f"Bearer {PERPLEXITY_API_KEY}"},
            json=px_payload
        ).json()
        px_content = px_res["choices"][0]["message"]["content"]
    except Exception as e:
        px_content = ""
 
    # 2. Build the GPT-4o prompt, including Perplexity research as context
    gpt_prompt = f"""
You are a Product Strategy and Competitive Intelligence expert in life-science instrumentation.
 
Below are external market signals extracted from public sources.
These signals may be incomplete, generic, or biased.
Use them ONLY as evidence to validate or contextualize points that are consistent
with known product positioning. Do NOT introduce new SWOT points
solely based on these signals.
 
--- External Market Signals ---
{px_content}
--- End of Market Signals ---
 
Product Category: {product_category}
Benchmark Product: {benchmark_product}
Benchmark Manufacturer: {benchmark_manufacturer}
Competitors: {", ".join(competitors)}
Region: {region}
 
IMPORTANT USE OF MARKET SIGNALS:
- External market signals are evidence inputs only.
- Do NOT summarize, paraphrase, or reuse their wording.
- Do NOT translate signals directly into SWOT bullets.
- Use them only to validate or contrast your own strategic judgments.
 
Generate a SWOT Analysis grounded in strategic reasoning and
publicly observable product positioning.
 
CRITICAL PRODUCT ACCURACY RULES (MANDATORY):
- Treat the benchmark product as a real, named commercial platform.
- Do NOT assume missing features unless clearly established.
- Describe uncertainty as positioning boundaries, not speculation.
- Do NOT generalize from older models or adjacent platforms.
- Do NOT downgrade the benchmark based on stereotypes.
- Strengths must reflect differentiation versus direct competitors.
- Do NOT attribute imaging or single-cell capabilities unless explicitly positioned.
 
COMPETITOR COMPARISON RULES:
- Named competitors may be referenced.
- Technology-level comparisons are allowed where widely recognized.
- Use directional comparisons (e.g., throughput tier, sensitivity tier).
 
INTERNAL COMPETITIVE MODE:
- It is acceptable to state that specific competitors are better suited
  for certain use cases when this is commonly accepted in the market.
- Strengths may NOT mention software or features unless framed as a
  consolidated workflow or architectural capability.
- ALL Weaknesses and Threats must be framed relative to either:
  (a) a named competitor,
  (b) a competing technology class,
  (c) a recognized platform tier (e.g., HTS readers, imaging readers).
- Opportunities must reflect external customer demand or market behavior
  WITHOUT conditional statements about future product capabilities.
 
STRUCTURE (MANDATORY):
 
Strengths:
- Strategic advantages based on architecture, workflow consolidation,
  ecosystem integration, or intended positioning.
 
Weaknesses:
- Positioning boundaries or trade-offs relative to higher-end or
  specialized platforms.
 
Opportunities:
- Must describe external customer demand, procurement behavior,
  or market shifts.
- Must reference a specific customer segment, geography,
  or workflow shift (e.g., mid-throughput labs, APAC expansion).
- Must NOT include action verbs such as "offer", "promote",
  "leverage", "address", or "capitalize".
- Do NOT use general market growth statements.
 
Threats:
- Competitive technologies, alternative platforms, or pricing pressure,
  explicitly anchored to competitors or technology classes.
 
GLOBAL ENFORCEMENT RULE:
- EVERY bullet point MUST reference at least one of the following:
  (a) a concrete technology element,
  (b) a workflow capability,
  (c) a comparative positioning against a competitor or platform class.
- If a point cannot be anchored this way, it must NOT be included.
 
PRIORITIZATION RULES:
- 5–6 Strengths, 4–5 Weaknesses, 4–5 Opportunities, 4–5 Threats.
- Abstract features into higher-level strategic capabilities.
- Avoid feature laundry lists.
- Avoid speculative roadmap ideas.
- Use decisive, leadership-ready language.
- Strengths must describe consolidated workflow or architectural advantages.
- Strengths must NOT enumerate specifications (e.g., plate formats,
  wavelength ranges, or mode lists); specifications must be abstracted
  into higher-level positioning or workflow advantages.
- Do NOT use generic adjectives such as "good", "strong", "flexible",
  "robust", or "user-friendly" unless immediately justified by a
  specific technology, workflow, or competitive comparison.
 
ANTI-SPECULATION RULE (MANDATORY):
- Do NOT use probabilistic or assumptive language such as
  "likely", "may", "might", "assuming", "appears to",
  "may have limitations", "may limit", or "could impact".
- Express limitations as clear positioning boundaries
  (e.g., "is not optimized for", "is positioned below").
- If a point cannot be stated decisively based on commonly
  accepted market knowledge, it must be excluded.
 
OUTPUT:
Return only the SWOT sections as bullet points.
"""
    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": gpt_prompt}],
            temperature=0.1
        )
        content = response.choices[0].message.content.strip()
    except Exception as e:
        content = f"Error: {e}"
 
    return {
    "type": "SWOT",
    "content": content,
    "citations": px_res.get("citations", []) if 'px_res' in locals() else []
    }

 


def generate_ip_technology_positioning(
    product_category,
    benchmark_product,
    benchmark_manufacturer,
    competitors
) -> Dict:
 
    # 1. Use Perplexity to get web-based IP/technology intelligence
    px_query = f"""
Act as a patent- and technology-intelligence extraction assistant.
 
Your task is to IDENTIFY and EXTRACT exact patent-theme language and
proprietary technology phrasing that appears in public literature
for the following:
 
Product Category: {product_category}
Benchmark Product: {benchmark_product}
Benchmark Manufacturer: {benchmark_manufacturer}
Competitors:{competitors}

 
Focus STRICTLY on:
- Exact or near-exact phrases used in:
  • patent titles
  • patent abstracts
  • patent claim summaries
  • manufacturer technical white papers ONLY when they explicitly
    reference a patented or proprietary design
  • analyst reports ONLY when they explicitly tie a design
    to patent protection or long-standing proprietary IP
 
 
Examples of acceptable outputs:
- "microplate reader with controlled gas atmosphere"
- "integrated incubation chamber for microplate-based assays"
- "linear variable filter monochromator architecture"
- "detector-centric high-throughput screening design"
 
Do NOT:
- Return descriptions of how a product is built or how it works
  unless the source explicitly states that this design is patented,
  proprietary, or uniquely owned by the manufacturer
- Treat the presence of any component, capability, or feature
  as evidence of a patent theme unless explicit IP ownership is stated
- Return any phrase that could plausibly apply
  to multiple manufacturers without explicit IP attribution
 
 
CRITICAL INSTRUCTION:
If a patent-theme phrase is found, return the phrase verbatim
(or as close as possible) and associate it with the correct manufacturer.
 
If NO explicit patent-theme phrasing is found for a manufacturer,
explicitly state:
"No clearly cited patent-theme language identified."
 
OUTPUT FORMAT (STRICT):
For each manufacturer:
- Manufacturer:
- Extracted patent-theme phrases (verbatim or near-verbatim):
  • [phrase 1]
  • [phrase 2]
- Source type:
  • patent abstract / patent title / white paper / analyst report
 
"""
 
    px_content = ""
    try:
        px_payload = {
            "model": PERPLEXITY_MODEL,
            "messages": [{"role": "user", "content": px_query}],
            "temperature": 0.1,
            "top_p": 0.1,
            "seed": 42
        }
        px_res = requests.post(
            PERPLEXITY_API_URL,
            headers={"Authorization": f"Bearer {PERPLEXITY_API_KEY}"},
            json=px_payload
        ).json()
        px_content = px_res["choices"][0]["message"]["content"]
    except Exception as e:
        px_content = ""
 
    # 2. Build the GPT-4o prompt, including Perplexity research as context
    prompt = f"""
You are a senior Technology Strategy and IP Positioning analyst specializing in
life-science instrumentation platforms.
 
Product Category: {product_category}
Benchmark Product: {benchmark_product}
Benchmark Manufacturer: {benchmark_manufacturer}
 
Competitors :{competitors}
 
REFERENCE-STYLE POSITIONING MODE (CRITICAL):
 
Your output must resemble how IP and technology positioning is written
in internal strategy decks, analyst notes, and competitive reviews.
 
This means:
- Use widely accepted industry narratives, even if high-level
- Prefer architectural, workflow, or patent-theme framing
- Do NOT invent new technology names
- Do NOT force every competitor to have an IP moat
- It is acceptable—and often correct—for competitors to be
  execution-led or application-fit driven
 
This is NOT a legal IP audit.
This is NOT a feature checklist.
This is a strategic, architecture-level positioning summary.
 
ANCHOR INTERPRETATION RULE (CRITICAL):
 
When multiple architectural interpretations are possible, prefer
long-standing, widely accepted industry associations over reinterpretation
or creative reassignment of technology themes.
 
ANCHOR REASSIGNMENT PROHIBITION (CRITICAL):
 
If a technology theme is widely associated with a particular class of
platforms in this category, do NOT reassign that theme to another vendor
unless explicitly stated in widely cited industry literature.
 
────────────────────────────────
ANALYTICAL SCOPE
────────────────────────────────
Focus on:
- Widely cited proprietary technologies or systems
- Commonly referenced patent THEMES (no patent numbers)
- Optical, detection, incubation, or environmental control architectures
- Structural design philosophies that shape application fit or workflow focus
 
It is acceptable to reference:
- Long-standing, industry-accepted proprietary architectures
- Named systems repeatedly used in vendor positioning
- Patent themes discussed in public analyst or industry literature
 
Avoid:
- Feature-by-feature comparisons
- Software UX, pricing, or services
- Legal enforceability or patent strength analysis
 
────────────────────────────────
IP / POSITIONING GUIDANCE (MERGED WITH SWOT LOGIC)
────────────────────────────────
For EACH manufacturer, identify the PRIMARY TECHNOLOGY OR POSITIONING THEME
they are most commonly associated with in the market.
 
This may be:
- A structural IP or architectural theme, OR
- An execution-led or application-fit positioning
  if no widely accepted IP moat exists.
 
POSITIONING BOUNDARY RULE:
- Express differentiation as positioning boundaries or trade-offs
  (e.g., flexibility vs sensitivity, application fit vs generality,
  throughput vs adaptability)
- Avoid absolute ownership claims unless they are widely accepted
- If a technology mainly defines WHERE the product is strong,
  describe it as application fit rather than a hard IP moat
 
RELATIVE POSITIONING RULE:
- Every positioning statement must be interpretable relative to
  at least one competitor or platform class
  (e.g., HTS readers, imaging readers, multimode research platforms)
- If a statement cannot be expressed comparatively,
  it is likely execution-level
 
ARCHITECTURE-FIRST ENFORCEMENT:
- If a description references software names, feature labels,
  or assay chemistries without mapping to an architectural or
  workflow capability, it MUST be abstracted upward or excluded
 
NO-INVENTION RULE:
- If a technology or architectural theme is not commonly mentioned
  in industry or analyst discussions for a manufacturer,
  DO NOT introduce it
- Silence or execution-led positioning is preferable to invention
- Do NOT convert generic descriptions of product capability or design
into named technologies or implied proprietary systems.
If a name or term is not explicitly present in the source signals,
it MUST NOT be introduced.
- If a technology name does not appear verbatim in the extracted source
material, it MUST NOT be introduced or inferred.
 
 
────────────────────────────────
STRUCTURE (MANDATORY)
────────────────────────────────
 
IP MOAT SUMMARY BY PLAYER:
 
For each manufacturer, use this structure:
 
• [Manufacturer / Product]
  – IP moat or positioning theme:
    [High-level statement referencing patent themes, architecture,
     or application-defining design philosophy]
  – Technology type:
    [e.g., controlled gas incubation, LVF monochromator,
     hybrid optical system, throughput-optimized detection]
  – Strategic implication:
    [Sensitivity vs flexibility vs application fit vs throughput]
  – Risk / limitation:
    [Where the positioning is narrow, application-specific,
     or less competitive versus alternatives]
 
────────────────────────────────
COMPARATIVE INSIGHT (REFERENCE-STYLE)
────────────────────────────────
- Summarize how different architectural or positioning approaches
  create trade-offs across the competitive landscape
  (e.g., incubation-driven application fit vs optical flexibility).
- Highlight where certain architectures or design philosophies
  are commonly regarded as difficult for competitors to match
  due to accumulated know-how, patents, or system complexity.
- Do NOT force comparative claims for execution-led positions.
 
────────────────────────────────
STYLE RULES
────────────────────────────────
- Bullet points only
- Strategic, neutral tone
- No marketing adjectives
- No excessive disclaimers
- No speculative language
 
PRIMARY POSITIONING UNIQUENESS RULE (CRITICAL):
 
Each platform must be positioned around a SINGLE primary technology
or architectural theme.
 
A theme that describes broad, general, or widely reusable capability
MUST NOT be selected as the primary theme if it does not materially
constrain how, where, or for what type of work the platform is used.
 
If multiple themes appear applicable to the same platform, you MUST:
- Select the theme that is most commonly and consistently associated
  with the platform in industry or analyst discourse
- Downgrade all other themes to execution-led or application-fit context
- Do NOT present multiple primary themes for a single platform
 
If no available theme clearly constrains how, where, or for what type
of work the platform is used, you MUST default the platform to
execution-led or application-fit positioning and avoid elevating
any broad capability as a primary theme.
 
 
POST-GENERATION VALIDATION (CRITICAL):
 
AFTER generating the full output, you MUST perform a consistency check.
If ANY platform is assigned mutually exclusive primary technology axes
(e.g., optical flexibility vs environmental control),
you MUST rewrite ONLY the conflicting rows and remove one axis,
defaulting those rows to execution-led or application-fit positioning.
 
If the selected primary theme for a platform describes broad or general
capability that could apply equally to many platforms, and another theme
more clearly defines how, where, or for what type of work the platform is
used, you MUST downgrade the broad theme to execution-led positioning.
 
 
OUTPUT:
Return only the structured output above.
No preamble.
No closing remarks.
"""
 
    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.1
        )
        content = response.choices[0].message.content.strip()
    except Exception as e:
        content = f"Error: {e}"
 
    return {
    "type": "IP_Technology_Positioning",
    "content": content,
    "citations": px_res.get("citations", []) if 'px_res' in locals() else []
}   



def clean_citations(text):
    """Removes citation markers like [1], [1][2]."""
    return re.sub(r'\[\d+(?:,\s*\d+)*\]|\[\d+\]', '', text)

def fix_nested_list_formatting(text):
    """
    Forces newlines before numbered lists to ensure Markdown renders them correctly.
    """
    # 1. Ensure main numbered items (1., 2.) have double newlines
    text = re.sub(r'(\d\.\s\*\*.*?\*\*)', r'\n\n\1', text)
    
    # 2. Ensure sub-items (1. Examples:, 2. Buyer logic:) start on new lines
    # Using \1 to reference the first capturing group correctly
    text = re.sub(r'(?<!\n)\s+(1\.\sExamples:)', r'\n   - \1', text)
    text = re.sub(r'(?<!\n)\s+(2\.\sBuyer logic:)', r'\n   - \1', text) # FIXED: Uses \1 now
    
    text = text.replace('\n\n\n', '\n\n')
    return text


def generate_deep_dive_strategy(product_name: str, company: str):
    if not PERPLEXITY_API_KEY:
        return {"error": "Missing API Key."}

    # --- THE TECHNICAL PROMPT ---
    prompt_template = f"""
    Act as a Senior Product Strategy Manager.
    Perform a strategic competitive positioning analysis for "{product_name}" by {company}.

    TASK:
    Generate a report following the EXACT structure below.

    STYLE ALIGNMENT:
    - Match the tone of executive strategic slides.
    - Focus on tier positioning, architectural trade-offs, and buyer logic.
    - Avoid deep specification comparisons or aggressive technical combat framing.
    - Keep language decisive, structured, and presentation-ready.

    POSITIONING BASELINE (DO NOT REDEFINE):
    - {product_name} is a research-grade multimode platform.
    - It sits in the Balanced / Upgradeable tier.
    - It is positioned below dedicated HTS screening systems.
    - It is not an imaging reader.
    - It prioritizes assay flexibility over maximum throughput.
    Do NOT reclassify the benchmark outside this positioning.

    DEPTH CONTROL:
    - Each bullet may contain up to 2 short sentences.
    - Provide 2–4 concise lines per subsection.
    - Do NOT exceed 4 lines per bullet.
    - Avoid long paragraphs.
    - Avoid feature laundry lists.

    ACCURACY RULES:
    - Do NOT invent specifications, performance claims, or proprietary technologies.
    - Reference architectural systems, optical designs, workflow structures, or certifications only when materially relevant.
    - If uncertain about detailed specs, abstract upward to positioning-level statements.
    - Frame weaknesses as positioning trade-offs, not product defects.

    ────────────────────────────────────────
    OUTPUT FORMAT (Markdown Only)
    ────────────────────────────────────────

    A) Strategic group map (Quality ceiling vs Cost)

    Cluster placement must be based on:
    - Throughput positioning
    - Optical architecture class
    - Automation integration depth
    - Target customer segment

    1. Value Tier (Cost ↓, Capability “good enough”)
    1. Examples: [Competitor names]
    2. Buyer logic:
        Provide 2–3 lines explaining procurement mindset, workflow needs, and cost sensitivity.

    2. Balanced / Upgradeable Tier (Sweet Spot) ← {product_name}
    1. Examples: {product_name}, [Competitor names]
    2. Buyer logic:
        Provide 2–3 lines explaining flexibility, evolving assay needs, and mid-tier positioning.

    3. Premium / High-Throughput (Performance ↑, Cost ↑)
    1. Examples: [Competitor names]
    2. Buyer logic:
        Provide 2–3 lines explaining automation integration, scale, and reproducibility focus.

    4. Niche / Single-mode
    1. Examples: [Competitor names if applicable]
    2. Buyer logic:
        Provide 2–3 lines explaining specialized or regulated workflows.

    ────────────────────────────────────────

    B) Where {product_name} is competitively strong

    1. [Architectural Advantage Title]
    Provide 2–4 lines explaining:
    - The architectural or modular basis of the advantage
    - Why it matters for workflow flexibility or cost control
    - How it positions against adjacent tiers

    2. [Optical / Ecosystem / Integration Advantage]
    Provide 2–4 lines explaining:
    - Strategic importance (e.g., hybrid optics, upgrade path, certification)
    - Buyer-facing impact

    3. [Upgradeability / Deployment / Software Advantage]
    Provide 2–4 lines explaining:
    - Deployment economics or lab scalability impact
    - Why this influences purchasing decisions

    ────────────────────────────────────────

    C) Where competitors can outflank {product_name}

    1. [Throughput / Automation Tier Difference]
    Name the competitor and provide 2–4 lines explaining:
    - The architectural or positioning advantage
    - The use case where it materially matters
    - Why this shifts purchasing logic

    2. [Optical Architecture / Sensitivity Positioning Difference]
    Name the competitor and provide 2–4 lines explaining:
    - The optical or system-level distinction
    - The application boundary impact

    3. [Application Boundary Shift]
    Name the competitor and provide 2–4 lines explaining:
    - The workflow change (e.g., imaging vs multimode, HTS vs research)
    - How this redefines the buying decision

    ────────────────────────────────────────

    INSTRUCTIONS:
    - Return RAW MARKDOWN only.
    - Do NOT include citations.
    - Do NOT add introduction text.
    - Start directly with "A)".
    - No closing summary.
    """

    try:
        payload = {
            "model": PERPLEXITY_MODEL,
            "messages": [
                {"role": "system", "content": "You are a technical analyst. Use precise specs, numbers, and proper nouns."},
                {"role": "user", "content": prompt_template}
            ],
            "temperature": 0.1
        }
        
        response = requests.post(PERPLEXITY_API_URL, headers={"Authorization": f"Bearer {PERPLEXITY_API_KEY}"}, json=payload)
        response.raise_for_status()
        
        res_json = response.json()
        raw_text = res_json["choices"][0]["message"]["content"]
        strategy_citations = res_json.get("citations", [])
        
        # --- CLEANING STEP: Remove ** and Citations ---
        cleaned_text = clean_citations(raw_text)
        cleaned_text = cleaned_text.replace("**", "")  # <--- Removes the stars
        
        # --- SPLIT SECTIONS ---
        parts = {"A": "", "B": "", "C": "","citations": strategy_citations}
        try:
            idx_a = cleaned_text.find("A) Strategic")
            idx_b = cleaned_text.find("B) Where")
            idx_c = cleaned_text.find("C) Where")
            
            if idx_a != -1:
                end_a = idx_b if idx_b != -1 else len(cleaned_text)
                parts["A"] = cleaned_text[idx_a:end_a].strip()
            if idx_b != -1:
                end_b = idx_c if idx_c != -1 else len(cleaned_text)
                parts["B"] = cleaned_text[idx_b:end_b].strip()
            if idx_c != -1:
                parts["C"] = cleaned_text[idx_c:].strip()
        except:
            return {"error": "Could not parse sections.","citations": []}

        return parts

    except Exception as e:
        return {"error": f"Error: {str(e)}","citations": []}

def generate_cost_structure(product_name: str, company: str):
    """
    Generates the 'Cost Structure / Price Drivers' analysis.
    """
    if not PERPLEXITY_API_KEY:
        return "Error: Missing API Key."

    prompt_template = f"""
    Act as a Senior Product Pricing Analyst.
    Analyze the pricing structure for "{product_name}" by {company}.

    STRICT OUTPUT RULES — READ BEFORE WRITING:
        - Output ONLY the structured sections below. Nothing else.
        - Do NOT include any introduction, preamble, summary, closing remarks, or meta-commentary.
        - Do NOT write phrases like "I must be transparent", "search results indicate", "What I can confirm", "Recommendation:", "To complete this section", or any similar hedging language.
        - Do NOT explain what data is missing or what the reader should do next.
        - If a specific data point is unavailable, write "Not publicly available" inline within the bullet — then move on. Do not dedicate bullets or sections to explaining the absence.
        - Every section MUST be present and populated. Never skip or collapse a section.
    TASK:
    Identify the Top 5 Technical Features that drive price in this specific product category.
    Then, explain how "{product_name}" compares on these drivers.

    Follow this EXACT format (Markdown):

    ### Cost Structure: What drives price for {product_name}
    When labs say "{product_name} cost," they’re usually mixing these drivers:

    1. **[Driver 1 Name]**
       [Explain market logic]. **{product_name} Position:** [Explain fit].

    2. **[Driver 2 Name]**
       [Explain market logic]. **{product_name} Position:** [Explain fit].

    3. **[Driver 3 Name]**
       [Explain market logic]. **{product_name} Position:** [Explain fit].

    4. **[Driver 4 Name]**
       [Explain market logic]. **{product_name} Position:** [Explain fit].

    5. **[Driver 5 Name]**
       [Explain market logic]. **{product_name} Position:** [Explain fit].

    INSTRUCTIONS:
    - Focus on HARDWARE specs.
    - Do NOT use citation numbers like [1].
    """

    try:
        payload = {
            "model": PERPLEXITY_MODEL,
            "messages": [
                {"role": "system", "content": "You are a pricing analyst. Output formatted Markdown."},
                {"role": "user", "content": prompt_template}
            ],
            "temperature": 0.1
        }
        
        response = requests.post(PERPLEXITY_API_URL, headers={"Authorization": f"Bearer {PERPLEXITY_API_KEY}"}, json=payload)
        response.raise_for_status()
        
        content = response.json()["choices"][0]["message"]["content"]
        return {
        "content": clean_citations(content),
        "citations": response.json().get("citations", [])
        }


    except Exception as e:
        return f"Error generating cost structure: {str(e)}"
    

# import re
 
# def clean_competitor_output(raw_text: str, max_entries: int = 6) -> list[str]:
#     lines = raw_text.strip().splitlines()
#     seen_manufacturers = set()
#     results = []
 
#     for line in lines:
#         # Strip bullets, asterisks, leading whitespace
#         line = line.strip().lstrip("*-• ")
 
#         # Strip citation markers like [1], [2]
#         line = re.sub(r'\[\d+\]', '', line).strip()
 
#         # Skip empty lines
#         if not line:
#             continue
 
#         # Normalize separator: replace → with –
#         # line = re.sub(r'\s*[→->]+\s*', ' – ', line)
#         line = re.sub(r'\s*→\s*|\s*->\s*', ' – ', line)
 
 
#         # Must contain the separator
#         if ' – ' not in line:
#             continue
 
#         manufacturer, platform = line.split(' – ', 1)
#         manufacturer = manufacturer.strip()
#         platform = platform.strip()
 
#         # Take only the first platform if multiple are listed (before first comma)
#         platform = platform.split(',')[0].strip()
 
#         # Remove content in parentheses (model variants)
#         # Remove content in parentheses (model variants)
#         platform = re.sub(r'\s*\(.*?\)', '', platform).strip()
 
#         # Remove standalone numbers and alphanumeric suffixes
#         # e.g. "Cytation 5" → "Cytation", "Synergy Neo 2" → "Synergy Neo"
#         platform = re.sub(r'\s+\d+\w*$', '', platform).strip()
 
#         # Deduplicate by manufacturer (case-insensitive)
#         manufacturer_key = manufacturer.lower()
#         if manufacturer_key in seen_manufacturers:
#             continue
#         seen_manufacturers.add(manufacturer_key)
 
#         results.append(f"{manufacturer} – {platform}")
 
#         if len(results) >= max_entries:
#             break
 
#     return results
 
# def validate_competitors_with_gemini(raw_perplexity_output: str, benchmark_product: str, benchmark_manufacturer: str, product_category: str) -> list[str]:
#     client = get_gemini_client()
#     if not client:
#         return []
 
#     prompt = f"""You are a laboratory instrumentation competitive intelligence expert.
 
# Below is raw research output about competitors for:
#   Benchmark Product: {benchmark_product}
#   Benchmark Manufacturer: {benchmark_manufacturer}
#   Product Category: {product_category}
 
# RAW INPUT:
# {raw_perplexity_output}
 
# YOUR TASK:
# Validate and clean this list. Return ONLY a JSON object in this exact format:
# {{"competitors": ["Manufacturer – Platform Name", ...]}}
 
# VALIDATION RULES (apply strictly):
# 1. BRAND NAMES: Use the current customer-facing product brand.
#     - Do NOT include the corporate parent in parentheses
#      (e.g., use "BioTek" not "BioTek (Agilent)").
#    - Only correct a brand name if you are confident it has changed.
#      When in doubt, keep the name as it appears in the input.
 
# 2. ONE PLATFORM PER MANUFACTURER: If multiple platforms are listed for one
#    manufacturer, keep only the single most relevant one for {product_category}.
 
# 3. FILTER WRONG CATEGORIES: Remove entries that are NOT true competitors to
#    {benchmark_product}. Remove:
#    - Bead-based / Luminex platforms (e.g., Bio-Plex)
#    - Cuvette-based spectrophotometers or spectrofluorometers (e.g., Cary Eclipse)
#    - Single-mode readers unless the benchmark itself is single-mode.
 
# 4. NO HALLUCINATIONS: Remove any platform you are not confident is a real,
#    commercially available product. When in doubt, exclude.
 
# 5. PLATFORM NAME ONLY: Use the platform family name only. No model numbers,
#    no suffixes like Plus/Pro/Neo/Elite, no parenthetical variants.
#    Example: "SpectraMax iSeries" not "SpectraMax iD3/iD5/i3x"
 
# 6. EXCLUDE BENCHMARK: Do not include {benchmark_manufacturer} or {benchmark_product}.
 
# 7. MAX 6 ENTRIES: Return at most 6 competitors.
 
# 8. SEPARATOR: Use " – " (space, en-dash, space) between manufacturer and platform.
 
# Return ONLY the JSON object. No explanation, no markdown, no extra text."""
 
#     try:
#         res = client.chat.completions.create(
#             model="gemini-2.0-flash",
#             messages=[
#                 {"role": "user", "content": prompt},
#                 {"role": "system", "content": "Output valid JSON only."}
#             ],
#             temperature=0.1
#         )
#         raw = res.choices[0].message.content.strip()
#         raw = re.sub(r'^```(?:json)?\s*', '', raw)
#         raw = re.sub(r'\s*```$', '', raw)
#         data = json.loads(raw)
#         return data.get("competitors", [])
#     except Exception:
#         return []
 
# def like_for_like(product_category, benchmark_product, benchmark_manufacturer,text=""):
# #     query = f"""
# # You are a competitive intelligence analyst in the laboratory instrumentation market.
 
# # Research the global “like-for-like” competitive set for:
 
# # Benchmark Product: {benchmark_product}
# # Manufacturer: {benchmark_manufacturer}
# # Category: {product_category}
 
# # Task:
 
# # Identify the top 7–10 global competitors that offer research-grade multimode microplate readers supporting Absorbance (UV-Vis) + Fluorescence Intensity (FI) as core capabilities (even if bundled with luminescence/TRF/Alpha).
 
# # Strict Instructions:
 
# # 1. Do NOT describe the benchmark product.
# # 2. Do NOT provide explanations.
# # 3. Do NOT summarize findings.
# # 4. Do NOT include commentary.
# # 5. Do NOT include incomplete competitors.
# # 6. Identify ALL major global manufacturers competing in this segment.
# # 7. For each manufacturer, list ONLY the specific product series or key models that directly compete with the benchmark product in terms of core capabilities (Abs + FI).
 
# # Output Format (TEXT ONLY):
 
# # * Manufacturer 1 → Product Series / Key Models
 
# # * Manufacturer 2 → Product Series / Key Models
# # ...
 
 
# # Example format:
# # Molecular Devices → SpectraMax iSeries (iD3, iD5, i3x)
 
 
# # Only return competitor mappings in the exact format above.
# # if any competitor does not have a clear product series or key models that match the benchmark's core capabilities, try to find the closest offering but do NOT include it if it's not a clear match.
# # One competitor per line.
# # No additional text before or after.
# # find the most accurate and direct competitors based on publicly available information from manufacturer websites, distributor listings, and reputable lab equipment resellers, privetely held market research, and industry reports.
# # """
 
#     query = f"""
#     You are a competitive intelligence analyst in the laboratory
#     instrumentation market.
 
#     Research the global “like-for-like” competitive set for:
 
#     Benchmark Product: {benchmark_product}
#     Benchmark Manufacturer: {benchmark_manufacturer}
#     Product Category: {product_category}
 
#     TASK:
#     Identify no more than 6 global competitors that customers realistically
#     recognize, evaluate, and shortlist as alternatives to the benchmark
#     in real purchasing decisions.
#     For each manufacturer, identify exactly ONE primary platform —
#     the single platform most commonly shortlisted against the benchmark.
#     Do NOT list multiple platforms per manufacturer.
#     Do NOT use commas or slashes to group variants or models on one line.
   
#     IMPORTANT: Do not include citation numbers, footnote markers,
#     or reference brackets anywhere in your output.
 
 
#     DEFINITION OF “LIKE-FOR-LIKE” (CRITICAL):
#     “Like-for-like” refers to platforms considered in the same purchasing
#     discussion, RFQ, or vendor shortlist — not strict technical equivalence.
 
#     PLATFORM DEFINITION (MANDATORY):
#     - A platform is a customer-recognized product family or system name
#     that anchors evaluation and shortlisting.
#     - Do NOT list individual models, SKUs, or configuration variants.
#     - Do NOT use parentheses to list sub-models or options.
#     - If multiple variants exist, collapse them into the single
#     highest-level platform name.
 
#     MANUFACTURER / BRAND RULES:
#     - List ONLY global OEM manufacturers or customer-facing brands.
#     - Exclude distributors, resellers, and integrators.
#     - Use the product-level brand name that appears on the instrument
#     and datasheet — not the corporate parent.
#     Customers shortlist by product brand, not holding company.
#     (e.g., "BioTek" not "BioTek (Agilent)",
#             "Beckman Coulter" not "Danaher (Beckman Coulter)")
#     - Use the current, active brand name as of today.
#     If a brand has been rebranded, use the name customers encounter
#     on current product pages and datasheets.
 
 
 
#     SHORTLIST CONTEXT RULE (CRITICAL):
#     Include ONLY platforms that are commonly evaluated in the SAME
#     buying conversation as the benchmark product.
#     If a platform is typically purchased or budgeted in a different
#     decision context, it must be excluded.
#     Exclude single-mode or application-specific platforms
#     (e.g., fluorescence-only, luminescence-only, polarization-only)
#     unless the benchmark itself is single-mode.
#     Only include platforms whose core capability matches the
#     primary detection mode(s) of the benchmark.
 
 
#     NO-OVERREACH RULE:
#     - Do NOT invent platforms or product families.
#     - Do NOT force inclusion if a credible platform does not exist.
#     - Base inclusion on commonly accepted market knowledge and
#     customer shortlisting behavior, not exhaustive specification matching.
#     - Prioritize platforms with demonstrated global commercial presence.
#     Exclude regional or niche vendors unless they are genuinely
#     shortlisted against the benchmark in global purchasing decisions,
#     not just regional or application-specific ones.
#     - If a manufacturer already appears under a product brand,
#     do NOT list it again under the parent company name.
#     Each manufacturer appears at most once.
 
 
#     OUTPUT FORMAT (STRICT):
#     One line per competitor, exactly:
#     Manufacturer – Platform Name
 
#     - Do NOT include citation numbers, footnote markers, or reference
#     brackets (e.g. [1], [2]) anywhere in your output.
#     - Do NOT use bullet points, asterisks, or any markdown formatting.
#     - Output plain text only.
#     - Use " – " (space, en-dash, space) as the only separator.
 
#     Example of CORRECT output:
#     Acme Corp – PlatformX
#     GlobalInstruments – AlphaReader
#     Parent Co (Brand) – PlatformY
 
#     Example of INCORRECT output (never do this):
#     Acme Corp – PlatformX Pro, PlatformX Lite        ← multiple platforms
#     GlobalInstruments – AlphaReader (AR-100, AR-200)  ← model variants
 
 
#     FINAL VALIDATION (MANDATORY — apply in order):
 
#     1. PLATFORM COLLAPSE: Each line must show exactly one platform name.
#     Strip ALL words or tokens after the core platform name, including:
#     - Descriptive adjectives: Plus, Pro, Elite, Ultra, Neo, Max
#     - Model designators and codes: FSX, LB 943, iSeries, M Plex
#     - Version numbers: 5, 10M, 200
#     Keep only the shortest recognizable platform name.
#     Example: "Platform X Plus" → "Platform X"
#     Example: "Platform iD3 / iD5 / iD7" → "Platform"
 
 
#     2. ONE ENTRY PER LINE: If multiple platforms appear on one line
#     separated by commas or slashes, collapse to the single dominant
#     platform name. Do NOT split into multiple lines.
 
#     3. SHORTLIST FILTER: Remove any platform not commonly evaluated
#     in the same RFQ or vendor shortlist as the benchmark.
#     When in doubt, exclude.
 
#     4. COUNT CHECK: If more than 6 entries remain after steps 1–3,
#     remove the least commonly shortlisted entries until ≤ 6 remain.
#     """
#     try:
#         res = requests.post(
#             PERPLEXITY_API_URL,
#             headers={"Authorization": f"Bearer {PERPLEXITY_API_KEY}"},
#             json={
#                 "model": PERPLEXITY_MODEL,
#                 "messages": [{"role": "user", "content": query}],
#                 "temperature": 0.2,
               
 
#             }
#         ).json()
       
#         # content = res["choices"][0]["message"]["content"]
#         # return {"content": content, "status": "success"}
#         # content = res["choices"][0]["message"]["content"]
#         # cleaned = clean_competitor_output(content, max_entries=6)
#         # return {"content": "\n".join(cleaned), "status": "success"}
#         content = res["choices"][0]["message"]["content"]
 
#         validated = validate_competitors_with_gemini(content, benchmark_product, benchmark_manufacturer, product_category)
 
#         if validated:
#             return {"content": "\n".join(validated), "status": "success"}
 
#         # Fallback if Gemini fails
#         cleaned = clean_competitor_output(content, max_entries=6)
#         return {"content": content, "status": "success"}
        
 
#     except Exception as e:
#         return {"status": "error"}